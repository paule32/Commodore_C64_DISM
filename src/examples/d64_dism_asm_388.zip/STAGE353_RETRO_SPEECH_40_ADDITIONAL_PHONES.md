# Stage 353 – Retro-Hybrid-Sprachsynthese um 40 Laute erweitert

**Verbindliche Ausgangsbasis:** `d64_dism_asm_352.zip`.

## Umsetzung

- Die bestehende Lauttabelle in `speech/retro_speech.c` wurde von 41 auf
  **81 Einträge**, also um **exakt 40 neue Tokens**, erweitert.
- Jede neue Lautvariante hat eigene F1/F2/F3-Formanten, Anregungswerte,
  eine zeitliche Dauer und gegebenenfalls einen Verschlussimpuls.
- Die neue deutsche Graphem-zu-Phonem-Logik berücksichtigt unter anderem
  `tsch`, `dsch`, `pf`, `ts/tz`, `ie`, `aa/ee/oo`, Dehnungs-`h`,
  finales `-er` und silbisches `-en`.
- Die Wörterbuchbeispiele sind entsprechend erweitert.
- Alle neuen Laute können per `SpeechRenderPhonemes()` angesprochen werden.
- Neue introspektive DLL-Exporte:
  - `SpeechGetPhonemeCount()` → 81
  - `SpeechGetPhonemeToken(index)`
  - `SpeechSavePhonemesWav(path, tokens)`
- Die Demo unterstützt `--list-phonemes` und `--phonemes "..."`.
- Bestehende C64-/Amiga-Mix-, Speed-, Pitch-, Articulation-, Expression-,
  `SpeechSpeak()`- und dBase-Importe bleiben erhalten.

## Kategorien

| Kategorie | Neue Laute |
|---|---:|
| Lange Vokale | 8 |
| Kurze/laxe Vokale | 7 |
| Nasalvokalvarianten | 4 |
| R-Laute | 3 |
| Silbische Nasale | 3 |
| Affrikaten | 4 |
| Zusätzliche Sibilanten | 3 |
| Fremdsprachenlaute | 4 |
| Behauchte/velare Laute | 4 |
| **Summe** | **40** |

**Präzisierung:** Nicht alle zusätzlichen Tokens sind eigenständige
Phoneme der deutschen Standardsprache; mehrere dienen der Aussprache,
lautlichen Variation und Fremdwortunterstützung. Die Retro-Formantsynthese
modelliert sie vereinfacht und ist nicht mit professionellen IPA-/TTS-
Sprachmodellen gleichzusetzen.

## Testnachweis

- `python -m unittest -v test_stage353_speech_40_phones`
- `python -m unittest test_stage339_retro_speech test_stage340_speech_pe32_imports test_stage341_speech_finetune test_stage342_dbase_speech test_stage343_speech_ordinal_compat`
- Host-GCC mit `-O2 -std=c99 -Wall -Wextra -Werror -fPIC -shared`.
- WAV-Ausgabe und Demo-Dynamiklink unter Linux wurden geprüft.
- Windows 10 PE32 / WinMM-Laufzeittest bleibt offen und benötigt `python build_pe32.py`
  aus einer 32-Bit-MINGW32-Shell.

## Betroffene Dateien

- `speech/retro_speech.c`
- `speech/retro_speech.h`
- `speech/retro_speech_demo.c`
- `speech/README.md`
- `test_stage353_speech_40_phones.py`
- `STAGE353_RETRO_SPEECH_40_ADDITIONAL_PHONES.md`
