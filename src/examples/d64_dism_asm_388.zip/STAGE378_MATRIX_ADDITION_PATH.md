# Stage 378 – Expliziter Lösungsweg für Matrix-Addition

Basis: `d64_dism_asm_377.zip`

## Änderung
Die Matrix-Beispielrechnungen zeigen bei Additionsaufgaben nun nicht mehr nur
allgemeinen Platzhaltertext wie `A + B = zeilenweise addieren`, sondern einen
konkreten Rechenweg mit Summanden und Ergebnis.

## Beispiel
Aus einer quadratischen Matrix

```text
[ 1, 2 ]
[ 3, 4 ]
```

wird nun z. B. dargestellt:

```text
A = [ 1, 2 ]
[ 3, 4 ]
B = [ 1, 2 ]
[ 3, 4 ]
```

Lösung:

```text
A + B = [ 1 + 1, 2 + 2 ]
[ 3 + 3, 4 + 4 ]
= [ 2, 4 ]
[ 6, 8 ]
```

## Technisch
- neuer Marker `§§SOLUTION§§` trennt Aufgabe und gelbe Lösung
- die gelbe Lösung kann jetzt mehrzeilig dargestellt werden
- aus numerischen Beispielmatrizen wird der Additionsweg automatisch erzeugt

## Tests
- `test_stage375_matrix_examples.py`
- `test_stage377_yellow_matrix_solutions.py`
- `test_stage378_matrix_addition_solution.py`
