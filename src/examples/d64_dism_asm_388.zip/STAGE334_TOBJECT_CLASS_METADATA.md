# Stage 334 – TObject und Klassenmetadaten

Verbindliche Ausgangsbasis: d64_dism_asm_333.zip.

## Implementiert

- `d64dbase/class_model.py`: `DBaseClassRegistry`, `DBaseClassInfo`, `DBaseClassError`, `parse_dbase_class_metadata`.
- Eingebaute Wurzelklasse `TObject`. `CLASS X` erhält implizit `OF TObject`.
- Eingebaute Klassen `FORM OF TObject`, `TV_Object OF TObject` und `TV_Application OF TV_Object` als Metadateneinträge für die geplante Turbo-Vision-Bindung.
- `CLASS X OF Base` wird unabhängig von Groß- und Kleinschreibung registriert; vorwärts referenzierte Eltern werden nach dem Sammeln aufgelöst.
- Prüfung auf doppelte Klassen, unbekannte Eltern und zyklische Vererbung.
- Methoden- und Property-Namen als Klassenmetadaten; `class_name`, `class_type`, `inherits_from`, `ancestors` auf Registry-Ebene.
- Bestehende WFM-Formulare werden mit `base_class="FORM"` und einer `class_registry` versehen.

## Absichtlich noch nicht umgesetzt

- Die vorhandene dBase-PRG-Codegenerierung verarbeitet nicht automatisch allgemeine `CLASS`-Definitionen aus der Registry. Die Registry ist die semantische Grundlage, **kein bereits funktionsfähiger allgemeiner OOP-Compiler**.
- Keine Laufzeit-Objektinstanzen mit TObject-Header, VTable, virtuellen Methoden oder dynamischem `Free`/`Destroy`.
- `TV_Object` und `TV_Application` sind nur Platzhalter für künftige DLL-Wrapper; keine DLL-Importe oder nativen Aufrufe.
- Die WFM-Laufzeit bleibt beim bisherigen FORM-Verhalten; kein neuer Klassenlayout-Code.

## Tests

`python -m unittest -v test_stage334_tobject.py`

Die Tests überprüfen die Klassenregistry und die bestehende WFM-Parse-Kompatibilität. Ein tatsächlicher Windows-PE32-Laufzeittest ist noch nicht erfolgt.
