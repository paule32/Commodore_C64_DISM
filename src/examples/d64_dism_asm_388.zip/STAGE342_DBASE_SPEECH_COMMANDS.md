# Stage 342 – dBase SET SPEECH / SAY

**Verbindliche Basis:** Stage 341 (`d64_dism_asm_341.zip`).

## dBase-PE32-Syntax

```dbase
SET SPEECH ON
SET SPEECH MODE HYBRID
SET SPEECH MIX 55
SET SPEECH PITCH 125
SET SPEECH SPEED 100
SAY "Hallo, ich bin dein Sprachcomputer."
SET SPEECH OFF
```

Die Beispielquelle liegt unter `examples/dbase_speech_stage342.prg` (ohne explizites OFF; das Programm-Cleanup schaltet die Sprache automatisch ab).

- `SET SPEECH ON`: initialisiert `retro_speech.dll` mit 22050 Hz (nur einmal pro aktiver Sitzung); `SpeechInitialize` meldet per Rueckgabewert den Erfolg.
- `SET SPEECH OFF`: ruft `SpeechShutdown` auf und deaktiviert weitere `SAY`-Aufrufe, bis erneut ON folgt.
- `SET SPEECH MODE C64|HYBRID|AMIGA`: stellt die Profile entsprechend `speech/retro_speech_demo.c` ein, inklusive Mix, Pitch, Speed, Expression und Articulation. Folgende einzelne SET-Anweisungen koennen Werte ueberschreiben.
- `SET SPEECH MIX n` (0..100, 0=C64, 100=Amiga), `SET SPEECH PITCH n` (70..260 Hz) und `SET SPEECH SPEED n` (50..200 %): erwarten ganze numerische Konstanten; sind sowohl vor als auch nach `SET SPEECH ON` moeglich. Werte werden beim naechsten ON wieder angewendet.
- `SAY <string-ausdruck>`: spricht einen String oder Char. Ohne ON bleibt die Anweisung ohne Wiedergabe.

Textliterale und zur Compile-Zeit bekannte String-Ausdruecke werden als UTF-8-NUL-terminierte Daten in die `.data`-Sektion geschrieben und direkt an `SpeechSpeak` uebergeben. Dynamische dBase-Strings werden weiter als CP1252-Bytefolgen mit expliziter Laenge gespeichert; die neue DLL-Funktion `SpeechSpeakCP1252(const char*, uint32_t)` kodiert diese vor der Synthese in UTF-8 um. Die Konvertierung ist auf maximal 8191 Eingangsbytes begrenzt.

## Import-/Link-Schnittstelle

Nur wenn ein dBase-Programm SET SPEECH oder SAY verwendet, erzeugt der Compiler diese benannten DLL-Importe:

```
SpeechInitialize      retro_speech.dll
SpeechSetMix          retro_speech.dll
SpeechSetPitch        retro_speech.dll
SpeechSetSpeed        retro_speech.dll
SpeechSetExpression   retro_speech.dll
SpeechSetArticulation retro_speech.dll
SpeechSpeak           retro_speech.dll
SpeechSpeakCP1252     retro_speech.dll
SpeechShutdown        retro_speech.dll
```

PE32-Aufrufkonvention: Win32 `__stdcall`; der Callee bereinigt seine Parameter. Der d64_dism-Assembler/COFF32-Linker verarbeitet die Exporte per Import-by-Name, ohne eine fremde `.dll.a`-Importbibliothek zu benoetigen. Die MinGW32-DLL muss `--add-stdcall-alias` enthalten (Stage 340, `speech/build_pe32.py`). Keine zusaetzliche DLL ist erforderlich, wenn ein dBase-Programm keine Sprachbefehle verwendet.

Beim Programmabschluss und beim geregelten GUI-Shutdown erfolgt `SpeechShutdown` genau dann, wenn die Engine zuvor erfolgreich initialisiert wurde. `SAY` ist synchron/blockierend, da die Stage-341-Windows-Ausgabe `waveOut` mit blockierendem Playback verwendet.

## Windows-10-Build und Start

1. MSYS2 **MINGW32** oeffnen, `cd speech`, `python build_pe32.py` ausfuehren. Das erzeugt `speech/bin/retro_speech.dll` und das Demo.
2. In d64_dism eine PE32-dBase-Programmdatei mit `SET SPEECH` und `SAY` kompilieren und mit dem **internen** Assembler/Linker zu einer PE32-EXE bauen.
3. Start aus d64_dism: fuer dBase-Programme mit dem Import wird die passende DLL aus dem Arbeitsverzeichnis oder `speech/bin` neben die EXE kopiert. Die gefundenen Exporte und die PE32-Maschine werden geprueft; bei fehlender/alter DLL erscheint eine Fehlermeldung.
4. Bei manuellem Start der EXE muss `retro_speech.dll` neben der EXE oder im Windows-DLL-Suchpfad liegen; die bisherige `libd64_qt5.dll` und ihre Qt5-Abhaengigkeiten bleiben erforderlich.

**Grenzen:** Aktuell nur PE32, weil diese Runtime als Windows-32-Bit-DLL gebaut wird. Der Compiler lehnt PE64-Sprachprogramme explizit ab. Es gibt noch kein `SAY PHONEM` und keine Fehlerabfrage auf dBase-Ebene. Das WFM-Event-Backend verwendet einen separaten Compilerpfad und ist hier noch nicht erweitert. Die Funktion `SpeechSpeakCP1252` setzt ein Neubauen der Sprach-DLL ab Stage 342 voraus.

## Verifikation

- Neue `test_stage342_dbase_speech.py`: Parser, Fehlerdiagnosen, Funktionen/IF, statische UTF-8-Literale, dynamische CP1252-Strings, bedingte Imports, PE64-Abweisung, echte COFF32-Assemblierung und PE32-Linking durch den internen d64_dism-Linker sowie C99/GCC-Validierung des DLL-Quellcodes.
- Vorherige Stage-339/340/341-Tests laufen weiterhin.
- Ein echter Windows-PE32-DLL-Build und WAV-/Audio-Playback wurden in dieser Linux-Umgebung nicht ausgefuehrt; unter MSYS2 MINGW32 nachholen.
