# Stage 385 – Zahlen → Lustiges zu Mathe → Amazing

**Verbindliche Basis:** `d64_dism_asm_384.zip`.

## Änderungen

- Das Blatt **Amazing** wurde unter `Mathematik → Fakten → Zahlen → Lustiges zu Mathe` als gleichrangiges Blatt neben `37` und `88` angelegt.
- Die rechte Lernansicht verwendet die neue Klasse `MathAmazingFactWidget` in `d64_dism.py` und die bestehende scrollbare Fakten-Arbeitsfläche.
- Übernommen wurde die Überschrift **It's Amazing!** und die neun Gleichungen aus der bereitgestellten Bildvorlage:

```text
1 × 8 + 1 = 9
12 × 8 + 2 = 98
123 × 8 + 3 = 987
1234 × 8 + 4 = 9876
12345 × 8 + 5 = 98765
123456 × 8 + 6 = 987654
1234567 × 8 + 7 = 9876543
12345678 × 8 + 8 = 98765432
123456789 × 8 + 9 = 987654321
```

- Die Werbezeile oben ("Like our page if you like us.") und das Logo wurden **nicht** übernommen.
- Ausschließlich native Qt-Text-Labels in **Times New Roman**: keine Grafik-Dateien oder Pixmaps. Der Multiplikator `8` wird als formatiertes RichText-Element farblich hervorgehoben.
- Dark-Mode: dunkelblauer Hintergrund, weiße Gleichungen und hellrote `8`/Überschrift; Light-Mode: heller Hintergrund, dunkle Gleichungen und dunkelrote Hervorhebung. Die Schrift bleibt auswählbar/kopierbar.
- Vorhandene Seiten `37` und `88`, sowie alle bisherigen Mathe-Zweige bleiben erhalten.

## Tests

- `python -m py_compile d64_dism.py`
- `test_stage385_math_amazing.py` – Text, vollständige arithmetische Korrektheit, Schrift, Themastile und Navigation
- `test_stage383_math_magic_37.py`, `test_stage384_math_magic_88_darkmode.py` – frühere Blätter / Baumstruktur
- Weitere bestehende Mathematik-Regressionstests.

**Einschränkung:** Ein nativer PyQt5-Windows-GUI-Lauf ist hier mangels PyQt5-Umgebung nicht möglich. Die Widget-Verkabelung wurde über Testdoubles überprüft.
