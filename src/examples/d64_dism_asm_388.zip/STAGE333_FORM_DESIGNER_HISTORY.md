# Stage 333 – Formular-Designer History

Verbindliche Basis: `d64_dism_asm_332.zip`.

- `DBaseFormDesignerScene` verwaltet bis zu 64 vollständige Formular-Snapshots.
- `Strg+Z` = Undo, `Strg+Y` = Redo, wenn Formularansicht oder Eigenschaftenfenster aktiv ist.
- Snapshots enthalten Formular-/Control-Eigenschaften, Brush-Daten, Hierarchie sowie Geometrie und Komponenten-Zähler.
- Die History wird alle 120 ms auf Änderungen überprüft; gleichbleibende Zustände belegen keinen zusätzlichen History-Platz.
- Nach Undo führt eine neue Änderung zum Verwerfen der Redo-Folge.
- Rekonstruktion entfernt Controls direkt aus der Scene statt des normalen `delete_control`, um keine WFM-Eventmethoden durch den Lösch-Cleanup zu verlieren.
- Beim Öffnen einer anderen WFM-Datei wird die History zurückgesetzt.

Grenzen: Die History arbeitet nur innerhalb der geöffneten Sitzung; sie wird nicht in die WFM-Datei geschrieben. Sehr schnell aufeinander folgende Einzeländerungen (<120 ms) können als ein Zustand gespeichert werden. Die Quelltextbearbeitung im Editor hat eine eigene Undo-History und gehört nicht zu dieser Designer-History. Ein nativer Windows-/Qt5-Test wurde nicht durchgeführt.
