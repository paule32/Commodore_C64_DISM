"""Stage 340 regression: PE32 stdcall names must link from MinGW and d64_dism.

The test instruments the build script with a fake compiler. It does not
claim to execute the actual MinGW32 linker on this Linux test host.
"""
from pathlib import Path
import runpy
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'speech' / 'build_pe32.py'


class Stage340Pe32ImportTests(unittest.TestCase):
    def invoke(self, target):
        with tempfile.TemporaryDirectory(prefix='stage340_build_script_') as scratch:
            work = Path(scratch)
            file = work / 'speech' / 'build_pe32.py'
            file.parent.mkdir(parents=True)
            shutil.copyfile(BUILD, file)
            commands = []

            def mock_run(args, **kwargs):
                args = list(map(str, args))
                if '-dumpmachine' in args:
                    return subprocess.CompletedProcess(args, 0, stdout=target + '\n')
                commands.append((args, kwargs))
                return subprocess.CompletedProcess(args, 0)

            with patch('subprocess.run', side_effect=mock_run), patch('shutil.which', return_value='/fake/gcc'):
                if target.startswith('x86_64-'):
                    with self.assertRaises(SystemExit) as err:
                        runpy.run_path(str(file), run_name='__main__')
                    self.assertIn('MINGW32', str(err.exception))
                else:
                    runpy.run_path(str(file), run_name='__main__')
            return commands

    def test_mingw32_build_exports_both_import_names(self):
        commands = self.invoke('i686-w64-mingw32')
        self.assertEqual(len(commands), 2)
        dll_command = commands[0][0]
        demo_command = commands[1][0]
        self.assertIn('-shared', dll_command)
        self.assertIn('-DRETRO_SPEECH_BUILD', dll_command)
        self.assertIn('-Wl,--add-stdcall-alias', dll_command)
        self.assertNotIn('-Wl,--kill-at', dll_command)
        self.assertTrue(any(arg.startswith('-Wl,--out-implib,') for arg in dll_command))
        self.assertIn('-lwinmm', dll_command)
        self.assertIn('-lretro_speech', demo_command)
        self.assertIn('-m32', dll_command)
        self.assertIn('-m32', demo_command)

    def test_rejects_mingw64_to_avoid_wrong_pe_architecture(self):
        self.assertEqual(self.invoke('x86_64-w64-mingw32'), [])

    def test_header_keeps_stdcall_and_import_annotations(self):
        header = (ROOT / 'speech' / 'retro_speech.h').read_text(encoding='utf-8')
        self.assertIn('#  define RS_API __declspec(dllexport)', header)
        self.assertIn('#  define RS_API __declspec(dllimport)', header)
        self.assertIn('# define RS_CALL __stdcall', header)
        self.assertIn('SpeechInitialize(int32_t sample_rate)', header)
        self.assertIn('SpeechRenderText(const char *utf8, int16_t *pcm, uint32_t capacity)', header)


if __name__ == '__main__':
    unittest.main(verbosity=2)
