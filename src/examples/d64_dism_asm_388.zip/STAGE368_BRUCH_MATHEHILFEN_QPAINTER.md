# Stage 368 – Bruch-Mathehilfen als Python-/QPainter-Code

Verbindliche Basis: `d64_dism_asm_367.zip`.

## Neue Baumstruktur

```
Fakten
└── Grundwissen
    └── Rechengesetze
        ├── Grundrechen-Arten
        ├── Teilbarkeit
        │   └── Brüche
        │       ├── Brüche addieren
        │       ├── Brüche subtrahieren
        │       ├── Brüche multiplizieren
        │       └── Brüche dividieren
        ├── Potenzen
        └── Rechengesetze
```

Doppelklick auf ein Blatt öffnet den entsprechenden QPainter-Inhalt auf der **rechten Inhaltsseite des vorhandenen Mathematik-Docks**. Eine eigene Dock-Komponente wird nicht erstellt. Beim Anpassen der Dock-Größe darf horizontal und vertikal gescrollt werden.

## Python-Dateien

- `fraction_math_help.py`: neue vollständige, eigenständig ausführbare QPainter-Komponente `FractionHelpWidget`.
- `d64_dism.py`: eingebundener Import, Konstruktion vor dem ersten `set_dark_mode`, Navigation und Theme-Weitergabe.
- `test_stage368_fraction_math_help.py`: fünf Seiten, helle und dunkle Palette, Test-Docknavigation, Arithmetik.

## Inhalt

**Brüche**: vektorielles Merkblatt mit neun Brüchen, ihren Dezimal-/Prozentwerten und proportional gefüllten grafischen Balken. Die Werte für ein und zwei Drittel werden als periodisch bzw. gerundet gekennzeichnet.

**Brüche addieren**: Gemeinsamer Nenner, 2/3 + 1/5 = 10/15 + 3/15 = 13/15, sowie 1/4 + 2/4 = 3/4.

**Brüche subtrahieren**: Gemeinsamer Nenner, 5/6 - 1/4 = 10/12 - 3/12 = 7/12, sowie 7/9 - 2/9 = 5/9.

**Brüche multiplizieren**: Zähler mal Zähler und Nenner mal Nenner, 2/3 · 1/5 = 2/15 und Kürzungsbeispiel 3/4 · 6/5 = 9/10.

**Brüche dividieren**: Kehrwert des zweiten Bruchs, 2/3 : 1/5 = 2/3 · 5/1 = 10/3, sowie 3/4 : 6/5 = 5/8.

Bei allen Seiten: Brüche und Bruchstriche mit `QPainter`, nicht per `QPixmap` oder eingefügter Rastergrafik. Eigene dunkle/helle Palette. Das Merkblatt wird linksbündig innerhalb der rechten Inhaltsseite gezeichnet.

## Eigenständige Ausführung

```powershell
python -m pip install PyQt5
python fraction_math_help.py --page fraction_overview
python fraction_math_help.py --page fraction_multiply --dark
python fraction_math_help.py --page fraction_divide
```

Verfügbare `--page`-Werte:

```
fraction_overview
fraction_add
fraction_subtract
fraction_multiply
fraction_divide
```

## Prüfstatus

- Syntax von `d64_dism.py` und `fraction_math_help.py` geprüft.
- 48 gezielte Tests mit Qt-kompatiblen Testobjekten bestanden.
- Keine tatsächliche Windows-PyQt5-Fensterdarstellung in dieser Umgebung möglich, da PyQt5 nicht installiert ist.
