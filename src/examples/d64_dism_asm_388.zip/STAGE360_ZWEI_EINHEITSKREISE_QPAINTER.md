# Stage 360 – Lernen / Mathe / Geometrie: Zwei getrennte Einheitskreise

Verbindliche Grundlage: `d64_dism_asm_359.zip`.

## Menü

`Lernen -> Mathe -> Geometrie -> Einheits-Kreis - 1`
- Bestehendes **animiertes** `UnitCircleLearningWidget`, unverändert mit 360°-Animation und Sinus-/Kosinus-Diagrammen.
- Nur Aktion und Dock-Titel umbenannt.

`Lernen -> Mathe -> Geometrie -> Einheits-Kreis - 2`
- **Neues und unabhängiges** `UnitCircleReferenceWidget`, eigenes `QDockWidget` und separate QAction.
- Die statische QPainter-Grafik zeichnet Kreis, 16 Strahlen im Winkel 0, 30, 45, ... 330 Grad,
  Gradbeschriftung, Bogenmaß mit π (u.a. Brüche), und exakte Koordinaten `(cos θ, sin θ)`.
- Brüche (z. B. √3/2) werden mit waagerechtem Bruchstrich aus Text und Linien gezeichnet,
  nicht als Pixelbild. Keine Nutzung der hochgeladenen PNG-Datei zur Darstellung.
- Hintergrund im Light Mode weiß, Beschriftung und Kreis schwarz;
  im Dark Mode Hintergrund schwarz, Schrift und Kreis weiß.
- `paintEvent()` skaliert den Vektorinhalt proportional auf die Größe des Docks.

## Docking-Verhalten

Die Docks sind unabhängig erstellt und haben die ObjectNames
`unit_circle_learning_dock` und `unit_circle_reference_dock`.
Sie teilen **nur** die vorhandene Vollflächen-Dockverwaltung, sodass das
zuletzt gewählte Lern-Dock sichtbar ist, ohne die übrigen IDE-Docks beim
Umschalten ungewollt wiederherzustellen. Beim Verlassen wird die zuvor
sichtbare Dockanordnung wieder eingeblendet. Die Animation wird beim
Wechsel vom ersten zum zweiten Kreis angehalten, beim erneuten Öffnen des
ersten Kreises wieder gestartet.

## Prüfungen

`python -m unittest -v test_stage360_two_unit_circles`
- 16 korrekte Winkel-/Bogenmaß-/Koordinatenpaare
- Qt-Painter-Aufrufe, Light/Dark-Modus
- proportionaler Resize
- Wechsel/Rückkehr der beiden Dock-Workspaces
- unveränderte ursprüngliche Animationsklasse

Auch die vorhandenen Tests aus Stage 344, 345, 352 und 359 wurden ausgeführt.

**Laufzeit-Hinweis:** Die Entwicklungsumgebung für dieses ZIP besitzt kein PyQt5.
Eine echte Darstellung im Windows-/PyQt5-Hauptfenster wurde daher hier nicht getestet.
