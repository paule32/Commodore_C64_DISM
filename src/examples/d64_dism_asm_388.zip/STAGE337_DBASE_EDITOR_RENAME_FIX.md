# Stage 337 – dBase-Editor und Umbenennung

Basis: d64_dism_asm_336.zip.

* `.prg`-Projektblätter unter `dBase-Programme -> Programme` verwenden beim Doppelklick weiterhin explizit `language_override="dbase"`.
* `DocumentEditor` setzt bei explizitem dBase-Modus nicht mehr den Hex-Editor als Startansicht; `focus_preferred_editor()` wählt ebenfalls den Quelltexteditor statt des C64-Hex-Editors.
* `configure_dbase_output_tabs()` blendet im dBase-Modus die Tabs `Hex-Editor` und `Hinweise` aus. Für andere Dokumenttypen bleiben diese Tabs verfügbar.
* `Umbenennen` aktiviert gezielt die Qt-Editierbarkeit und startet `editItem()` zeitversetzt nach dem Schließen des Kontextmenüs. Nach Commit wird die Editierbarkeit zurückgenommen. Der vorhandene Namenskonflikt-Dialog bleibt unverändert.

Validierung: Python-Syntaxprüfung, gezielte Source-Regressionstests; Windows-PyQt5-Interaktion nicht ausgeführt.
