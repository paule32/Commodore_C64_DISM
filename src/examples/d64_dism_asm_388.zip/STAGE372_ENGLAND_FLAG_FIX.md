# Stage 372 – England-Karte: Flagge rechts oben korrigiert

Basis: `d64_dism_asm_371.zip`

## Aufgabe
Unter `Lernen -> Geographie -> England` zeigte die eingebettete England-Karte
rechts oben eine vom Benutzer beanstandete falsche Flagge. Dieser Bereich
sollte durch eine gueltige Flagge ersetzt werden.

## Umsetzung
- Die eingebettete PNG in `england.py` wurde aktualisiert.
- Der Flaggenbereich rechts oben wurde neu gezeichnet.
- Verwendet wird jetzt eine gueltige England-Flagge
  (**St.-Georgs-Kreuz**, rotes Kreuz auf weissem Grund).
- Karteninhalt, County-Beschriftungen, Groesse, Dock-Verhalten und Zoomlogik
  bleiben unveraendert.

## Technische Details
- Bildgroesse weiterhin: **371 × 463 Pixel**
- Aktualisierte SHA-256 der eingebetteten PNG:
  `9cbf9fd3f4b2600ea22e170587e8fa9eb5f3401348707a2464cb5a0bccaa3810`

## Tests
- Neuer Regressionstest `test_stage372_england_flag.py` prueft die eingebettete
  PNG direkt und verifiziert im Flaggenbereich:
  - weisse Ecken,
  - roten horizontalen Balken,
  - roten vertikalen Balken.
- Vorhandene England-/Geographie-Tests bleiben Bestandteil der Regression.
