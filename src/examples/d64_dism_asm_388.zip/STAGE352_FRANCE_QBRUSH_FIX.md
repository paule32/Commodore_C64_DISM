# Stage 352 – Fehlerkorrektur beim Öffnen des Frankreich-Fluss-Docks

**Verbindliche Basis:** `d64_dism_asm_351.zip`

Der Aufruf `item.setBrush(Qt.NoBrush)` in
`FranceMapView._create_tributary_overlay_items()` erzeugte mit PyQt5 den
Laufzeitfehler `TypeError: ... unexpected type 'BrushStyle'`.

**Korrektur:** `item.setBrush(QBrush(Qt.NoBrush))`.
Die Qt-Bindings erwarten an dieser Stelle ein `QBrush`-Objekt, nicht den
`Qt.BrushStyle`-Enumwert. Die blauen 3-Pixel-Nebenflusslinien bleiben ohne
Fuellung; ihr Sichtbarkeitswechsel wird beibehalten.

**Tests:** Neue Tests in `test_stage352_france_tributary_qbrush.py` pruefen den
generierten Quellcode und simulieren die Qt-Typkontrolle sowie das Umschalten
zwischen Hauptfluessen. Ein nativer PyQt5-Laufzeittest ist auf der Windows-
Entwicklungsumgebung erforderlich.
