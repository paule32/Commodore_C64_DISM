# Stage 347 - Frankreich-Fluss-Overlay verfeinert

Basis: `d64_dism_asm_346.zip`

## Ziel
Die Fluss-Pfade fuer `Lernen -> Geographie -> Frankreich -> Fluesse` sollten
nicht mehr nur grob approximiert sein, sondern sich sichtbarer an der vom
Benutzer hochgeladenen Referenz-Flusskarte orientieren.

## Umsetzung
- die Overlay-Pfade wurden neu auf die bereits eingebettete Frankreich-
  Basiskarte normalisiert
- vorhandene Hauptfluesse wurden geometrisch ueberarbeitet
- zusaetzlich wurden weitere im Referenzbild sichtbare Fluesse ergaenzt:
  - Dordogne
  - Saone
  - Meuse
  - Moselle
- die Darstellung bleibt ein reines Overlay ueber derselben Basiskarte,
  d.h. kein zweites grosses Kartenbild wird eingebettet
- Linienfarbe bleibt blau (`#0066ff`), Strichbreite bleibt 2 Pixel

## Betroffene Datei
- `d64_dism.py`
