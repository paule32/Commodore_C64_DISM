# Stage 370 – Gesetze unter Potenzen als Blätter

Verbindliche Basis: `d64_dism_asm_369.zip`.

## Änderung

Die vier Gesetze sind weiterhin **direkte Untereinträge von Potenzen**, aber nun in der Qt5-Baumansicht ausdrücklich als **Endblätter** gekennzeichnet:

- Kommutativ-Gesetz
- Assoziativ-Gesetz Addition
- Assoziativ-Geset Multiplikation
- Distributiv-Gesetz

Es wird kein weiterer Unterknoten und kein ausklappbarer Ast für diese Einträge dargestellt.

## Implementierung

In `MathematicsLearningDockWidget._populate_facts_tree()` wird für jedes Gesetz gesetzt:

```python
law_item.setChildIndicatorPolicy(QTreeWidgetItem.DontShowIndicatorWhenChildless)
law_item.setFlags(law_item.flags() | Qt.ItemNeverHasChildren)
```

Die bestehende Zuordnung zur rechten QPainter-Mathehilfe über `Qt.UserRole` und `open_fact` bleibt erhalten. Alle anderen Knoten der Mathematiknavigation bleiben unverändert.

## Prüfung

55 lokale Regressionstests erfolgreich (Mathematik, Geometrie, Zinsrechnung, England-Karte, Brüche, bisherige Rechengesetze). Qt-kompatible Testdoubles wurden um die verwendeten Qt5-Konstanten und Methoden ergänzt. Python-Syntax geprüft. Nativer Windows-/PyQt5-Test steht aus.
