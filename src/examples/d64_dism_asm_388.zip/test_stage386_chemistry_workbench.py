"""Stage 386: Chemie-Baukasten (40 Elemente, Reaktionen, Dock-Menue, Matrixhoehe)."""
import ast
from pathlib import Path
import unittest

from chemistry_model import (
    ELEMENTS, BY_SYMBOL, REACTIONS, find_reaction, is_balanced,
    pretty_equation, pretty_formula,
)

DIRECTORY = Path(__file__).parent
MAIN = (DIRECTORY/'d64_dism.py').read_text(encoding='utf-8')
UI = (DIRECTORY/'chemistry_workbench.py').read_text(encoding='utf-8')


class Stage386Tests(unittest.TestCase):
    def test_first_forty_real_elements(self):
        self.assertEqual(len(ELEMENTS), 40)
        self.assertEqual([element.number for element in ELEMENTS], list(range(1, 41)))
        self.assertEqual((ELEMENTS[0].symbol, ELEMENTS[-1].symbol), ('H', 'Zr'))
        self.assertEqual(len(BY_SYMBOL), 40)

    def test_all_reactions_are_balanced_and_use_available_elements(self):
        self.assertGreaterEqual(len(REACTIONS), 20)
        for reaction in REACTIONS:
            with self.subTest(name=reaction.name):
                self.assertEqual(len(reaction.symbols), 2)
                self.assertTrue(reaction.symbols.issubset(BY_SYMBOL))
                self.assertTrue(is_balanced(reaction.equation))
                self.assertTrue(reaction.formula and reaction.name)

    def test_reaction_examples_and_unknown_results(self):
        self.assertEqual(find_reaction(['O','H']).formula, 'H2O')
        self.assertEqual(find_reaction(['Cl','Na']).formula, 'NaCl')
        self.assertEqual(find_reaction(['C','O']).formula, 'CO2')
        self.assertIsNone(find_reaction(['He','Ne']))
        self.assertIsNone(find_reaction(['H','H']))
        self.assertIsNone(find_reaction(['H']))
        self.assertIsNone(find_reaction(['H', 'O', 'C']))
        self.assertIsNone(find_reaction(['not-an-element','H']))

    def test_chemical_formula_notation(self):
        self.assertEqual(pretty_formula('Al2O3'), 'Al₂O₃')
        self.assertEqual(pretty_equation('2 H2 + O2 -> 2 H2O'), '2 H₂ + O₂ → 2 H₂O')
        self.assertEqual(pretty_equation('4 Al + 3 O2 -> 2 Al2O3'), '4 Al + 3 O₂ → 2 Al₂O₃')

    def test_menu_action_and_workspace(self):
        self.assertIn("self.chemie_baukasten_action = self.chemie_menu.addAction('Baukasten')", MAIN)
        self.assertIn('self.chemie_baukasten_action.triggered.connect(self.show_chemie_baukasten_dock)', MAIN)
        self.assertIn('def show_chemie_baukasten_dock(self):', MAIN)
        self.assertIn('class ChemistryWorkbenchController(PeriodicTableController):', MAIN)
        self.assertIn('controller.show_chemistry_workbench()', MAIN)
        self.assertIn('self._chemistry_workbench_controller = None', MAIN)
        self.assertIn('chemistry_dock.canvas.set_dark_mode(enabled)', MAIN)

    def test_drop_zone_and_buttons_and_theme(self):
        for expected in (
            'class ChemistryElementButton(QPushButton):',
            'class ChemistryElementDropArea(QFrame):',
            'class ChemistryWorkbenchWidget(QWidget):',
            'drag.setMimeData(mime)', 'self.setAcceptDrops(True)',
            'self.workbench.add_element(symbol)', 'self.combine_button.clicked.connect(self.combine_elements)',
            'self.clear_button.clicked.connect(self.clear_selection)',
            'self.search_box.textChanged.connect(self.filter_elements)',
            'def set_dark_mode(self, enabled):',
            'pretty_equation(reaction.equation)',
        ):
            with self.subTest(expected=expected):
                self.assertIn(expected, UI)

    def test_matrix_card_height_and_parent_sizing(self):
        root = ast.parse(MAIN)
        widget = next(node for node in ast.walk(root) if isinstance(node, ast.ClassDef)
                      and node.name == 'BasicMathRulesFactWidget')
        method = next(n for n in widget.body if isinstance(n, ast.FunctionDef)
                      and n.name == '_paint_matrix_type')
        source = ast.get_source_segment(MAIN, method)
        self.assertIn('calc_h = 274.0', source)
        self.assertIn('required_panel_h = content_bottom - panel_y + bottom_pad', source)
        self.assertIn('panel_h = max(340.0, available_h, required_panel_h)', source)


if __name__ == '__main__':
    unittest.main()
