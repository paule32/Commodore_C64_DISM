"""Tests for Stage 359 --test SPC entry player (audio device is mocked)."""
import importlib.util
import io
import math
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
import wave
import zlib

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('sc359', ROOT / 'speechConvert.py')
sc = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = sc
spec.loader.exec_module(sc)


class SamplePreviewTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.root = Path(self.td.name)
        self.input_wav = self.root / 'wort.wav'
        self.spc = self.root / 'samples.spc'
        self.frames = 811
        self.rate = 16000
        samples = [int(10000 * math.sin(2 * math.pi * 400 * t / self.rate))
                   for t in range(self.frames)]
        with wave.open(str(self.input_wav), 'wb') as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(self.rate)
            wav.writeframes(struct.pack('<' + 'h' * len(samples), *samples))

    def tearDown(self):
        self.td.cleanup()

    def call(self, *argv):
        return sc.main(list(map(str, argv)))

    def preview(self, entry='WORT'):
        data = []
        with patch.object(sc, '_play_wav_windows', side_effect=lambda b: data.append(b)):
            self.assertEqual(self.call('-oc', self.spc, '--test', entry), 0)
        self.assertEqual(len(data), 1)
        with wave.open(io.BytesIO(data[0]), 'rb') as wav:
            self.assertEqual(wav.getframerate(), self.rate)
            self.assertEqual(wav.getnchannels(), 1)
            self.assertEqual(wav.getsampwidth(), 2)
            self.assertEqual(wav.getnframes(), self.frames)
            return wav.readframes(wav.getnframes())

    def test_ima_plain_casefold_lookup(self):
        self.call(self.input_wav, '-oc', self.spc, '-a', 'Wort')
        pcm = self.preview('wOrt')
        self.assertTrue(any(pcm))

    def test_ima_gzip_identical_to_plain(self):
        self.call(self.input_wav, '-oc', self.spc, '-a', 'WORT')
        plain = self.preview()
        self.call(self.input_wav, '-oc', self.spc, '-a', 'WORT', '-gz')
        packed = self.preview()
        self.assertEqual(plain, packed)
        self.assertTrue(sc.read_container(self.spc)['wort'].codec & sc.CODEC_GZIP_FLAG)

    def test_pcm16_gzip_preserves_original(self):
        self.call(self.input_wav, '-c', 'pcm', '-oc', self.spc, '-a', 'WORT', '-gz')
        raw = self.preview()
        with wave.open(str(self.input_wav), 'rb') as wav:
            self.assertEqual(raw, wav.readframes(self.frames))

    def test_pcm8_converts_to_16bit(self):
        wav = self.root / 'pcm8.wav'
        with wave.open(str(wav), 'wb') as out:
            out.setnchannels(1); out.setsampwidth(1); out.setframerate(self.rate)
            out.writeframes(bytes([0, 128, 255, 128]))
        self.call(wav, '-c', 'pcm', '-oc', self.spc, '-a', 'EIGHT')
        captured = []
        with patch.object(sc, '_play_wav_windows', side_effect=captured.append):
            self.call('-oc', self.spc, '--test', 'eight')
        with wave.open(io.BytesIO(captured[0]), 'rb') as out:
            self.assertEqual(out.getsampwidth(), 2)
            self.assertEqual(struct.unpack('<4h', out.readframes(4)),
                             (-32768, 0, 32512, 0))

    def test_missing_entry_no_audio(self):
        self.call(self.input_wav, '-oc', self.spc, '-a', 'WORT')
        with patch.object(sc, '_play_wav_windows') as player:
            with self.assertRaisesRegex(sc.SpeechError, 'nicht gefunden'):
                self.call('-oc', self.spc, '--test', 'fehlend')
            player.assert_not_called()

    def test_missing_container_no_audio(self):
        with self.assertRaisesRegex(sc.SpeechError, 'nicht gefunden'):
            self.call('-oc', self.spc, '--test', 'WORT')

    def test_crc_fail_without_playback(self):
        self.call(self.input_wav, '-oc', self.spc, '-a', 'WORT', '-gz')
        data = bytearray(self.spc.read_bytes())
        data[sc.HEADER.size + 4] ^= 0x20
        self.spc.write_bytes(data)
        with patch.object(sc, '_play_wav_windows') as player:
            with self.assertRaisesRegex(sc.SpeechError, 'CRC32'):
                self.call('-oc', self.spc, '--test', 'WORT')
            player.assert_not_called()

    def test_bad_gzip_with_valid_crc_is_rejected(self):
        # Use public data format API to store a fake gzip stream with valid CRC.
        payload = self.root / 'bad_payload.bin'
        payload.write_bytes(b'not-a-gzip-stream')
        entry = sc.Item('BAD', sc.CODECS['ima-adpcm'] | sc.CODEC_GZIP_FLAG,
                        1, 16000, 10, payload.stat().st_size,
                        zlib.crc32(payload.read_bytes()) & 0xffffffff, payload)
        sc.write_container(self.spc, {'bad':entry})
        with patch.object(sc, '_play_wav_windows') as player:
            with self.assertRaisesRegex(sc.SpeechError, 'GZIP'):
                self.call('-oc', self.spc, '--test', 'BAD')
            player.assert_not_called()

    def test_bad_adpcm_block_rejected(self):
        self.call(self.input_wav, '-oc', self.spc, '-a', 'WORT')
        entry = sc.read_container(self.spc)['wort']
        blob = bytearray(sc.read_sample_payload(self.spc, entry))
        at = blob.index(b'data') + 8
        blob[at+2] = 255  # out-of-range ADPCM step index
        payload = self.root / 'bad_adpcm.wav'
        payload.write_bytes(blob)
        invalid = sc.Item('BAD', sc.CODECS['ima-adpcm'], 1, self.rate, self.frames,
                          len(blob), zlib.crc32(blob)&0xffffffff, payload)
        other = self.root / 'bad.spc'
        sc.write_container(other, {'bad':invalid})
        with patch.object(sc, '_play_wav_windows') as player:
            with self.assertRaisesRegex(sc.SpeechError, 'Blockkopf'):
                self.call('-oc', other, '--test', 'BAD')
            player.assert_not_called()

    def test_mp3_ogg_uses_vlc_backend(self):
        for kind in ('mp3','ogg'):
            payload = self.root / f'raw.{kind}'
            payload.write_bytes(b'DUMMY-AUDIO')
            item = sc.Item('SONG', sc.CODECS[kind], 1, 16000, 16000,
                           len(payload.read_bytes()), zlib.crc32(payload.read_bytes()) & 0xffffffff,
                           payload)
            sc.write_container(self.spc, {'song':item})
            with patch.object(sc, '_play_vlc_audio') as player:
                self.call('-oc', self.spc, '--test', 'song', '--vlc', 'customvlc.exe')
                player.assert_called_once_with(b'DUMMY-AUDIO', sc.EXTENSIONS[kind], 'customvlc.exe')

    def test_test_mode_rejects_modifications(self):
        self.call(self.input_wav, '-oc', self.spc, '-a', 'WORT')
        before = self.spc.read_bytes()
        for addition in [('-d','WORT'),('--text','hi'),('-s',),('-gz',),
                         (str(self.input_wav),)]:
            with self.assertRaises(SystemExit) as cm:
                self.call('-oc', self.spc, '--test', 'WORT', *addition)
            self.assertEqual(cm.exception.code, 2)
        self.assertEqual(self.spc.read_bytes(), before)

    def test_test_works_with_list_verify(self):
        self.call(self.input_wav, '-oc', self.spc, '-a', 'WORT')
        with patch.object(sc, '_play_wav_windows') as player:
            self.call('-oc', self.spc, '--test', 'WORT', '--list', '--verify')
            player.assert_called_once()

if __name__ == '__main__':
    unittest.main(verbosity=2)
