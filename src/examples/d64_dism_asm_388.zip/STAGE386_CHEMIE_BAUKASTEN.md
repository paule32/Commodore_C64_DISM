# Stage 386 – Matrix-Kacheln und Chemie-Baukasten

**Basis:** `d64_dism_asm_385.zip`

## Matrix-Darstellung
- Alle Matrix-Beispielrechnungskacheln wurden von **242 auf 274 Pixel** erhöht (+32 Pixel).
- Die Parent-Kachel wird weiterhin vor dem Malen an die Kacheln angepasst.
- Bestehende Gleichungen, Farben und Matrixausrichtung bleiben unverändert.

## Chemie-Baukasten
- **Menü:** `Lernen → Chemie → Baukasten`. Das bestehende Periodensystem bleibt separat erhalten.
- Eigenes schließbares, verschiebbares und abdockbares Qt5-Docking-Fenster; volle Breite der freien Arbeitsfläche. Beim Schließen werden zuvor sichtbare IDE-Docks wiederhergestellt (gleiche Docklogik wie das Periodensystem).
- Auswählbar sind **40 reale Elemente**, Ordnungsnummern 1–40 (H bis Zr), mit Nummer, Symbol und Namen.
- Suche nach Ordnungszahl, Symbol, Name und Familie.
- Elemente können angeklickt oder via Drag & Drop auf die Reaktionsfläche gezogen werden.
- Zwei unterschiedliche Elemente werden als Eingaben unterstützt, Auswahl löschen/zurücknehmen.
- **24 hinterlegte Reaktionsbeispiele**; Darstellung als Verbindung mit Name, Summenformel und ausgeglichener Reaktionsgleichung. Dazu passende sofort auswählbare Beispiele.
- Bei unbekannten Elementpaaren keine erfundenen Verbindungen oder angeblich gesicherten Reaktionen.
- Unterstützt Dark- und Light-Modus ohne Bitmap-Assets.

**Fachhinweis:** Chemische Reaktionen erzeugen Verbindungen und verändern nicht die Elementidentität. Gleichungen im Baukasten sind ausschließlich Lehrbeispiele; das Mischen der Ausgangsstoffe ist keine sichere oder allgemein hinreichende reale Synthesemethode. Es werden keine Laboranleitungen geliefert.

### Quellcode
- `d64_dism.py`: Menüeintrag, Dock-Controller, Theme, Matrixhöhe.
- `chemistry_workbench.py`: PyQt5-Baukasten, 40 Elemente, Arbeitsfläche, Interaktion.
- `chemistry_model.py`: chemische Daten, Verbindungen, Reaktionsgleichungen und Bilanzprüfung (auch ohne PyQt5 testbar).
- `test_stage386_chemistry_workbench.py`: gezielte Tests.
