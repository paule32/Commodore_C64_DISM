# Stage 363 – Mathematik: Mehr Eingabegrößen, linksbündige Felder, verschiebbare Fehlerdialog-Titelleiste

**Verbindliche Basis:** `d64_dism_asm_362.zip`. Die bestehende Mathematik-Dock-Struktur,
QPainter-Zeichnungen und beide unabhängigen Einheitskreise bleiben erhalten.

## Layout

Unter den Flächen- und Volumenzeichnungen beginnen **Eingabefelder, Berechnen-Button
und schreibgeschütztes Ergebnisfeld** bei 10 px Abstand von der linken Kante der rechten Faktenansicht.
Die früher künstlich eingefügte linke Streckfläche wurde entfernt. Bis zu vier Felder
werden pro Zeile dargestellt; weitere Felder folgen darunter. Eingaben bleiben beim
Wechsel der Figur innerhalb der aktuellen Sitzung erhalten. Der Inhalt des Ergebnisfelds
kann bei längeren Listen gescrollt werden; der vollständige Text steht auch im Tooltip.

## Ergänzte Größen und Berechnung

Alle **8 Flächen** und **11 Volumenkörper** verfügen über zusätzliche Eingabefelder.
Beispiele:

- Rechteck: Länge `a`, Breite `b`, Fläche `A`, Umfang `U`, Diagonale `d`.
- Quadrat: Seite, Fläche, Umfang, Diagonale.
- Dreieck: Grundseite, Höhe, drei Seiten, Fläche, Umfang. Mit drei Seiten
  wird die Heron-Formel benutzt; die Grundseite `g` entspricht `c`.
- Kreis und Halbkreis: Radius, Durchmesser, Fläche und (beim Halbkreis inklusive
  gerader Durchmesserlinie) Umfang.
- Ellipse: Halbachsen, Fläche, Umfang mit Ramanujan-Näherung.
- Rhombus: Diagonalen, Seite, Höhe, Fläche, Umfang.
- Trapez: parallele Seiten, Schenkel, Höhe, Mittellinie, Fläche, Umfang.
- Würfel: Kantenlänge, Raumdiagonale, Grundfläche, Oberfläche, Volumen.
- Quader: Kantenmaße, Raumdiagonale, Grundfläche, Mantelfläche, Oberfläche, Volumen.
- Zylinder, Halbkugel, Kegel, Kegelstumpf, Pyramiden und Prisma: passende
  Größen einschließlich Grund-/Mantel-/Oberflächen und Volumen; die jeweiligen
  abhängigen Größen werden aus den vorhandenen Maßen berechnet.

Ein neuer gleichungsbasierter Rechenkern wendet sowohl Vorwärtsformeln als auch
algebraisch eindeutige Umstellungen an. **Nicht alle Felder müssen gefüllt werden.**
Zum Beispiel wird beim Rechteck aus `a=6` und `A=24` die Breite `b=4` berechnet;
aus `a=6` und `U=20` ebenfalls. Aus `a=3` und `d=5` folgt `b=4`.

Das Ergebnisfeld zeigt alle eindeutig **zusätzlich hergeleiteten** Größen, wobei
`A` bzw. `V` zuerst steht. Bei vollständigen, widerspruchsfreien Angaben kann
auch die eingegebene Fläche bzw. das Volumen bestätigt werden.
Fehlende Angaben, ungültige Dezimalzahlen, überbestimmte widersprüchliche
Werte oder physikalisch unmögliche Maße führen zum Fehlerdialog.
Es werden keine unbekannten Maße frei angenommen, wenn mehrere Lösungen
möglich wären (z.B. sind `a` und `b` allein aus `U` und `A` nicht etikettierbar).

Eingabefilter: nur Ziffern und höchstens ein Dezimalpunkt; Maße müssen positiv sein.

## Fehlerdialog

Der modale Dialog enthält weiterhin den exakten Text
`Daten Fehlen bzw. sind nicht gültig`, einen 3-Pixel-Rahmen, **OK** und **✕**.
Neu ist eine eigenständige 39-px-Titelleiste mit horizontalem Verlauf von
Schwarz nach Grau im Dark-Mode (heller Verlauf im Light-Mode). Die Titelleiste
reagiert auf linke Maustaste + Ziehen und verschiebt das rahmenlose Dialogfenster.
Beide Schließmöglichkeiten funktionieren unabhängig voneinander.

## Technische Änderungen

- `d64_dism.py`: `_GEOMETRY_INPUTS`, `_solve_geometry_fact`,
  `_calculate_geometry_fact` (kompatibler Rückgabetyp für bestehende Aufrufe),
  `GeometryCalculatorPanel`, `GeometryErrorTitleBar`, `GeometryDataErrorDialog`
  sowie `_add_geometry_fact_page`.
- `test_stage363_geometry_extra_inputs.py`: zusätzliche Funktions-, Formel-,
  Fehlerfall-, Layout- und Titelbalkenprüfungen.
- `test_stage362_geometry_calculator.py`: bestehende Regressionen an die neuen
  zusätzlichen Felder / responsive Rasteranordnung angepasst.

**Prüfumgebung:** Python 3.13 ohne PyQt5: die Geometrie-Funktionstests und
statischen Strukturprüfungen bestanden. In der breiten automatischen Test-Discovery
wurden 152 Tests ausgeführt: 150 erfolgreich, zwei Importfehler in den älteren
ANTLR-generierten Modulen `c64c` und `c64pascal` (unverträgliche Version des
vorhandenen `antlr4`-Python-Runtimes). Diese Fehler stehen nicht mit der
Geometrie-Erweiterung im Zusammenhang. Ein tatsächlicher PyQt5-GUI-Test auf
Windows muss separat erfolgen.
