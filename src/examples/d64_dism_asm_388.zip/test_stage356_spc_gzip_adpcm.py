"""Stage 356 integration tests: compressed SPC, native C WAV ADPCM decoder and dBase."""
import ctypes
import io
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
import wave
ROOT=Path(__file__).resolve().parent
TOOL=ROOT/'speechConvert.py'
SOURCE=Path('/mnt/data/du.wav')

@unittest.skipUnless(shutil.which('gcc'),'Native GCC needed')
class SpcNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='spc_native_')
        cls.dir=Path(cls.temp.name)
        cls.dll_path=cls.dir/'speech.so'
        subprocess.run(['gcc','-O2','-std=c99','-Wall','-Wextra','-Werror',
                        '-shared','-fPIC',str(ROOT/'speech/retro_speech.c'),'-lm',
                        '-o',str(cls.dll_path)],check=True)
        cls.lib=ctypes.CDLL(str(cls.dll_path))
        cls.lib.SpeechInitialize.argtypes=[ctypes.c_int32]
        cls.lib.SpeechInitialize.restype=ctypes.c_int32
        cls.lib.SpeechLoadContainer.argtypes=[ctypes.c_char_p]
        cls.lib.SpeechLoadContainer.restype=ctypes.c_int32
        cls.lib.SpeechGetContainerEntryCount.restype=ctypes.c_int32
        cls.lib.SpeechGetContainerEntryName.argtypes=[ctypes.c_int32]
        cls.lib.SpeechGetContainerEntryName.restype=ctypes.c_char_p
        cls.lib.SpeechUnloadContainer.restype=ctypes.c_int32
        cls.lib.SpeechRenderSample.argtypes=[ctypes.c_char_p,ctypes.POINTER(ctypes.c_int16),ctypes.c_uint32]
        cls.lib.SpeechRenderSample.restype=ctypes.c_uint32
        cls.lib.SpeechGetLastSampleRate.restype=ctypes.c_int32
        cls.lib.SpeechSetBackend.argtypes=[ctypes.c_int32]
        cls.lib.SpeechSetBackend.restype=ctypes.c_int32
        cls.lib.SpeechSaveWav.argtypes=[ctypes.c_char_p,ctypes.c_char_p]
        cls.lib.SpeechSaveWav.restype=ctypes.c_int32
        cls.lib.SpeechGetLastError.restype=ctypes.c_int32
        cls.lib.SpeechGetLastErrorText.restype=ctypes.c_char_p

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def setUp(self):
        self.lib.SpeechInitialize(22050)
        self.lib.SpeechUnloadContainer()
        self.lib.SpeechSetBackend(0)

    def tool(self,*args,expect_ok=True):
        r=subprocess.run([sys.executable,str(TOOL),*map(str,args)],text=True,capture_output=True)
        if expect_ok:self.assertEqual(r.returncode,0,r.stderr+r.stdout)
        else:self.assertNotEqual(r.returncode,0)
        return r

    def sample(self,name=b'du'):
        needed=self.lib.SpeechRenderSample(name,None,0)
        if not needed:return None
        dst=(ctypes.c_int16*needed)()
        self.assertEqual(self.lib.SpeechRenderSample(name,dst,needed),needed)
        return bytes(dst)

    def load(self,p):
        self.assertEqual(self.lib.SpeechLoadContainer(os.fsencode(p)),1,self.lib.SpeechGetLastErrorText())

    def test_adpcm_decode_plain_and_gzip_identical(self):
        a=self.dir/'a_plain.spc'; b=self.dir/'b_gzip.spc'
        self.tool(SOURCE,'-s','-oc',a,'-a','DU','--verify')
        self.tool(SOURCE,'-s','-oc',b,'-a','DU','-gz','--verify')
        self.assertLess(b.stat().st_size,a.stat().st_size)
        self.load(a)
        pcm1=self.sample(b'DU')
        self.assertEqual(len(pcm1),5888*2)
        self.assertEqual(self.lib.SpeechGetLastSampleRate(),16000)
        self.assertGreater(max(abs(x) for x in struct.unpack('<5888h',pcm1)),300)
        self.load(b)
        pcm2=self.sample(b'du')
        self.assertEqual(pcm1,pcm2)
        self.assertEqual(self.lib.SpeechGetContainerEntryCount(),1)
        self.assertEqual(self.lib.SpeechGetContainerEntryName(0),b'DU')

    def test_pcm16_wav_sample(self):
        p=self.dir/'pcm.spc'
        self.tool(SOURCE,'-s','-c','pcm','-oc',p,'-a','DU','-gz')
        self.load(p)
        pcm=self.sample()
        with wave.open(str(SOURCE),'rb') as src:
            raw=src.readframes(src.getnframes())
        self.assertEqual(pcm,raw[:len(pcm)])

    def test_spoken_words_wav_output(self):
        p=self.dir/'phrase.spc'; wav=self.dir/'phrase.wav'
        self.tool(SOURCE,'-s','-oc',p,'-a','DU','-gz')
        self.load(p)
        self.assertEqual(self.lib.SpeechSetBackend(2),1)
        self.assertEqual(self.lib.SpeechSaveWav(os.fsencode(wav),b'Du, DU!'),1,
                         self.lib.SpeechGetLastErrorText())
        with wave.open(str(wav),'rb') as out:
            self.assertEqual(out.getframerate(),16000)
            self.assertEqual(out.getsampwidth(),2)
            self.assertEqual(out.getnframes(),5888*2+400)
        self.assertEqual(self.lib.SpeechSaveWav(os.fsencode(wav),b'unbekannt'),0)
        self.assertEqual(self.lib.SpeechGetLastError(),9)
        self.assertIn(b'missing',self.lib.SpeechGetLastErrorText())

    def test_crc_corruption_and_truncated_container_rejected(self):
        p=self.dir/'corrupt.spc'
        self.tool(SOURCE,'-s','-oc',p,'-a','DU','-gz')
        raw=bytearray(p.read_bytes());raw[37]^=0x01;p.write_bytes(raw)
        self.load(p)
        self.assertEqual(self.lib.SpeechRenderSample(b'du',None,0),0)
        self.assertEqual(self.lib.SpeechGetLastError(),9)
        broken=self.dir/'bad.spc';broken.write_bytes(bytes(raw[:30]))
        self.assertEqual(self.lib.SpeechLoadContainer(os.fsencode(broken)),0)
        self.assertEqual(self.lib.SpeechGetLastError(),9)

    def test_backwards_compat_existing_container(self):
        p=Path('/mnt/data/deutsch_demo.spc')
        self.load(p)
        self.assertEqual(self.lib.SpeechGetContainerEntryCount(),1)
        self.assertEqual(len(self.sample(b'DU')),5888*2)

    def test_cli_gzip_requires_container_and_survives_delete_batch(self):
        self.tool(SOURCE,'--gzip',expect_ok=False)
        p=self.dir/'batch.spc';batch=self.dir/'batch.txt';batch.write_text(f'"{SOURCE}" S A\n')
        self.tool('@'+str(batch),'-oc',p,'-gz')
        self.load(p);self.assertIsNotNone(self.sample())
        self.tool('-oc',p,'-d','du','--verify')
        self.load(p);self.assertEqual(self.lib.SpeechGetContainerEntryCount(),0)

    def test_dbase_samples_mode_independent_from_piper(self):
        from d64dbase.compiler import compile_dbase_to_assembly
        asm=compile_dbase_to_assembly('SET SPEECH MODE SAMPLES\nSET SPEECH ON\nSAY "Du"',target='pe32').assembly
        self.assertIn('    mov dword ptr [__dbase_speech_backend], 2',asm)
        asm=compile_dbase_to_assembly('SET SPEECH MODE PIPER\nSET SPEECH ON\nSAY "Du"',target='pe32').assembly
        self.assertIn('    mov dword ptr [__dbase_speech_backend], 1',asm)

if __name__=='__main__':unittest.main(verbosity=2)
