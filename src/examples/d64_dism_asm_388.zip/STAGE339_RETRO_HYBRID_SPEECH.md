# Stage 339 – Retro-Hybrid-Phonemsynthesizer

Basis: d64_dism_asm_338.zip.

Neue eigenstaendige Runtime in `speech/`:
- `retro_speech.c/.h`: deutsche UTF-8-Eingabe, einfache Lexikon-/Regel-basierte
  Phonemzuordnung, 3 Formantresonatoren, Rausch-/Impulsanregung, Mischung
  C64-artiger 8-Bit-Rauheit und Amiga-artiger geglaetteter PCM-Ausgabe.
- `retro_speech_demo.c`: dynamisch gegen DLL gelinkte Win32-Konsolendemo.
- `build_pe32.py`: MinGW32 DLL + Importbibliothek + EXE ohne make.
- WAV-Export und direkter Phonemmodus fuer den Test.
- `test_stage339_retro_speech.py`: lokale C99-Tests und RIFF/Audio-Pruefung.

Die DLL selbst wird ausschliesslich von MinGW32 erstellt; dBase-Compiler
und d64_dism-Assembler werden in dieser Stufe **nicht** modifiziert. Die
spaetere dBase-ABI wird durch dokumentierte C-stdcall-Exporte vorbereitet.

Validierung in Linux moeglich; ein natives Windows-PE32-Binary kann ohne
32-Bit-MinGW-Cross-Toolchain hier nicht gebaut werden. Kein Windows-Abspieltest.
