# Stage 369 – Vorhandene Rechengesetze umsortiert

**Verbindliche Grundlage:** Stage 368 (`d64_dism_asm_368.zip`).

## Gewünschte Baumstruktur

```text
Fakten
└── Grundwissen
    ├── Rechengesetze
    │   ├── Grundrechen-Arten
    │   │   └── Punkt- vor Strich-Rechnung
    │   ├── Teilbarkeit
    │   │   └── Brüche (mit ihren bisherigen vier Unterblättern)
    │   └── Potenzen
    │       ├── Kommutativ-Gesetz
    │       ├── Assoziativ-Gesetz Addition
    │       ├── Assoziativ-Geset Multiplikation
    │       └── Distributiv-Gesetz
    ├── Algebra
    │   └── Zinsrechnung
    └── Geometrie
        ├── Flächen
        └── Volumen
```

Die fünf zuvor auf der Sammelseite `Rechengesetze` sichtbaren Zeilen wurden **ohne
neue mathematische Inhalte** auf die neuen Positionen verteilt. Das redundante
Einzelblatt `Rechengesetze` unter dem gleichnamigen Hauptknoten ist entfernt.
Das gewünschte Label `Assoziativ-Geset Multiplikation` ist wörtlich übernommen.

`Grundrechen-Arten` und `Potenzen` können weiterhin unabhängig von ihren
Unterblättern mit Doppelklick geöffnet werden. Die früheren Merkkarten und die
Potenzenformeln bleiben unverändert. Der nicht mehr sichtbare Schlüssel
`calculation_rules` bleibt aus Kompatibilitätsgründen im QPainter-Router für
ältere direkte Aufrufer verfügbar.

## Umsetzung

- `d64_dism.py`: `MathematicsLearningDockWidget._populate_facts_tree`
- `d64_dism.py`: `MathematicsLearningDockWidget.open_fact`
- `d64_dism.py`: `BasicMathRulesFactWidget.RELOCATED_LAWS`, `paintEvent`
- Angepasste Alt-Regressionen: `test_stage364_math_interest.py`,
  `test_stage367_math_rules_widget_init.py`
- Neu: `test_stage369_reorder_math_laws.py`

## Prüfstatus

- Python `py_compile`: erfolgreich
- 52 gezielte Mathematik-, England-Karten- und Bruchhilfe-Tests: erfolgreich
- ZIP `testzip`: erfolgreich
- Tatsächlicher Windows-/PyQt5-GUI-Test: nicht verfügbar, offen
