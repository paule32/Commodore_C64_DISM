# Stage 351 – Frankreich: Nebenflüsse im Overlay und dynamische Einblendung

Basis: Stage 350 (`d64_dism_asm_350.zip`)

## Ziel
Die Frankreich-Flusskarte wurde erweitert, so dass beim Überfahren eines Flusses:

1. im Overlay zusätzlich die **Nebenflüsse** des gewählten Flusses erscheinen,
2. die **Nebenflüsse auch optisch** auf der Karte eingeblendet werden,
3. beim Wechsel auf einen **anderen Fluss** die bisher eingeblendeten Nebenflüsse wieder ausgeblendet und durch die zum neuen Fluss passenden ersetzt werden.

## Umsetzung

### 1. Erweiterte Fluss-Metadaten (`france.py`)
Die Struktur `FRANCE_RIVER_HOVER_DATA` enthält jetzt zusätzlich je Hauptriver:
- `tributaries`: Liste von Nebenflüssen
  - `name`
  - `points` (normierte Koordinaten für die Darstellung und Hit-Tests)

Für folgende Flüsse wurden Nebenflüsse ergänzt:
- Seine
- Loire
- Garonne
- Dordogne
- Rhône
- Saône
- Rhein
- Maas
- Mosel

### 2. Overlay-Text
Das Hover-Overlay zeigt jetzt zusätzlich eine Zeile:
- `Nebenflüsse: ...`

### 3. Sichtbare Nebenfluss-Overlays
`FranceMapView` erzeugt jetzt separate `QGraphicsPathItem`-Overlays für Nebenflüsse:
- blaue Darstellung
- 3 Pixel Breite
- zunächst unsichtbar

Sobald ein Fluss aktiv ist, werden dessen Nebenflüsse sichtbar geschaltet.
Beim Wechsel auf einen anderen Fluss werden die bisher sichtbaren Nebenflüsse wieder verborgen.

### 4. Verbesserte Hover-Erkennung
Die Hover-Erkennung prüft jetzt nicht nur den Hauptfluss, sondern auch dessen Nebenflüsse.
Dadurch bleibt das Overlay aktiv, wenn man mit der Maus von einem Hauptfluss auf einen eingeblendeten Nebenfluss weiterfährt.

## Geänderte Dateien
- `d64_dism.py`
- `france.py`
- `STAGE351_FRANCE_TRIBUTARIES_HOVER.md`
