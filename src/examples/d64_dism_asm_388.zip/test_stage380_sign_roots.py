"""Stage 380: Sign laws, square root laws and card height."""
import unittest
import test_stage367_math_rules_widget_init as t
from pathlib import Path

class Stage380Tests(unittest.TestCase):
    def test_navigation(self):
        w=t.MathWidget()
        rules=w.facts_tree.children[0]._child_items[0]
        arithmetic=rules._child_items[0]
        signs=t.ctx['BasicMathRulesFactWidget'].SIGN_RULE_CARDS
        self.assertEqual(len(signs),8)
        self.assertEqual(arithmetic._child_items, [])
        self.assertEqual(rules._child_items[1].label, 'Punkt-vor-Strich-Rechnung')
        self.assertEqual(rules._child_items[2].label, 'Vorzeichen-Regeln')
        self.assertEqual(rules._child_items[5].label,'Wurzel-Gesetze')
        for key in ('sign_rules','root_rules'):
            with self.subTest(key=key):
                self.assertEqual(w._fact_items[key]._child_items,[])
                w.open_fact(key,key)
                self.assertIs(w.content_stack._current,w.basic_math_rules_scroll)
    def test_card_height_and_rules_in_source(self):
        source=Path(__file__).with_name('d64_dism.py').read_text('utf-8')
        self.assertIn('calc_h = 274.0',source)
        self.assertIn('def _paint_root_rules(',source)
        self.assertIn('def _paint_sign_rule(',source)
        self.assertIn("'√(a²) = |a|'",source)

if __name__=='__main__': unittest.main()
