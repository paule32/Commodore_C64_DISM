# Stage 364 – Mathematik: Grundwissen / Algebra / Geometrie / Zinsrechnung

**Verbindliche Grundlage:** `d64_dism_asm_363.zip`.

## Faktenbaum

```
Fakten
└─ Grundwissen
   ├─ Algebra
   │  └─ Zinsrechnung
   └─ Geometrie
      ├─ Flächen
      │  └─ 8 bisherige Flächenfiguren
      └─ Volumen
         └─ 11 bisherige Volumenkörper
```

Andere Faktenbereiche wie Zahlen, Cantor, Pascal Dreieck und Fibonacci Spirale bleiben separat bestehen.

## Darstellung / wichtige Korrektur

Zinsrechnung ist ausdrücklich **KEIN neues QDockWidget**. Ein Doppelklick auf
`Fakten -> Grundwissen -> Algebra -> Zinsrechnung` aktiviert rechts in
`MathematicsLearningDockWidget.content_stack` eine eigene
`InterestCalculationFactWidget`-Seite. Der linke Fakten-Baum bleibt erhalten.

Bei der Auswahl werden alle anderen momentan sichtbaren Dockingfenster,
einschließlich Protokoll, ausgeblendet. Das Mathematik-Dock nutzt die
verfügbare Fläche. Die zuvor sichtbaren zusätzlichen Docks werden beim Wechsel
zu einer anderen Fakten-/Spiele-Seite oder beim Schließen des Mathematik-Docks
wieder angezeigt. Der bereits vorhandene allgemeine Mathematik-Workspace
behält seine bisherigen Regeln für andere Inhalte.

Die Formeln werden mit nativen Qt5-Layouts, QFrame, QLabel, eigenen Bruchstrichen
und Light-/Dark-Mode-Kachelfarben aufgebaut, nicht als Pixelgrafik.
Bei schmalen Fenstern kann die rechte Seite horizontal gescrollt werden.

## Formeln

| Gesucht | Darstellung | Bedingung |
|---|---|---|
| Grundwert | G = (W / p) × 100 | p != 0 |
| Prozentwert | W = (G × p) / 100 | – |
| Prozentsatz | p = (W / G) × 100 | G != 0 |

Legende: Prozentsatz p (Anteil in Prozent), Grundwert G (das Ganze),
Prozentwert W (Teil des Ganzen).

## Beispielkarten

- **Prozentwert:** G = 30 €, W = ?, p = 40 %;
  100 % = 30 €, 1 % = 0,30 €, 40 % = 12,00 €.
- **Grundwert:** W = 15 €, p = 30 %, G = ?;
  30 % = 15 €, 1 % = 0,50 €, 100 % = 50 €.
- **Prozentsatz:** G = 50 €, W = 15 €, p = ?;
  100 % = 50 €, 2 % = 1 €, 30 % = 15 €.

Diese Stage stellt die vom Benutzer gewünschten **statischen Lernkacheln** dar;
interaktive Berechnungsfelder wurden hierfür nicht angefordert.

## Prüfungen

- Python-Syntaxprüfung (`python -m py_compile`): bestanden.
- 6 Stage-364-Prüfungen (Qt-Testdoubles, Baumhierarchie, Layoutinhalte,
  Dark-/Light-Konfiguration, Dock-Isolation, Restore): bestanden.
- Weitere Mathematik-Regressionen der Stages 360–363: bestanden.
- Vollständige gezielte Testmodul-Sammlung (`test_*.py`):
  157 Tests bestanden. Unittest discovery über *alle* Verzeichnisse wurde vermieden,
  weil die vorhandenen generierten ANTLR-Module in dieser Linux-Umgebung beim Import
  fehlschlagen (bekanntes Umgebungsproblem).
- **Keine echte PyQt5-Windows-GUI-Prüfung in dieser Umgebung** (PyQt5 fehlt).
