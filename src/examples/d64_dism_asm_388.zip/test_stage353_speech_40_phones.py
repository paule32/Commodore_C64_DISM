"""Stage 353: 40 new documented phonetic phones and their runtime behavior.

The tests compile a host shared library: they do not claim Windows waveOut
or MinGW32 PE32 runtime execution has been verified.
"""
import ctypes
import hashlib
import os
import shutil
import subprocess
import tempfile
import unittest
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "speech"
ADDED = (
    "A:", "E:", "I:", "O:", "U:", "AE:", "OE:", "UE:",
    "A0", "E0", "I0", "O0", "U0", "OE0", "UE0",
    "AN", "EN", "ON", "UN", "RY", "RX", "ER", "M=", "N=", "NG=",
    "TS", "TSH", "DSH", "PF", "ZH", "SHH", "SS", "TH", "DH", "WW", "NY",
    "PH", "THP", "KH", "GH",
)


@unittest.skipUnless(shutil.which("gcc"), "host C99 GCC required")
class Stage353SpeechTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="stage353_")
        cls.work = Path(cls.temp.name)
        cls.so = cls.work / "libretro353.so"
        subprocess.run(
            ["gcc", "-O2", "-std=c99", "-Wall", "-Wextra", "-Werror",
             "-fPIC", "-shared", str(SRC / "retro_speech.c"), "-lm", "-o", str(cls.so)],
            capture_output=True, text=True, check=True,
        )
        cls.dll = ctypes.CDLL(str(cls.so))
        cls.dll.SpeechInitialize.argtypes = [ctypes.c_int32]
        cls.dll.SpeechInitialize.restype = ctypes.c_int32
        cls.dll.SpeechSetSpeed.argtypes = [ctypes.c_int32]
        cls.dll.SpeechSetSpeed.restype = ctypes.c_int32
        cls.dll.SpeechGetPhonemeCount.restype = ctypes.c_int32
        cls.dll.SpeechGetPhonemeToken.argtypes = [ctypes.c_int32]
        cls.dll.SpeechGetPhonemeToken.restype = ctypes.c_char_p
        cls.dll.SpeechGetLastError.restype = ctypes.c_int32
        for name in ("SpeechRenderText", "SpeechRenderPhonemes"):
            fn = getattr(cls.dll, name)
            fn.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_int16), ctypes.c_uint32]
            fn.restype = ctypes.c_uint32
        for name in ("SpeechSaveWav", "SpeechSavePhonemesWav"):
            fn = getattr(cls.dll, name)
            fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
            fn.restype = ctypes.c_int32

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        self.assertEqual(self.dll.SpeechInitialize(22050), 1)
        self.assertEqual(self.dll.SpeechSetSpeed(100), 1)

    def _pcm(self, token, fn="SpeechRenderPhonemes"):
        if isinstance(token, str):
            token = token.encode("utf-8")
        render = getattr(self.dll, fn)
        samples = render(token, None, 0)
        self.assertGreater(samples, 0, token)
        pcm = (ctypes.c_int16 * samples)()
        self.assertEqual(render(token, pcm, samples), samples)
        return bytes(pcm)

    def test_exactly_forty_unique_extra_tokens(self):
        self.assertEqual(len(ADDED), 40)
        all_tokens = [self.dll.SpeechGetPhonemeToken(i).decode("ascii")
                      for i in range(self.dll.SpeechGetPhonemeCount())]
        self.assertEqual(len(all_tokens), 81)  # stage 352 had 41 entries
        self.assertEqual(len(set(all_tokens)), len(all_tokens))
        self.assertEqual(tuple(all_tokens[41:]), ADDED)
        self.assertEqual(set(ADDED) & set(all_tokens[:41]), set())

    def test_each_new_sound_renders_real_pcm(self):
        hashes = set()
        for token in ADDED:
            sound = self._pcm(token)
            self.assertGreater(len(sound), 500, token)
            self.assertNotEqual(sound, b"\x00" * len(sound), token)
            hashes.add(hashlib.sha256(sound).hexdigest())
        self.assertEqual(len(hashes), 40)

    def test_long_short_vowels_are_different_lengths(self):
        for long_token, short_token in [("A:", "A0"), ("E:", "E0"),
                                         ("I:", "I0"), ("O:", "O0"), ("U:", "U0"),
                                         ("OE:", "OE0"), ("UE:", "UE0")]:
            self.assertGreater(len(self._pcm(long_token)), len(self._pcm(short_token)))

    def test_unknown_token_and_enumeration_bounds_are_checked(self):
        self.assertIsNone(self.dll.SpeechGetPhonemeToken(-1))
        self.assertEqual(self.dll.SpeechGetLastError(), 1)
        self.assertIsNone(self.dll.SpeechGetPhonemeToken(81))
        self.assertEqual(self.dll.SpeechGetLastError(), 1)
        self.assertEqual(self.dll.SpeechRenderPhonemes(b"NO_SUCH_PHONE", None, 0), 0)
        self.assertEqual(self.dll.SpeechGetLastError(), 2)

    def test_new_graphemes_affect_auto_transcription(self):
        phrases = ["Pfanne", "Deutsch", "Dschungel", "schön", "grün",
                   "ziehen", "sehen", "Katze", "Äpfel", "Hallo, ich bin dein Sprachcomputer."]
        for phrase in phrases:
            with self.subTest(text=phrase):
                self.assertGreater(len(self._pcm(phrase, "SpeechRenderText")), 0)
        # The newly single-segment affricate is deliberately not identical to P F.
        self.assertNotEqual(self._pcm("PF"), self._pcm("P F"))

    def test_phoneme_wav_and_demo_command_line(self):
        path = self.work / "new_phones.wav"
        self.assertEqual(self.dll.SpeechSavePhonemesWav(os.fsencode(path), b"PF A0 N @ _ DSH U0 NG @ L"), 1)
        with wave.open(str(path), "rb") as f:
            self.assertEqual((f.getnchannels(), f.getframerate(), f.getsampwidth()), (1, 22050, 2))
            self.assertGreater(f.getnframes(), 1000)
        exe = self.work / "retro353demo"
        subprocess.run(["gcc", "-O2", "-std=c99", "-Wall", "-Wextra", "-Werror",
                        str(SRC / "retro_speech_demo.c"), "-L" + str(self.work),
                        "-lretro353", "-o", str(exe)], check=True, capture_output=True)
        env = dict(os.environ, LD_LIBRARY_PATH=str(self.work))
        listing = subprocess.run([str(exe), "--list-phonemes"], capture_output=True,
                                 text=True, check=True, env=env).stdout
        for token in ADDED:
            self.assertIn(token, listing.split())
        wavfile = self.work / "commandline.wav"
        subprocess.run([str(exe), "--no-play", "--phonemes", "PF A0 N @ _ DSH U0 NG @ L",
                        "--wav", str(wavfile)], capture_output=True, check=True, env=env)
        with wave.open(str(wavfile), "rb") as f:
            self.assertGreater(f.getnframes(), 1000)


if __name__ == "__main__":
    unittest.main(verbosity=2)
