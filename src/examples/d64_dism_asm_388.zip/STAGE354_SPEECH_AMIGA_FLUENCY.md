# Stage 354 – Amiga-orientierte, flüssigere Retro-Sprachausgabe

**Verbindliche Basis:** `d64_dism_asm_353.zip`.

## Ziel

Die experimentelle Retro-Synthese aus Stage 353 klang bruchstückhaft. Bei
normalem Text stand zuvor **zwischen beinahe jedem Wort eine zusätzliche
36-ms-Silbe bzw. Stille**. Außerdem wurden bestimmte Lautübergänge zu stark
abgeschwächt, obwohl die Lautkette innerhalb eines Wortes weiterging.

## Technische Änderungen

### Neue Prosodie/Audioerzeugung in `speech/retro_speech.c`

- Ein Leerzeichen markiert nur noch die **Wortgrenze**. Es erzwingt keine
  künstliche 36-ms-Pause; Kommata und echte Satzzeichen erhalten ihre
  eigenen Pausen.
- Die Formantparameter werden **sowohl am Anfang als auch am Ende** eines
  Lautsegments mit Nachbarlauten überblendet (Coartikulation).
- Die Hüllkurve wird nur noch an echten Stillegrenzen deutlich abgesenkt,
  nicht bei jedem Wechsel zwischen stimmhaften und stimmlosen Lauten.
- Ergänzter weicherer, harmonischer Anregungsanteil für Amiga-orientierte
  Stimmen; C64-Anteil und 81 vorhandene Lauttokens bleiben erhalten.
- Verschlusslautimpulse und Wortakzente sind weniger überzeichnet.
- Neue Funktion `SpeechSetFluency(0..100)` (Vorgabe `75`), welche die
  Übergangsglättung und den weicheren Stimmanregungsanteil steuert.

### Erweiterter Wortschatz

- **199 verschiedene Wörterbucheinträge** mit festen Aussprachefolgen,
  z. B. wichtige deutsche Funktionswörter, Computerbegriffe,
  häufige Verben und Redewendungen.
- Aussprachen sind **Regeln und Phonemfolgen**, keine Samples oder
  nachgebildeten originalen Amiga-Narrator-Sprachdaten.
- Unbekannte Wörter verwenden weiterhin die Graphem-zu-Phonem-Regeln.

### dBase-Anbindung

Unter PE32 stehen zusätzlich zur bisherigen Syntax zur Verfügung:

```dbase
SET SPEECH ON
SET SPEECH MODE AMIGA
SET SPEECH FLUENCY 100
SET SPEECH ARTICULATION 35
SET SPEECH EXPRESSION 80
SAY "Guten Morgen. Willkommen beim Amiga."
```

`SET SPEECH MODE C64/HYBRID/AMIGA` setzt jetzt auch die passenden
Flüssigkeitswerte (25/75/100). Die zugehörigen Sprach-DLL-Imports werden nur
in Programmen verwendet, die Sprachbefehle enthalten. `retro_speech.dll`
muss **neu gebaut** und neben die erzeugte EXE gestellt werden.

### Demo-CLI

```sh
cd speech
python build_pe32.py
./bin/retro_speech_demo.exe --preset amiga --fluency 100 \
    --text "Guten Morgen. Ich bin dein Sprachcomputer."
```

Presets: `c64` (kantiger), `hybrid` (balanciert), `amiga` (weicher).
Die neue Demo-Option heißt `--fluency 0..100`.

## Messbarer Effekt / Grenzen

Ein identischer, ungepunkteter Vergleichssatz hatte in Stage 353 mehrere
36-ms-Leerstellen, in Stage 354 gibt es diese künstlichen Wortpausen nicht
mehr. Dies belegt eine **technische Kontinuitätsverbesserung**, aber keine
subjektiv garantierte Sprachqualität.

Es handelt sich weiterhin um eine bewusst synthetische, selbst geschriebene
Formantengine. Dies ist **keine Emulation** der historischen Amiga-Narrator-
Algorithmen. Für wirklich natürliche Prosodie sind zukünftig umfangreichere
Aussprachelexika, Silbentrennung, kontextabhängige Dauerregeln und
Resonanz-/Nasalmodelle nötig.

## Tests

- `python -m unittest -q test_stage354_speech_amiga_fluency`
- `python -m unittest -q test_stage339_retro_speech test_stage340_speech_pe32_imports test_stage341_speech_finetune test_stage342_dbase_speech test_stage343_speech_ordinal_compat test_stage353_speech_40_phones`
- `gcc -O2 -std=c99 -Wall -Wextra -Werror -shared -fPIC speech/retro_speech.c -lm ...`
- Windows-/MinGW32-PE32-Build und Lautsprecherwiedergabe stehen weiterhin aus.
