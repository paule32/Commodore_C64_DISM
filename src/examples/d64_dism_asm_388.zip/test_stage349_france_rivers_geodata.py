"""Stage 349: geographic, unsmoothed French river SVG, Qt-independent tests."""
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import unittest
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parent
SOURCE=(ROOT/'d64_dism.py').read_text(encoding='utf-8')
META=json.loads((ROOT/'STAGE349_GEOGRAPHIC_RIVER_METADATA.json').read_text(encoding='utf-8'))
SVG_BYTES=(ROOT/'france_rivers_overlay.svg').read_bytes()
SVG=SVG_BYTES.decode('utf-8')

class Stage349FranceRiverTests(unittest.TestCase):
    def test_svg_not_handdrawn_spline(self):
        tree=ET.fromstring(SVG)
        ns='{http://www.w3.org/2000/svg}'
        self.assertEqual(tree.get('viewBox'), '0 0 1254 1254')
        group=tree.find(ns+'g')
        self.assertEqual(group.get('stroke'),'#0066ff')
        self.assertEqual(group.get('stroke-width'),'2')
        paths=group.findall(ns+'path')
        self.assertEqual(len(paths), META['segment_count_clipped'])
        self.assertGreater(len(paths),200)
        for p in paths:
            d=p.attrib['d']
            self.assertTrue(d.startswith('M '))
            self.assertIsNone(re.search(r'[CcSsQqTtAaZz]',d))
            self.assertGreaterEqual(d.count('L'),1)
        self.assertGreater(META['vertex_count'],5000)

    def test_embedded_svg_same_as_standalone(self):
        spec=importlib.util.spec_from_file_location('france_stage349',ROOT/'france.py')
        mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        self.assertEqual(base64.b85decode(mod.FRANCE_RIVER_OVERLAY_SVG_B85),SVG_BYTES)
        self.assertEqual(hashlib.sha256(SVG_BYTES).hexdigest(),META['svg_sha256'])
        self.assertEqual(mod.FRANCE_MAP_WIDTH,1254)
        self.assertEqual(mod.FRANCE_MAP_HEIGHT,1254)

    def test_geographic_source_and_city_registration(self):
        self.assertIn('WDBII', META['source'])
        self.assertEqual(META['source_crs'],'EPSG:4326')
        self.assertEqual(len(META['control_points']),12)
        self.assertGreater(META['segment_count_raw'],META['segment_count_clipped'])
        self.assertIn('approximate',META['cartographic_limitation'])
        self.assertTrue((ROOT/'licenses/GSHHG_LGPL3_COPYING_LESSER.txt').is_file())

    def test_map_loaded_once_rivers_only_for_river_dock(self):
        self.assertIn('QGraphicsSvgItem()',SOURCE)
        self.assertIn('show_rivers=True',SOURCE)
        self.assertIn('show_rivers=False',SOURCE)
        self.assertIn('FranceMapView',SOURCE)
        self.assertNotIn('FRANCE_RIVER_PATHS',SOURCE)
        self.assertIn('loaded.FRANCE_RIVER_OVERLAY_SVG_B85 = b""',SOURCE)
        self.assertIn('Das Frankreich-Fluss-Overlay benötigt PyQt5.QtSvg',SOURCE)
        self.assertIn('Frankreich -> Flüsse',SOURCE)
        self.assertIn('Frankreich -> Landkarte',SOURCE)

if __name__=='__main__':
    unittest.main()
