# Stage 330 – Wiederholungsvorschau für Custom Brush

Verbindliche Basis: `d64_dism_asm_329(1).zip`.

## Erweiterung

- Rechts unter der 32-Farben-Palette: festes Vorschau-Widget `d64CustomBrushRepeatPreview`.
- Vorschaugröße: genau 128 × 128 Bildpixel (ohne Zoom oder Gitternetz).
- Für jeden Ausgabepixel (x,y) wird der Quellpixel `(x % width, y % height)` verwendet.
- Die Musterwiederholung erfolgt lückenlos entlang beider Achsen.
- Vorschau aktualisiert sich beim Zeichnen im Gitter, Ändern von Palettenfarben und Laden einer JSON-Datei.
- Die existierende JSON-Struktur und Formular-Brush-Anbindung bleiben unverändert.

## Tests

- `python test_stage330_custom_brush_repeat.py -v` – 3 Tests erfolgreich.
- `python -m py_compile d64_custom_brush.py d64_dism.py` – erfolgreich.
- PyQt5 ist in der Testumgebung nicht installiert: tatsächlicher GUI-Laufzeittest unter Windows ausstehend.
- Breite/heh Höhe des Musters 1 bis 128, wie in Stage 329; die Vorschau hat stets 128x128.
