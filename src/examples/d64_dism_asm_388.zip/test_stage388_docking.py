"""Stage 388: isolated lifecycle tests (Qt5 is not available in this runner)."""
from pathlib import Path
import ast
from types import SimpleNamespace
from typing import Optional

SRC = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
TREE = ast.parse(SRC)
QT_CLASSES = [n for n in ast.walk(TREE) if isinstance(n, ast.ClassDef)]
EXPLORER = next(n for n in QT_CLASSES if n.name == 'ExplorerWindow')
DOCK_CLS = next(n for n in QT_CLASSES if n.name == 'C64ToolEditorDock')

for name in ('C64CharacterEditorDialog','C64PaletteEditorDialog', 'C64TextScreenEditorDialog', 'C64PixelScreenEditorDialog', 'ResourceBuilderToolWindow'):
    node = next(n for n in QT_CLASSES if n.name == name)
    assert node.bases[0].id == 'QWidget', name

method_names = ('_show_c64_tool_dock','_c64_tool_dock_destroyed','show_character_editor','show_palette_editor','show_text_screen_editor','show_pixel_screen_editor', 'resource_dialog')
methods = [n for n in EXPLORER.body if isinstance(n, ast.FunctionDef) and n.name in method_names]
assert len(methods) == len(method_names)

class Signal:
    def __init__(self): self.slots = []
    def connect(self, slot): self.slots.append(slot)
    def disconnect(self): self.slots.clear()
    def emit(self, *args):
        for slot in self.slots: slot(*args)

class Widget:
    def __init__(self, *args, **kwargs):
        self.windowTitleChanged = Signal()
        self._title = self.__class__.__name__
        self.current_path = None
        self.load_calls = []
        self.close_button = SimpleNamespace(clicked=Signal())
        self._allow = True
    def load_file(self, path):
        self.load_calls.append(path)
        if not self._allow: return False
        self.current_path = Path(path)
        return True
    def windowTitle(self): return self._title
    def setMinimumSize(self, *args): pass
    def setSizePolicy(self, *args): pass
    def setFocus(self, *args): pass
    def _confirm_discard(self): return self._allow
    def deleteLater(self): pass

class AliasWidget(Widget):
    pass

class Dock:
    class _Features:
        pass
    def __init__(self, title, main):
        self.editor_widget = None
        self.destroyed = Signal()
        self._is_visible = False
    def setObjectName(self, *args): pass
    def setFeatures(self, *args): pass
    def setAllowedAreas(self, *args): pass
    def setSizePolicy(self, *args): pass
    def setMinimumSize(self, *args): pass
    def setWidget(self, *args): pass
    def setWindowTitle(self, *args): pass
    def setTitleBarWidget(self, *args): pass
    def setAttribute(self, *args): pass
    def show(self): self._is_visible = True
    def raise_(self): pass
    def isFloating(self): return False
    def close(self):
        event=SimpleNamespace(ignore=lambda: None, accept=lambda: None)
        self.closeEvent(event)
        return not self._is_visible
    def closeEvent(self, event):
        self._is_visible = False
        self.destroyed.emit(None)

class Scroll:
    def __init__(self, parent): pass
    def setObjectName(self, *args): pass
    def setWidgetResizable(self, *args): pass
    def setFrameShape(self, *args): pass
    def setSizePolicy(self, *args): pass
    def setMinimumSize(self, *args): pass
    def setWidget(self, *args): pass

class QFake:
    LeftDockWidgetArea = 1
    RightDockWidgetArea = 2
    TopDockWidgetArea = 4
    BottomDockWidgetArea = 8
    WA_DeleteOnClose = 9
    OtherFocusReason = 10

class Scope:
    Expanding = 1
    Ignored = 2

ns = dict(QDockWidget=Dock, QCloseEvent=object, QScrollArea=Scroll,
          Qt=QFake, QFrame=SimpleNamespace(NoFrame=0), QSizePolicy=Scope,
          Optional=Optional, Path=Path,
          C64CharacterEditorDialog=Widget, C64PaletteEditorDialog=Widget,
          C64TextScreenEditorDialog=Widget, C64PixelScreenEditorDialog=Widget,
          ResourceBuilderToolWindow=AliasWidget,
          DockTitleBar=lambda dock: None)
exec(compile(ast.fix_missing_locations(ast.Module(body=[DOCK_CLS], type_ignores=[])), 'stage388', 'exec'), ns)
exec(compile(ast.fix_missing_locations(ast.Module(body=methods, type_ignores=[])), 'stage388', 'exec'), ns)

class Window:
    _c64_tool_docks = None
    def __init__(self):
        self._c64_tool_docks = {}
        self.current_directory=Path('.')
        self.status_msgs=[]
    def _dock_features(self): return 7
    def addDockWidget(self, *args): pass
    def _assign_widget_property_ids(self, *args): pass
    def statusBar(self): return SimpleNamespace(showMessage=self.status_msgs.append)
    _show_c64_tool_dock = ns['_show_c64_tool_dock']
    _c64_tool_dock_destroyed = ns['_c64_tool_dock_destroyed']
    show_character_editor = ns['show_character_editor']
    show_palette_editor = ns['show_palette_editor']
    show_text_screen_editor = ns['show_text_screen_editor']
    show_pixel_screen_editor = ns['show_pixel_screen_editor']
    resource_dialog = ns['resource_dialog']

ns['C64ToolEditorDock'] = ns['C64ToolEditorDock']
w=Window()
# All 5 tools create QDocks with a QWidget as content.
for kind in ('characters','palettes','text_screen','pixel_screen','alias_builder'):
    assert w._show_c64_tool_dock(kind)
    assert kind in w._c64_tool_docks
assert len(w._c64_tool_docks) == 5
# Opening same path does not reload and leaves unsaved edits intact.
p1=Path('/tmp/a.chr'); p2=Path('/tmp/b.chr')
w.show_character_editor(initial_path=p1)
e=w.character_editor_dialog
assert len(e.load_calls)==1
w.show_character_editor(initial_path=p1)
assert len(e.load_calls)==1
# Failed/cancelled load must not replace the open edit.
e._allow=False
w.show_character_editor(initial_path=p2)
assert e.current_path==p1
# Dock close via custom title bar is vetoed if dirty editor says Cancel.
dock=w._c64_tool_docks['characters']
assert not dock.close()
assert 'characters' in w._c64_tool_docks
e._allow=True
assert dock.close()
assert 'characters' not in w._c64_tool_docks
assert w.character_editor_dialog is None
w.show_character_editor(initial_path=p2)
assert w.character_editor_dialog is not e
# Editors' close buttons all close their owning dock.
w.palette_editor_dialog.close_button.clicked.emit()
assert 'palettes' not in w._c64_tool_docks
# Alias builder route is docked and reusable, not exec_().
w.resource_dialog()
assert 'alias_builder' in w._c64_tool_docks
print('Stage 388: structural tests + 5 dock lifecycle / file-switch / cancel / close tests passed')
