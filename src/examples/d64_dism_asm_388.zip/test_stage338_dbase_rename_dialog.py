from pathlib import Path
import ast
s=Path(__file__).with_name('d64_dism.py').read_text(encoding='utf8')
ast.parse(s)
start=s.index('        def _begin_dbase_program_rename(')
end=s.index('        def _show_project_dbase_file_menu(', start)
seg=s[start:end]
assert 'QDialog(self)' in seg
assert 'dbaseProgramRenameInput' in seg
assert 'QLineEdit(old_name, dialog)' in seg
assert 'QPushButton("Ok", dialog)' in seg
assert 'QPushButton("Abbrechen", dialog)' in seg
assert 'cancel_button.clicked.connect(dialog.reject)' in seg
assert 'if dialog.exec_() == QDialog.Accepted:' in seg
assert 'self._commit_dbase_program_rename(item, name_edit.text(), old_name)' in seg
assert 'self._show_dbase_rename_collision_warning()' in seg
assert 'old_path.rename(target)' in seg
assert 'self._find_open_document(old_path)' in seg
assert 'self.save_project()' in seg
assert 'self.project_tree.editItem(item, 0)' not in seg
print('Stage 338: dialog/rename structural checks passed')
