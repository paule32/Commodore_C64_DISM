"""Stage 383: 37-Zahlenmuster als echten Times-New-Roman-Text anzeigen."""
import ast
from pathlib import Path
import unittest

import test_stage367_math_rules_widget_init as doubles

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)


class RecordingFont:
    created = []
    def __init__(self, family, point_size):
        self.family = family
        self.point_size = point_size
        self.italic = False
        self.bold = False
        type(self).created.append(self)
    def setItalic(self, value):
        self.italic = value
    def setBold(self, value):
        self.bold = value


def build_font_page():
    cls = next(n for n in ast.walk(TREE)
               if isinstance(n, ast.ClassDef) and n.name == 'MathMagic37FactWidget')
    module = ast.Module(body=[cls], type_ignores=[])
    ast.fix_missing_locations(module)
    ctx = dict(QWidget=doubles.Attr, QVBoxLayout=doubles.Attr,
               QFrame=doubles.Frame, QLabel=doubles.Attr,
               QFont=RecordingFont, Qt=doubles.Qt)
    exec(compile(module, 'math_magic_37_qt_doubles.py', 'exec'), ctx)
    return ctx['MathMagic37FactWidget']


class TestStage383(unittest.TestCase):
    def test_nine_equations_correct_and_not_bitmaps(self):
        page = build_font_page()()
        expected = [f'{n * 111} / ({n}+{n}+{n}) = 37' for n in range(1, 10)]
        self.assertEqual([label.args[0] for label in page.equation_labels], expected)
        for number in range(1, 10):
            self.assertEqual((number * 111) / (3 * number), 37)
        cls = next(n for n in ast.walk(TREE)
                   if isinstance(n, ast.ClassDef) and n.name == 'MathMagic37FactWidget')
        src = ast.get_source_segment(SOURCE, cls)
        self.assertNotIn('QPixmap(', src)
        self.assertNotIn('QImage(', src)
        self.assertNotIn('QPainter(', src)
        self.assertNotIn('setPixmap(', src)

    def test_font_family_and_copyable_text(self):
        page = build_font_page()()
        for label in page.equation_labels:
            (font,) = next(args for name, args, _ in label.calls if name == 'setFont')
            self.assertEqual((font.family, font.point_size), ('Times New Roman', 31))
            self.assertTrue(font.italic)
            self.assertTrue(font.bold)
            self.assertIn(('setTextInteractionFlags', (doubles.Qt.TextSelectableByMouse,), {}),
                          label.calls)
        (footer_font,) = next(args for name, args, _ in page.caption_label.calls if name == 'setFont')
        self.assertEqual(footer_font.family, 'Times New Roman')
        self.assertEqual(page.caption_label.args[0], 'THIS IS MAGIC')

    def test_navigation_opens_correct_fact_page_and_keeps_old_nodes(self):
        dock = doubles.MathWidget()
        self.assertEqual([node.label for node in dock.facts_tree.children][:3],
                         ['Grundwissen', 'Matrizen', 'Zahlen'])
        zahlen = dock.facts_tree.children[2]
        self.assertEqual([node.label for node in zahlen._child_items],
                         ['Wahrscheinlichkeit', 'Primzahlen', 'Lustiges zu Mathe'])
        funny = zahlen._child_items[2]
        self.assertEqual([node.label for node in funny._child_items], ['37', '88', 'Amazing'])
        leaf = funny._child_items[0]
        self.assertEqual(leaf.data(0, doubles.Qt.UserRole), 'math_magic_37')
        self.assertIs(dock._fact_items['math_magic_37'], leaf)
        dock.open_fact('math_magic_37', '37')
        self.assertIs(dock.content_stack._current, dock.math_magic_37_scroll)
        self.assertIs(dock.facts_tree._current, leaf)
        dock.open_fact('prime_numbers')
        self.assertIs(dock.content_stack._current, dock.prime_solver_scroll)

    def test_theme_propagates_and_scroll_does_not_resize_window(self):
        dock = doubles.MathWidget()
        self.assertIn(dock.math_magic_37_scroll, dock.content_stack.children)
        self.assertEqual(dock.math_magic_37_widget.theme_calls, [True])
        self.assertEqual(dock.math_magic_37_scroll.args[0], dock.content_stack)
        dock.set_dark_mode(False)
        self.assertEqual(dock.math_magic_37_widget.theme_calls, [True, False])


if __name__ == '__main__':
    unittest.main()
