"""Stage 382: Wurzel-Gesetz-Kacheln 26 px höher und Lösung versetzt."""
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("d64_dism.py").read_text(encoding="utf-8")


class Stage382RootCardHeightTests(unittest.TestCase):
    def test_root_card_height_extended_by_26(self):
        start = SOURCE.index("def _paint_root_rules(")
        end = SOURCE.index("def _paint_basic_arithmetic(", start)
        block = SOURCE[start:end]
        self.assertIn("QRectF(margin, y, width, 142)", block)
        self.assertIn("rect.y() + 114", block)
        self.assertIn("y += 156", block)

    def test_example_and_solution_no_longer_overlap(self):
        # _draw_formula_card zeichnet das Beispiel bei y+84 mit 28 px Höhe,
        # also bis y+112. Die Lösung startet in Stage 382 bei y+114.
        example_bottom = 84 + 28
        solution_top = 114
        self.assertGreaterEqual(solution_top, example_bottom + 2)

    def test_existing_root_rules_remain_present(self):
        for text in (
            "Produktregel",
            "Quotientenregel",
            "Quadrat und Wurzel",
            "Wurzel aus einem Quadrat",
            "Verschachtelte Wurzel",
        ):
            self.assertIn(text, SOURCE)


if __name__ == "__main__":
    unittest.main()
