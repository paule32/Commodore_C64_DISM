"""Stage 330: statische Tests und mathematische Wiederholungsprüfung, ohne PyQt5."""
import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('d64_custom_brush.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)

class RepeatPreviewTests(unittest.TestCase):
    def test_preview_has_own_widget_and_identifier(self):
        cls = next(c for c in TREE.body if isinstance(c, ast.ClassDef) and c.name == '_PatternRepeatPreview')
        self.assertIn('PREVIEW_SIZE = 128', SOURCE)
        self.assertIn('d64CustomBrushRepeatPreview', SOURCE)
        self.assertTrue(any(isinstance(m, ast.FunctionDef) and m.name == 'paintEvent' for m in cls.body))
    def test_repeated_native_pixels_without_grid(self):
        cls = next(c for c in TREE.body if isinstance(c, ast.ClassDef) and c.name == '_PatternRepeatPreview')
        render = next(m for m in cls.body if isinstance(m, ast.FunctionDef) and m.name == 'refresh_pattern')
        content = ast.get_source_segment(SOURCE, render)
        self.assertIn('y % height', content)
        self.assertIn('x % width', content)
        self.assertIn('QImage.Format_ARGB32', content)
        self.assertIn('image.setPixel(x, y,', content)
        self.assertNotIn('drawLine(', content)
        pixels = [[0, 1, 2], [3, 4, 5]]
        repeat = [[pixels[y % 2][x % 3] for x in range(128)] for y in range(128)]
        self.assertEqual((len(repeat),len(repeat[0])),(128,128))
        self.assertEqual(repeat[0][:7],[0,1,2,0,1,2,0])
        self.assertEqual(repeat[2][:7],repeat[0][:7])
    def test_events_update_preview(self):
        self.assertIn('self.owner.repeat_preview.refresh_pattern()', SOURCE)
        self.assertIn('self.repeat_preview.refresh_pattern()', SOURCE)
        self.assertIn('self._refresh_colors()', SOURCE)

if __name__ == '__main__':
    unittest.main()
