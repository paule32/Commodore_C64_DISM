"""Stage 375: Matrixdarstellung mit Zeilenumbrüchen und Beispielrechnungen."""
from pathlib import Path
import ast
import unittest

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')


def _method_node(class_name: str, method_name: str):
    tree = ast.parse(SOURCE)
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == method_name:
                    return item
    raise AssertionError(f'{class_name}.{method_name} nicht gefunden')


class Stage375MatrixExampleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        methods = [
            _method_node('BasicMathRulesFactWidget', '_format_matrix_example'),
            _method_node('BasicMathRulesFactWidget', '_parse_displayed_matrix'),
            _method_node('BasicMathRulesFactWidget', '_compute_matrix_value_sum'),
            _method_node('BasicMathRulesFactWidget', '_build_matrix_addition_solution'),
            _method_node('BasicMathRulesFactWidget', '_matrix_calculation_examples'),
        ]
        module = ast.Module(body=methods, type_ignores=[])
        ast.fix_missing_locations(module)
        ns = {}
        exec(compile(module, '<stage375_methods>', 'exec'), ns)

        class FakeWidget:
            pass

        FakeWidget._format_matrix_example = ns['_format_matrix_example']
        FakeWidget._parse_displayed_matrix = ns['_parse_displayed_matrix']
        FakeWidget._compute_matrix_value_sum = ns['_compute_matrix_value_sum']
        FakeWidget._build_matrix_addition_solution = ns['_build_matrix_addition_solution']
        FakeWidget._matrix_calculation_examples = ns['_matrix_calculation_examples']
        cls.widget = FakeWidget()

    def test_matrix_modes_use_separate_painter(self):
        self.assertIn("self._paint_matrix_type(painter, colors, spec)", SOURCE)
        self.assertIn("def _paint_matrix_type(self, painter: QPainter, colors: dict, spec) -> None:", SOURCE)

    def test_semicolon_rows_are_shown_on_separate_lines_with_commas(self):
        text = self.widget._format_matrix_example('[ 1 2 3 ; 3 1 2 ; 2 3 1 ]')
        self.assertEqual(text, '[ 1, 2, 3 ]\n[ 3, 1, 2 ]\n[ 2, 3, 1 ]')

    def test_single_column_matrix_becomes_multiple_display_rows(self):
        text = self.widget._format_matrix_example('[ 1 ; 2 ; 3 ]')
        self.assertEqual(text, '[ 1 ]\n[ 2 ]\n[ 3 ]')

    def test_matrix_examples_provide_one_or_more_calculation_blocks(self):
        formatted = self.widget._format_matrix_example('[ 1 0 ; 0 1 ]')
        examples = self.widget._matrix_calculation_examples('matrix_identity', formatted)
        self.assertGreaterEqual(len(examples), 2)
        self.assertEqual(examples[0][0], 'Neutralität')
        self.assertIn('A · I = A', examples[0][1])

    def test_generic_matrix_types_still_receive_examples(self):
        formatted = self.widget._format_matrix_example('[ 1 2 ; 3 4 ]')
        examples = self.widget._matrix_calculation_examples('matrix_dense', formatted)
        self.assertGreaterEqual(len(examples), 1)
        self.assertTrue(any('A +' in text or '2 · A' in text for _title, text in examples))


if __name__ == '__main__':
    unittest.main()
