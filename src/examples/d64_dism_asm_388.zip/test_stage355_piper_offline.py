"""Stage 355: optional Piper/Thorsten German offline voice integration.

No downloadable third-party binary or model is required to run these tests.
The Win32 CreateProcess/PlaySound integration requires a native Windows test.
"""
import ctypes
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent


@unittest.skipUnless(shutil.which('gcc'), 'host C compiler required')
class PiperBackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='stage355_')
        cls.so=Path(cls.tmp.name)/'retro_speech355.so'
        subprocess.run(['gcc','-std=c99','-O2','-Wall','-Wextra','-Werror',
                        '-fPIC','-shared',str(ROOT/'speech/retro_speech.c'),'-lm','-o',str(cls.so)],
                       capture_output=True,text=True,check=True)
        cls.dll=ctypes.CDLL(str(cls.so))
        for name in ('SpeechInitialize','SpeechSetBackend'):
            f=getattr(cls.dll,name);f.argtypes=[ctypes.c_int32];f.restype=ctypes.c_int32
        cls.dll.SpeechSaveWav.argtypes=[ctypes.c_char_p,ctypes.c_char_p]
        cls.dll.SpeechSaveWav.restype=ctypes.c_int32
        cls.dll.SpeechGetLastError.restype=ctypes.c_int32

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_backend_and_retained_formant_speech(self):
        self.assertEqual(self.dll.SpeechInitialize(22050),1)
        self.assertEqual(self.dll.SpeechSetBackend(1),1)
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'probe.wav'
            # POSIX cannot launch Windows Piper; should return clear error.
            self.assertEqual(self.dll.SpeechSaveWav(str(file).encode(),b'Guten Tag!'),0)
            self.assertEqual(self.dll.SpeechGetLastError(),7)
            self.assertEqual(self.dll.SpeechSetBackend(0),1)
            self.assertEqual(self.dll.SpeechSaveWav(str(file).encode(),b'Guten Tag!'),1)
            self.assertGreater(file.stat().st_size,44)

    def test_backend_invalid_value(self):
        self.assertEqual(self.dll.SpeechSetBackend(-1),0)
        self.assertEqual(self.dll.SpeechSetBackend(2),1)
        self.assertEqual(self.dll.SpeechSetBackend(3),0)
        self.assertEqual(self.dll.SpeechSetBackend(0),1)

    def test_dbase_compiles_piper_and_samples_modes(self):
        from d64dbase.compiler import compile_dbase_to_assembly,parse_dbase_statements
        for mode in ('PIPER','SAMPLES'):
            source=f'SET SPEECH MODE {mode}\nSET SPEECH ON\nSAY "Guten Morgen!"\n'
            self.assertEqual(parse_dbase_statements(source)[0].value,mode.lower())
            asm=compile_dbase_to_assembly(source,filename='piper.prg',target='pe32').assembly
            self.assertIn('import SpeechSetBackend, "retro_speech.dll", "SpeechSetBackend"',asm)
            self.assertIn('    call SpeechSetBackend',asm)
            self.assertIn('__dbase_speech_backend:',asm)
            self.assertIn(f'    mov dword ptr [__dbase_speech_backend], {2 if mode == "SAMPLES" else 1}',asm)
        asm=compile_dbase_to_assembly('SET SPEECH MODE AMIGA\nSET SPEECH ON\nSAY "Test"',target='pe32').assembly
        self.assertIn('    mov dword ptr [__dbase_speech_backend], 0',asm)

    def test_dbase_piper_pe32_object_and_link(self):
        from d64dbase.compiler import compile_dbase_to_assembly
        from regression_test_helpers import pe_namespace
        ns=pe_namespace()
        ns['PE32_TEXT_COMPRESSION_MSZIP_DEFAULT']=False
        asm=compile_dbase_to_assembly(
            'SET SPEECH MODE PIPER\nSET SPEECH ON\nSAY "Hallo, hier ist dein Computer."',
            target='pe32').assembly
        obj=ns['assemble_pe32_object_source'](asm)
        coff=ns['write_coff32_object'](obj)
        self.assertTrue(coff.startswith(b'\x4c\x01'))
        pe=ns['link_coff32_objects']([coff],entry_symbol='_start',gui=True)
        self.assertIn(b'SpeechSetBackend',pe.executable)

    def test_install_script_without_downloads(self):
        script=ROOT/'speech/install_piper_voice.py'
        result=subprocess.run(['python',str(script),'--dry-run','--quality','high'],
                              capture_output=True,text=True,check=True)
        self.assertIn('de_DE-thorsten-high.onnx.json',result.stdout)
        self.assertIn('piper_windows_amd64.zip',result.stdout)


if __name__=='__main__':
    unittest.main(verbosity=2)
