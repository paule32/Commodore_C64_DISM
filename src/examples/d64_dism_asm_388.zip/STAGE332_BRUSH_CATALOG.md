# Stage 332 – Zentrale Brush-Musterbibliothek

- `brush.json` liegt neben `d64_dism.py` und enthält eine Liste benannter Muster.
- Jedes Muster enthält `id`, `name`, `format`, `width`, `height`, `palette` (32 Farben) und `pixels` (Farbindex-Matrix).
- Die Brush->Style-Auswahl liest `brush.json` beim Aufbau des Eigenschaftenfensters.
- Die Bibliothekseinträge erscheinen zusätzlich zu den Standardmustern und `Custom` mit individuellen Maßen und Vorschau-Icons.
- Die Auswahl eines Bibliotheksmusters übernimmt Pixelmatrix und Geometrie in die Komponente.
- Nach dem Speichern im Custom-Pixel-Editor wird das Muster automatisch zur zentralen Bibliothek hinzugefügt/aktualisiert. Einzeldateien bleiben erhalten.
- `CustomId` speichert die stabile Musterkennung in WFM; die bestehenden `CustomWidth`, `CustomHeight` und `CustomFile` bleiben erhalten.
- Fehlerhafte Musterdateien werden nicht überschrieben; Einträge werden beim Laden validiert.

Hinweis: Die Laufzeitdarstellung in einer nativen WFM-EXE ist weiterhin ein separates Thema; Stage 332 betrifft die IDE/Designer-Bibliothek.
