# Stage 366 – Mathematik / Grundwissen / Rechengesetze

## Inhalt

Diese Stage erweitert den Hauptknoten **Grundwissen** im Mathematik-Docking-Fenster um den neuen ersten Unterknoten **Rechengesetze** mit den Blättern:

- Grundrechen-Arten
- Teilbarkeit
- Potenzen
- Rechengesetze

## Darstellung rechts

### Grundrechen-Arten
Auf der rechten Seite werden vier untereinander angeordnete QPainter-Kacheln dargestellt für:

1. Addition / addieren
2. Subtraktion / subtrahieren
3. Multiplikation / multiplizieren
4. Division / dividieren

Jede Kachel enthält Überschrift, Merksatz und Beispiel.

### Teilbarkeit
Die rechte Seite zeigt eine QPainter-Ansicht mit:

- Überschrift `Teilbarkeitsregeln`
- mittigem Text `Eine Zahl ist`
- 8 Kacheln im 2-spaltigen Raster für 2, 3, 4, 5, 6, 8, 9 und 10
- jede Kachel enthält Regeltext und zwei innere Beispielboxen
- linke Box mit grünem Check-Symbol
- rechte Box mit rotem Falsch-Symbol

Die Inhalte orientieren sich am bereitgestellten Referenzbild, ohne eine Pixelkopie zu sein.

### Potenzen / Rechengesetze
Beide Blätter werden ebenfalls innerhalb des bestehenden Mathematik-Docks dargestellt. Für diese Stufe enthalten sie kompakte Merkblätter mit den grundlegenden Rechenregeln.

## Technik

- neue Klasse `BasicMathRulesFactWidget`
- Darstellung vollständig per `QPainter`
- Dark-Mode-Farben berücksichtigt
- Integration in das bestehende `MathematicsLearningDockWidget`
- kein eigenes zusätzliches Dock-Fenster

## Geänderte Bereiche

- Faktenbaum unter `Grundwissen`
- Fakten-Stack / Seitenumschaltung
- Dark-Mode-Weitergabe an neues Widget
- Öffnen der neuen Rechen-Blätter im bestehenden Mathematik-Dock
