"""Stage 339: independent C99 synthesis / DLL ABI smoke tests.

These tests use the host compiler for deterministic WAV/PCM validation;
Windows 10 PE32 is built and tested separately on MSYS2 MINGW32.
"""
import ctypes
import hashlib
import math
import os
import shutil
import subprocess
import tempfile
import unittest
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'speech'


@unittest.skipUnless(shutil.which('gcc'), 'host GCC is required to test native DSP')
class SpeechTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='stage339_')
        cls.dir = Path(cls.tmp.name)
        cls.lib = cls.dir / 'libretro_speech_test.so'
        subprocess.run(['gcc', '-O2', '-std=c99', '-Wall', '-Wextra', '-Werror',
                        '-fPIC', '-shared', str(SRC / 'retro_speech.c'), '-lm',
                        '-o', str(cls.lib)], check=True, capture_output=True)
        cls.dll = ctypes.CDLL(str(cls.lib))
        cls.dll.SpeechInitialize.argtypes = (ctypes.c_int32,)
        cls.dll.SpeechSetMix.argtypes = (ctypes.c_int32,)
        cls.dll.SpeechSetPitch.argtypes = (ctypes.c_int32,)
        cls.dll.SpeechSetSpeed.argtypes = (ctypes.c_int32,)
        for name in ('SpeechInitialize', 'SpeechSetMix', 'SpeechSetPitch', 'SpeechSetSpeed',
                     'SpeechGetSampleRate', 'SpeechGetLastError', 'SpeechSpeak',
                     'SpeechSaveWav'):
            getattr(cls.dll, name).restype = ctypes.c_int32
        for name in ('SpeechRenderText', 'SpeechRenderPhonemes'):
            fn = getattr(cls.dll, name)
            fn.argtypes = (ctypes.c_char_p, ctypes.POINTER(ctypes.c_int16), ctypes.c_uint32)
            fn.restype = ctypes.c_uint32
        cls.dll.SpeechSaveWav.argtypes = (ctypes.c_char_p, ctypes.c_char_p)
        cls.dll.SpeechGetLastErrorText.restype = ctypes.c_char_p
        cls.dll.SpeechSpeak.argtypes = (ctypes.c_char_p,)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def setUp(self):
        self.assertEqual(self.dll.SpeechInitialize(22050), 1)
        self.assertEqual(self.dll.SpeechSetMix(55), 1)
        self.assertEqual(self.dll.SpeechSetPitch(125), 1)
        self.assertEqual(self.dll.SpeechSetSpeed(100), 1)

    def render(self, text, fn='SpeechRenderText'):
        func = getattr(self.dll, fn)
        if isinstance(text, str):
            text = text.encode('utf-8')
        n = func(text, None, 0)
        self.assertGreater(n, 0)
        pcm = (ctypes.c_int16 * n)()
        self.assertEqual(func(text, pcm, n), n)
        return bytes(pcm)

    def test_german_sentence_generates_nonzero_audio(self):
        data = self.render('Hallo, ich bin dein Sprachcomputer.')
        n = len(data) // 2
        self.assertGreater(n, 22050)
        self.assertLess(n, 22050 * 15)
        pcm = (ctypes.c_int16 * n).from_buffer_copy(data)
        peak = max(abs(x) for x in pcm)
        self.assertGreater(peak, 4000)
        self.assertLessEqual(peak, 32767)

    def test_phoneme_direct(self):
        self.assertGreater(len(self.render('H A L O _ I CH .', 'SpeechRenderPhonemes')), 0)

    def test_deutsches_utf8_und_unbekanntes_wort(self):
        self.assertGreater(len(self.render('Äpfel, Öl und Grüße!')), 0)

    def test_c64_amiga_mix_changes_pcm(self):
        self.dll.SpeechSetMix(0)
        c64 = self.render('Hallo')
        self.dll.SpeechSetMix(100)
        amiga = self.render('Hallo')
        self.assertNotEqual(hashlib.sha256(c64).digest(), hashlib.sha256(amiga).digest())

    def test_speed_and_pitch(self):
        normal = self.render('Hallo')
        self.assertEqual(self.dll.SpeechSetSpeed(200), 1)
        fast = self.render('Hallo')
        self.assertLess(len(fast), len(normal))
        self.assertEqual(self.dll.SpeechSetSpeed(100), 1)
        self.assertEqual(self.dll.SpeechSetPitch(180), 1)
        high = self.render('Hallo')
        self.assertNotEqual(normal, high)

    def test_validates_errors_and_insufficient_buffer(self):
        self.assertEqual(self.dll.SpeechSetMix(101), 0)
        self.assertEqual(self.dll.SpeechGetLastError(), 1)
        self.assertEqual(self.dll.SpeechSetPitch(20), 0)
        self.assertEqual(self.dll.SpeechSetSpeed(0), 0)
        self.assertEqual(self.dll.SpeechInitialize(123), 0)
        self.assertEqual(self.dll.SpeechInitialize(22050), 1)
        self.assertEqual(self.dll.SpeechRenderPhonemes(b'BADPHONEME', None, 0), 0)
        self.assertEqual(self.dll.SpeechGetLastError(), 2)
        self.assertEqual(self.dll.SpeechRenderText(b'', None, 0), 0)
        self.assertEqual(self.dll.SpeechGetLastError(), 2)
        tiny = (ctypes.c_int16 * 1)()
        self.assertEqual(self.dll.SpeechRenderText(b'Hallo', tiny, 1), 0)
        self.assertEqual(self.dll.SpeechGetLastError(), 4)
        self.assertGreater(len(self.dll.SpeechGetLastErrorText()), 0)

    def test_wav_header_and_samples(self):
        path = self.dir / 'hallo.wav'
        self.assertEqual(self.dll.SpeechSaveWav(os.fsencode(path),
                                                 'Hallo Welt'.encode('utf-8')), 1)
        with wave.open(str(path), 'rb') as f:
            self.assertEqual(f.getnchannels(), 1)
            self.assertEqual(f.getsampwidth(), 2)
            self.assertEqual(f.getframerate(), 22050)
            self.assertGreater(f.getnframes(), 1000)
            self.assertEqual(len(f.readframes(f.getnframes())), f.getnframes() * 2)

    def test_host_playback_explicitly_unsupported(self):
        self.assertEqual(self.dll.SpeechSpeak(b'Hallo'), 0)
        self.assertEqual(self.dll.SpeechGetLastError(), 5)

    def test_demo_dynamic_linking_and_generated_wav(self):
        exe = self.dir / 'demo'
        subprocess.run(['gcc', '-std=c99', '-Wall', '-Wextra', '-Werror',
                        str(SRC / 'retro_speech_demo.c'), '-L' + str(self.dir),
                        '-lretro_speech_test', '-o', str(exe)], check=True, capture_output=True)
        env = dict(os.environ, LD_LIBRARY_PATH=str(self.dir))
        dest = self.dir / 'demo.wav'
        proc = subprocess.run([str(exe), '--no-play', '--wav', str(dest)],
                              capture_output=True, text=True, env=env, check=True)
        self.assertIn('Hallo, ich bin dein Sprachcomputer.', proc.stdout)
        self.assertTrue(dest.is_file())
        with wave.open(str(dest), 'rb') as f:
            self.assertEqual(f.getframerate(), 22050)


if __name__ == '__main__':
    unittest.main(verbosity=2)
