# Stage 350 – Frankreich-Flüsse 3 px + Hover-Overlay

Basis: Stage 349 (`d64_dism_asm_349.zip`)

## Änderungen

1. **Flussdarstellung auf 3 Pixel erhöht**
   - Das eingebettete Frankreich-Fluss-SVG wird beim Laden auf `stroke-width="3"` umgestellt.
   - Die Frankreich-Landkarte bleibt weiterhin nur einmal gespeichert; die Flüsse liegen als Overlay darüber.

2. **Interaktive Fluss-Overlays**
   - Beim Überstreichen einer Flusslinie mit dem Mauszeiger wird ein Overlay im Kartenfenster eingeblendet.
   - Angezeigt werden:
     - Name des Flusses
     - Ursprungsquelle
     - Mündung
     - Länge (falls vorhanden)

3. **Unterstützte Flüsse (Hover-Informationen)**
   - Seine
   - Loire
   - Garonne
   - Dordogne
   - Rhône
   - Saône
   - Rhein
   - Maas
   - Mosel

## Technische Umsetzung

- Die sichtbaren Flüsse stammen weiterhin aus dem geodatenbasierten SVG-Overlay.
- Für die Maus-Hit-Tests wird eine zusätzliche Datenstruktur `FRANCE_RIVER_HOVER_DATA` in `france.py` verwendet.
- Die Hover-Erkennung arbeitet mit normierten Polyline-Stützpunkten und einer zoomabhängigen Toleranz.
- Das Info-Overlay wird als `QLabel` direkt auf dem Viewport des `FranceMapView` gezeichnet.

## Geänderte Dateien

- `d64_dism.py`
- `france.py`
- `STAGE350_FRANCE_RIVER_HOVER.md`

## Hinweis

Die sichtbaren Flussverläufe stammen aus dem geodatenbasierten SVG-Overlay. Die Hover-Geometrie ist für die wichtigsten Flüsse separat hinterlegt, damit die Benutzer interaktive Zusatzinformationen erhalten.
