# Stage 327 – WFM-Funktionsaufrufe in IF/ELSEIF und RETURN

Basis: `d64_dism_asm_326.zip` (verbindlich). Ursache des gemeldeten Fehlers:

```
Form1.wfm: WFM-IF numerischer Ausdruck noch nicht unterstuetzt:
DBaseCallExpression(... name='CheckLower', ...)
```

Der allgemeine `.prg`-Compiler kann benutzerdefinierte Funktionen in IF auswerten; der WFM-Eventassembler behandelte vorher ausschließlich einige eingebaut benannte Funktionen (`ISUPPER`, `ISLOWER`, `ISMOUSE`, `ISKEYBOARD`) und wies andere DBaseCallExpression-Knoten ab.

## Korrektur

- `d64_dism.py`: WFM-IF/ELSEIF kann jetzt eine in derselben FORM-Klasse definierte `FUNCTION` direkt aufrufen und deren numerischen/Boolean-Rückgabewert aus EAX ins x87-Registerformat überführen.
- Unterstützt werden Funktionen ohne Parameter oder mit einem UTF-8-Text-/Zeichenparameter. Im Textfall werden Pointer und die **explizite UTF-8-Bytezahl** übertragen. Der WFM-Funktionsprolog erstellt für den Textparameter einen typisierten Slot; `ISUPPER(parameter)` und `ISLOWER(parameter)` verarbeiten diesen korrekt.
- Die bestehende Behandlung von `RETURN ISUPPER(...)` / `RETURN ISLOWER(...)` bleibt erhalten. Ergänzt ist `RETURN <numerischer Ausdruck>` einschließlich weiterer WFM-Funktionsaufrufe.
- Fehlermeldungen unterscheiden fehlende Funktion, PROCEDURE statt FUNCTION, falsche Parameterzahl und nicht unterstützte Argumentformen.
- Die Eingabe der Funktion darf sowohl ein Literal (`'z'`, `'Ä'`) als auch eine mit `STORE` angelegte WFM-Textvariable sein.

## Beispiel

```dbase
CLASS Form1 OF FORM
    PROCEDURE Button1Click(Sender)
        IF CheckLower('z')
            ? "Kleinbuchstabe erkannt"
        ENDIF
    RETURN

    FUNCTION CheckLower(c)
        RETURN ISLOWER(c)
ENDCLASS
```

Der Funktionsname muss im WFM-Formular vorhanden sein; eine `.prg`-Funktion in einer anderen Quelldatei wird dadurch **nicht automatisch** als WFM-Klassenmethode importiert oder gelinkt. Die allgemeine Übergabe beliebig vieler beziehungsweise komplexer Funktionsargumente ist im WFM-Assembler weiterhin noch nicht implementiert.

## Prüfungen

- `python test_dbase_wfm_user_calls_stage327.py`: PE32/PE64 WFM-Assembler + gültiger COFF-Objektcode, `IF CheckLower('z')`, Textvariablen, `.AND.`, `.NOT.`, nullparametrige Funktion und erwartete Diagnosen.
- `python test_dbase_char_case_stage326.py`: PE32/PE64 `.prg` + `.wfm`, dynamische Zeichenprüfung und Fehlerfälle.
- `python test_dbase_wfm_logic_stage308.py`, `python test_dbase_logic_stage306.py`, `python test_dbase_ismouse_stage309.py`, `python test_dbase_iskeyboard_stage310.py`: alle abgeschlossen und bestanden.

Windows-Ausführung der erzeugten EXE ist in dieser Linux-Umgebung nicht möglich. Eine vollständige Windows-WFM-Laufzeitbestätigung liegt noch nicht vor.
