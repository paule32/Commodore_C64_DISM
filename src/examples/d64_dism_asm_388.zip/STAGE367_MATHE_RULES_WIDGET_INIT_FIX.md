# Stage 367 – Mathematik-Dock: fehlende Rechengesetze-Instanz

## Gemeldeter Fehler

Beim Öffnen der Mathematik-Arbeitsfläche brach die initiale Dark-Mode-Konfiguration in
`MathematicsLearningDockWidget.set_dark_mode()` ab:

```
AttributeError: 'MathematicsLearningDockWidget' object has no attribute 'basic_math_rules_widget'
```

## Ursache

Stage 366 hat die neue Klasse `BasicMathRulesFactWidget` sowie die Aufrufe
in `set_dark_mode()` und `open_fact()` ergänzt, aber das Widget und die zugehörige
Scroll-Seite im `MathematicsLearningDockWidget.__init__()` nicht instanziiert.

## Änderung

Die Initialisierung erfolgt unmittelbar nach der Zinsrechnungsseite und vor dem
Aufruf von `self.set_dark_mode(True)`:

```python
self.basic_math_rules_widget = BasicMathRulesFactWidget()
self.basic_math_rules_scroll = _add_fact_scroll_page(
    self.basic_math_rules_widget, 'basic_math_rules_scroll_area'
)
self.basic_math_rules_widget.setMinimumWidth(760)
```

Die Mindestbreite wird *nach* der Scroll-Seiten-Hilfsfunktion gesetzt, da diese die
Mindestgrößen zunächst zurücksetzt. Die bisherigen Inhalte bleiben unverändert.

## Regressionen

- `test_stage367_math_rules_widget_init.py`: tatsächlicher Konstruktor mit
  Qt-kompatiblen Testdoubles; Initialisierung inklusive Dark-Mode, Fakten-Baum,
  Navigation auf alle vier Blätter sowie auf Zinsrechnung/Flächen/Volumen.
- `test_stage364_math_interest.py`: vorhandene Zinsrechnungs-Tests an die seit
  Stage 366 gültige Baumstruktur und das eingefügte neue Widget angepasst.
- Python-Syntax und Archivintegrität geprüft.

Ein nativer PyQt5-/Windows-GUI-Laufzeittest muss weiterhin lokal erfolgen.
