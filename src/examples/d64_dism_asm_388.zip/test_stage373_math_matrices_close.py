"""Stage 373: mathematische Navigation, Schließen-Button und Hochstellungen."""
from pathlib import Path
import ast
import unittest
import test_stage367_math_rules_widget_init as doubles

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')

class MathStage373Tests(unittest.TestCase):
    def test_close_button_is_in_tab_header_and_signal_connected_to_dock(self):
        self.assertIn("self.math_close_button = QPushButton('Schließen', self.left_tabs)", SOURCE)
        self.assertIn('self.left_tabs.setCornerWidget(self.math_close_button, Qt.TopRightCorner)', SOURCE)
        self.assertIn('self.math_close_button.clicked.connect(self.close_requested.emit)', SOURCE)
        self.assertIn('widget.close_requested.connect(dock.close)', SOURCE)
        widget = doubles.MathWidget()
        self.assertIn(('setCornerWidget', (widget.math_close_button, 1), {}), widget.left_tabs.calls)

    def test_powers_are_superscripted_without_caret(self):
        p0 = SOURCE.index("elif self._mode == 'powers_rules':")
        p1 = SOURCE.index("elif self._mode.startswith('matrix_'):", p0)
        formula_source = SOURCE[p0:p1]
        self.assertNotIn('^', formula_source)
        self.assertIn('aᵐ · aⁿ = a⁽ᵐ⁺ⁿ⁾', formula_source)
        self.assertIn('aᵐ : aⁿ = a⁽ᵐ⁻ⁿ⁾', formula_source)

    def test_matrices_are_independent_top_level_node_and_open_pages(self):
        widget = doubles.MathWidget()
        grundwissen = widget.facts_tree.children[0]
        self.assertEqual([i.label for i in grundwissen._child_items],
                         ['Rechengesetze','Algebra','Geometrie','Trigometrie'])
        matrices = widget.facts_tree.children[1]
        self.assertEqual(matrices.label, 'Matrizen')
        expected = doubles.ctx['BasicMathRulesFactWidget'].MATRIX_TYPES
        self.assertEqual(len(matrices._child_items), len(expected))
        self.assertGreaterEqual(len(expected), 30)
        for key, title, *_ in expected:
            with self.subTest(key=key):
                item = widget._fact_items[key]
                self.assertEqual(item.label, title)
                self.assertEqual(item._child_items, [])
                widget.open_fact(key,title)
                self.assertIs(widget.content_stack._current, widget.basic_math_rules_scroll)
                self.assertIn(('activate_fact',(key,title),{}),widget.basic_math_rules_widget.calls)

if __name__ == '__main__':
    unittest.main()
