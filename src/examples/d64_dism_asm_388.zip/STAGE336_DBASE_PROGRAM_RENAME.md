# Stage 336 – dBase-Programmdatei umbenennen

Basis: `d64_dism_asm_335.zip`.

Im Kontextmenü einer Programmdatei unter `dBase-Programme -> Programme`
steht neu `Umbenennen`. Die Aktion startet die Bearbeitung des Dateinamens
im TreeWidget selbst. Nach Bestätigung werden Dateiname auf Datenträger,
Projektblatt, Pfadreferenz und ein eventuell geöffneter dBase-Editor-Tab
aktualisiert; die Projektkonfiguration wird gespeichert.

Bei Dateinamenskollision wird nichts überschrieben. Stattdessen erscheint
`Warnung: Datei mit gleichen Namen existiert bereits!` in einem modalen
Dark-Mode-Dialog mit selbst gezeichneter, horizontal schwarz-grauer
Titelleiste, Schließen-Symbol, 3-Pixel-Rahmen und OK-Button. Das
Inline-Edit ist dann bereits beendet, der bisherige Blattname steht wieder da.

Der Dateityp `.prg` bleibt erhalten; ungültige Dateinamen oder Dateisystemfehler
werden abgewiesen. Dies betrifft ausschließlich dBase-Programmdatei-Blätter.

Teststatus: Python-Compilation und strukturelle Regression erfolgreich.
Windows/Qt5-Dialog-Laufzeittest noch nicht durchgeführt.
