"""Stage 360: statische QPainter-Tafel, Farben, Originalanimation, Dockwechsel.
Ohne echte PyQt-Laufzeit; ein Windows-GUI-Test ist zusätzlich erforderlich.
"""
import math
from pathlib import Path
import re
import textwrap
import types
import unittest

SRC = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')

class MockQColor:
    def __init__(self, code): self.code = code
    def __repr__(self): return f'QColor({self.code})'
class MockQPen:
    def __init__(self, color, *args): self.color = color
class MockQBrush:
    def __init__(self, color): self.color = color
class MockQSize:
    def __init__(self, w, h): self.wh=(w,h)
class MockQPointF:
    def __init__(self,x,y): self._x=x; self._y=y
    def x(self): return self._x
    def y(self): return self._y
class MockQRectF:
    def __init__(self,x,y,w,h): self.coords=(x,y,w,h)
class MockQFont:
    def __init__(self, other=None): self.size=getattr(other,'size',12); self.bold=False
    def setPixelSize(self,size): self.size=size
    def setBold(self,flag): self.bold=flag
class MockQFontMetricsF:
    def __init__(self, font): self.font=font
    def horizontalAdvance(self, text): return self.font.size*.6*len(text)
class MockQWidget:
    def __init__(self,parent=None): self.w=1200; self.h=1060; self.events=[]
    def setObjectName(self,*a): pass
    def setMinimumSize(self,*a): pass
    def setSizePolicy(self,*a): pass
    def setAttribute(self,*a): pass
    def update(self): self.events.append('update')
    def width(self): return self.w
    def height(self): return self.h
    def rect(self): return ('full_canvas',self.w,self.h)
class MockQt:
    WA_OpaquePaintEvent=1
    NoBrush=2
    AlignCenter=4
    Horizontal=8
    Vertical=16
class MockQSizePolicy:
    Expanding=1
class MockQPainter:
    Antialiasing=1;TextAntialiasing=2
    def __init__(self,widget):
        self.widget=widget;self.calls=[]; self.fnt=MockQFont()
        widget.last_painter=self
    def setRenderHint(self,*a): pass
    def fillRect(self,rect,brush): self.calls.append(('background',brush.code))
    def translate(self,*a): self.calls.append(('translate',a))
    def scale(self,*a): self.calls.append(('scale',a))
    def setPen(self,p): self.calls.append(('pen',getattr(p,'color',p)))
    def setBrush(self,*a): pass
    def drawLine(self,*a): self.calls.append(('line',a))
    def drawEllipse(self,*a): self.calls.append(('ellipse',a))
    def setFont(self,font): self.fnt=font
    def font(self): return self.fnt
    def drawText(self,rect,flags,text):self.calls.append(('text',text))
    def end(self):self.calls.append(('end',))

# Nur Klasse extrahieren, statt das grosse GUI-Modul zu importieren.
cls_start=SRC.index('    class UnitCircleReferenceWidget(QWidget):')
cls_end=SRC.index('    class MathematicsLearningDockWidget(QWidget):',cls_start)
cls_code=textwrap.dedent(SRC[cls_start:cls_end])
ctx=dict(QWidget=MockQWidget, QSize=MockQSize, QSizePolicy=MockQSizePolicy,
         Qt=MockQt,QPointF=MockQPointF,QRectF=MockQRectF,
         QColor=MockQColor,QBrush=MockQBrush,QPen=MockQPen,
         QPainter=MockQPainter,QFont=MockQFont,QFontMetricsF=MockQFontMetricsF,
         math=math)
exec(compile(cls_code,'unit_circle_ref','exec'),ctx)
Reference=ctx['UnitCircleReferenceWidget']

class FakeDock:
    def __init__(self,name):self.name=name;self.visible=True;self.signals_blocked=False
    def isVisible(self):return self.visible
    def hide(self):self.visible=False
    def show(self):self.visible=True
    def blockSignals(self,yes): old=self.signals_blocked;self.signals_blocked=yes;return old
    def __repr__(self):return self.name
class FakeCenter:
    visible=True
    def isVisible(self):return self.visible
    def hide(self):self.visible=False
    def show(self):self.visible=True
class FakeAnimator:
    def __init__(self):self.stopped=0
    def stop_animation(self):self.stopped+=1

start=SRC.index('        def _restore_unit_circle_workspace(self) -> None:')
end=SRC.index('        def _restore_math_learning_workspace(self) -> None:',start)
method_code=textwrap.dedent(SRC[start:end])
ns={'QDockWidget':FakeDock,'Qt':MockQt,'QSizePolicy':MockQSizePolicy}
exec(compile('class Main:\n'+textwrap.indent(method_code,'    '),'workspace','exec'),ns)
Main=ns['Main']

class Stage360Tests(unittest.TestCase):
    def test_16_labels_and_exact_sin_cos(self):
        self.assertEqual(len(Reference.ANGLES),16)
        self.assertEqual(len(Reference.RADIAN_LABELS),16)
        self.assertEqual(len(Reference.COORDINATES),16)
        self.assertEqual(Reference.RADIAN_LABELS[14],('7π','4'))
        def val(expr):
            def term(s):
                if s.startswith('√'): return math.sqrt(float(s[1:]))
                if s.startswith('-√'): return -math.sqrt(float(s[2:]))
                return float(s)
            return term(expr.split('/')[0])/float(expr.split('/')[1]) if '/' in expr else term(expr)
        for deg,(x,y) in zip(Reference.ANGLES,Reference.COORDINATES):
            self.assertAlmostEqual(val(x),math.cos(math.radians(deg)),places=8)
            self.assertAlmostEqual(val(y),math.sin(math.radians(deg)),places=8)

    def test_painter_light_dark_and_all_degrees(self):
        widget=Reference()
        widget.paintEvent(None)
        calls=widget.last_painter.calls
        self.assertIn(('background','#ffffff'),calls)
        texts=[row[1] for row in calls if row[0]=='text']
        for deg in Reference.ANGLES: self.assertIn(f'{deg}°',texts)
        self.assertGreaterEqual(len([row for row in calls if row[0]=='ellipse']),2)
        self.assertIn('√3',texts)
        self.assertIn('π',texts)
        widget.set_dark_mode(True)
        widget.paintEvent(None)
        calls=widget.last_painter.calls
        self.assertIn(('background','#000000'),calls)
        self.assertTrue(any(row[0]=='pen' and isinstance(row[1],MockQColor) and row[1].code=='#ffffff' for row in calls))
        self.assertFalse(any(row[0]=='background' and row[1]=='#ffffff' for row in calls))

    def test_resize_does_not_distort_circle(self):
        widget=Reference();widget.w=700;widget.h=480
        widget.paintEvent(None)
        scale=[row[1] for row in widget.last_painter.calls if row[0]=='scale'][0]
        self.assertAlmostEqual(scale[0],scale[1])
        self.assertLess(scale[0],1)

    def test_workspace_switch_does_not_restore_other_docks(self):
        first=FakeDock('animated');second=FakeDock('static');second.hide()
        normal=FakeDock('filesystem');central=FakeCenter()
        app=Main();app.unit_circle_dock=first;app.unit_circle_reference_dock=second
        app.unit_circle_widget=FakeAnimator();app._unit_circle_workspace_active=False
        app._unit_circle_workspace_hidden_docks=[];app._unit_circle_workspace_replaced_central_widget=False
        app.findChildren=lambda cls:[first,second,normal]
        app.centralWidget=lambda:central
        app._prepare_unit_circle_workspace(first)
        self.assertFalse(normal.visible);self.assertFalse(central.visible)
        second.show();app._prepare_unit_circle_workspace(second)
        self.assertFalse(first.visible);self.assertFalse(normal.visible)
        self.assertIs(app._unit_circle_workspace_dock,second)
        self.assertGreater(app.unit_circle_widget.stopped,0)
        app._restore_unit_circle_workspace()
        self.assertTrue(normal.visible);self.assertTrue(central.visible)
        self.assertFalse(first.visible)
        self.assertIsNone(app._unit_circle_workspace_dock)

    def test_original_animation_not_replaced(self):
        self.assertIn('class UnitCircleLearningWidget(QWidget):',SRC)
        self.assertIn('self._animation_timer.timeout.connect(self._advance_animation)',SRC)
        self.assertIn('widget.start_animation()',SRC)
        self.assertIn('"Einheits-Kreis - 1"',SRC)
        self.assertIn('"Einheits-Kreis - 2"',SRC)
        self.assertIn('geometry_menu.addAction(self.unit_circle_action)',SRC)
        self.assertIn('geometry_menu.addAction(self.unit_circle_reference_action)',SRC)
        self.assertIn("dock.setObjectName('unit_circle_learning_dock')",SRC)
        self.assertIn("dock.setObjectName('unit_circle_reference_dock')",SRC)
        self.assertIn('elif isinstance(widget, UnitCircleReferenceWidget):',SRC)
        self.assertNotIn('QPixmap(',cls_code)

if __name__=='__main__':unittest.main()
