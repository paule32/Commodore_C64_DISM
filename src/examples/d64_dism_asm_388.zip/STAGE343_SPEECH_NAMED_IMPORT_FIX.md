# Stage 343 – Retro Speech: Ordinalimport-/DLL-Versionskonflikt

**Verbindliche Basis:** `d64_dism_asm_342.zip`.

## Gemeldeter Fehler

Bei aktivierten Projekt-Einstellungen zum Umwandeln benannter PE32-DLL-Importe in Ordinalimporte erschien beim Kompilieren einer dBase-Sprachdemo:

> Ordinalimport für `SpeechSetExpression` aus `retro_speech.dll` ist nicht möglich: die Exporttabelle von `.../examples/retro_speech.dll` enthält diesen Funktionsnamen nicht.

Die DLL in `examples/` war eine ältere Version oder ein anderes Build-Artefakt als die benötigte Stage-342-Runtime. `SpeechSetExpression` wurde in Stage 341, `SpeechSpeakCP1252` in Stage 342 hinzugefügt. **Die genaue vorhandene DLL-Datei auf dem Benutzerrechner lag zum Prüfen nicht vor**, daher ist die Versionsursache anhand des Exportfehlers erschlossen, nicht binär verifiziert.

## Codeänderungen

- `rewrite_pe_assembly_imports_to_ordinals`: behält `import ... "retro_speech.dll", "Speech..."` unverändert bei, auch wenn das Projekt Ordinalimporte erzwingt. Andere DLL-Importe können weiterhin gemäß Einstellung in Ordinale umgewandelt werden.
- `_pe_import_specs_with_local_ordinals`: schützt dieselbe DLL auch vor dem optionalen globalen Ordinalimport-Optimierer im internen PE-Linker. Dies verhindert eine versteckte spätere Umwandlung.
- `MainWindow._launch_assembled_document`: führt die vorhandene Export-/PE32-Prüfung vor dem Start sowohl für direkte dBase-GUI-Starts als auch für Workstation-Runner-Starts aus, sofern der generierte Assembler Sprach-DLL-Importe enthält.
- `MainWindow._prepare_dbase_speech_runtime`: protokolliert bei inkompatiblen lokalen Kandidaten, welche Exportnamen fehlen; eine veraltete DLL neben der EXE wird aus `speech/bin/retro_speech.dll` ersetzt, **sofern** dort eine PE32-DLL mit allen erforderlichen Exporten vorhanden ist. Ohne passende DLL bleibt der Start gesperrt und meldet den erforderlichen Neubuild.
- `MainWindow._launch_dbase_qt5_gui`: entfernt die nach dem zentralen Startcheck redundante erneute Prüfung.

## Neubuild / Test am Windows-Rechner

Unter MSYS2 **MINGW32** (nicht MINGW64):

```
cd T:/GitHub/dBase2Many/src/asmjit/compiler/frontend/c64/speech
python build_pe32.py
objdump -p bin/retro_speech.dll | grep -E 'SpeechSetExpression|SpeechSpeakCP1252'
```

Mit Stage 343 `d64_dism.py` die `.prg` erneut kompilieren und assemblieren. Für manuelle EXE-Starts `speech/bin/retro_speech.dll` nach `examples/retro_speech.dll` kopieren; beim IDE-Start wird die kompatible Runtime automatisch bereitgestellt.

**Wichtig:** Bereits vorher erzeugte ausführbare PE-Dateien mit gebundenen Ordinalimporten müssen neu gelinkt werden; nur die DLL auszutauschen behebt die instabilen Ordinalnummern nicht zuverlässig. Nach dem erneuten Linken bleiben die Sprachimporte namentlich.

## Prüfstatus

- `test_stage343_speech_ordinal_compat.py`: 7 Tests bestanden, darunter Namensimporte bei Ordinalpflicht, verbleibende Ordinaloptimierung anderer DLLs, realer interner COFF32-/PE32-Linklauf, Ersetzen veralteter lokaler DLL (über simulierte Exporttabelle), Fehlerfall und Startpfad-Regression.
- Sprachengine-/dBase-Regressionen Stages 339–342: 31 Tests bestanden.
- Python-Syntax und ZIP-Integrität: geprüft.
- Windows-PE32-DLL und Tonwiedergabe: auf diesem Linux-Host nicht nativ ausgeführt; unter Windows validieren.
