# Stage 356 – GZIP-SPC-Container, nativer IMA-ADPCM-Decoder, dBase-Samples

**Basis:** Stage 355 (`d64_dism_asm_355.zip`) und `speechConvert.py` aus dem separaten speechConvert-Paket.

## Einordnung der Formate

IMA-ADPCM ist bereits eine verlustbehaftete **4-Bit-Differenzkodierung**. Es reduziert PCM16 auf ungefähr ein Viertel der Nutzdatenmenge. `gzip` ist eine zusätzliche verlustfreie Kompression der **kodierten WAV-Payload** und spart nur dann Platz, wenn noch Redundanz enthalten ist; bei manchen Dateien wird das Ergebnis größer.

## Kompatibler SPC1-Datencontainer

Header und Eintragsstruktur bleiben im bestehenden Little-Endian-SPC1-Format unverändert:

- `SPCHV1\0\0`, Version 1; Index am Dateiende.
- Jedes Verzeichnisobjekt: `<HBBIQQQI>` + UTF-8-Name.
- Im Byte `codec` markiert **Bit 7 (0x80)** eine gzip-komprimierte Payload.
- Die unteren Bits (`codec & 0x7f`) bleiben unverändert: 1=PCM WAV, 2=IMA-ADPCM WAV, 3=MP3, 4=Ogg.
- `size`/`offset` beschreiben die tatsächlich gespeicherten Bytes; CRC32 prüft ebenfalls die **gespeicherten** Bytes (bei `--gzip` also die gzip-Daten).
- Vorhandene SPC1-Container bleiben gültig. Ältere Reader kennen die gzip-Markierung nicht und können gepackte Einträge nicht lesen.
- `--gzip` wirkt **nur** auf einen Container-Eintrag. Eine zusätzlich mit `-ow` erzeugte WAV bleibt regulär dekodierbar.

## CLI-Beispiele

```powershell
python speechConvert.py du.wav -s --keep-ms 10 -oc sprache.spc -a DU --gzip
python speechConvert.py du.wav -s -oc sprache.spc -a DU -gz
python speechConvert.py '@sprach_batch.txt' -oc sprache.spc -gz
python speechConvert.py -oc sprache.spc --list --verify
python speechConvert.py -oc sprache.spc -d DU
```

## C-Runtime: speech/spc_reader.c

- Index wird einmal eingelesen; Audiodaten werden erst auf Anfrage gelesen.
- Namen werden ASCII-case-insensitiv verglichen (`DU` und `du`), UTF-8-Datenbytes unverändert.
- CRC32-Prüfung vor dem Entpacken; `speechConvert.py --verify` prüft auch den GZIP-Stream.
- GZIP-DEFLATE mit zlib **dynamisch** und nur bei gzip-Einträgen (keine zlib-Entwicklungsbibliothek beim Build notwendig).
- Unter Windows muss bei Verwendung von `--gzip` **zlib1.dll** (passende 32-Bit-Version für PE32) in der Windows-DLL-Suchumgebung vorhanden sein. Unter Linux `libz.so.1`.
- Der Reader dekodiert **Mono PCM16 WAV** sowie **Microsoft IMA-ADPCM WAV** (WAVE_FORMAT_DVI_ADPCM = 0x0011), einschließlich `fact`-Sampleanzahl, Blockheader und Low-Nibble-First-Kodierung.
- MP3 und Ogg können weiterhin im SPC-Container gespeichert werden, brauchen für direkte Wiedergabe jedoch einen gesonderten Decoder; die neue C-Runtime meldet dafür einen expliziten Fehler.
- Sicherheitsgrenzen: max. 100.000 Einträge, 64 MiB komprimierte bzw. entpackte Payload pro Eintrag, maximales PCM-Limit, CRC- und Formatintegritätsprüfung.

## DLL-Schnittstelle

```c
int32_t SpeechLoadContainer(const char *path);
int32_t SpeechUnloadContainer(void);
int32_t SpeechGetContainerEntryCount(void);
const char *SpeechGetContainerEntryName(int32_t index);
uint32_t SpeechRenderSample(const char *name, int16_t *pcm, uint32_t capacity);
int32_t SpeechGetLastSampleRate(void);
```

`SpeechRenderSample(name,NULL,0)` liefert die benötigte Anzahl PCM16-Mono-Samples; der Aufruf mit hinreichendem Puffer schreibt die Daten. Puffer werden vom Aufrufer verwaltet. `SpeechGetLastSampleRate()` liefert die tatsächliche Rate des geladenen Samples.

## dBase-Anbindung

```dbase
SET SPEECH ON
SET SPEECH MODE SAMPLES
SAY "Du"
SAY "Du du"
SET SPEECH OFF
```

**Backend-IDs:** 0=Formant, 1=Piper, **2=SPC Samples**. `SAMPLES` ist damit **kein Piper-Alias mehr**. Die Runtime findet den Container in folgender Reihenfolge:

1. Expliziter Aufruf `SpeechLoadContainer(path)` (für C-Anwendungen),
2. Umgebungsvariable `D64_SPEECH_CONTAINER`,
3. `speech.spc` im aktuellen Arbeitsverzeichnis,
4. `speech.spc` im Ordner der EXE (Windows).

Einzelne Satzwörter müssen als Einträge vorhanden sein; z.B. `SAY "Guten Morgen"` benötigt `GUTEN` und `MORGEN`. Die Runtime setzt 25 ms Wortabstand, 5 ms Fade-in/out und erzeugt bei `SpeechSaveWav` 16-Bit-PCM. Dateien eines Satzes müssen dieselbe Abtastrate haben. Fehlende Wörter liefern einen Fehler (Fehler 9), keine automatische Formantsynthese.

## Build und Test

```bash
# Aus MSYS2 MINGW32, kein make:
python speech/build_pe32.py

# Windows-Test, vorab speech.spc bereitstellen:
speech/bin/retro_speech_demo.exe --backend samples --container speech.spc --text "Du du" --wav test.wav --no-play
```

Die Source-Datei `spc_reader.c` wird per `#include` in `retro_speech.c` eingebunden, damit alte Einzeldatei-C99-Buildtests und das PE32-Buildskript weiter funktionieren. Beim eigenen Build **nicht zusätzlich** als separates Objekt neben `retro_speech.c` linken, sonst entstehen doppelte Definitionen.

Das Paket enthält `examples/speech.spc` ohne gzip (läuft ohne zlib1.dll), `examples/speech_gzip.spc` mit gzip und `examples/dbase_speech_samples_stage356.prg`.

Der native Win32-Wiedergabetest ist lokal mangels MSYS2 MINGW32 noch offen.
