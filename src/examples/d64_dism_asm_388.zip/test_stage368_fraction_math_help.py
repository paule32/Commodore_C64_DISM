"""Stage 368: Math fraction canvas regression without Windows/PyQt dependency."""
import ast
from fractions import Fraction
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name('fraction_math_help.py').read_text(encoding='utf-8')
MAIN = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
node = next(n for n in ast.parse(SOURCE).body
            if isinstance(n, ast.ClassDef) and n.name == 'FractionHelpWidget')


class Qt:
    AlignCenter = 1
    AlignLeft = 2
    AlignTop = 4
    TextWordWrap = 8

class Rect:
    def __init__(self, x, y, w, h):
        self._x, self._y, self._w, self._h = x, y, w, h
    def x(self): return self._x
    def y(self): return self._y
    def width(self): return self._w
    def height(self): return self._h
    def center(self): return Point(self._x + self._w / 2, self._y + self._h / 2)

class Point:
    def __init__(self, x, y): self._x, self._y = x, y
    def x(self): return self._x
    def y(self): return self._y

class PainterPath:
    def addRoundedRect(self, *args): pass

class Paint:
    Antialiasing = 1
    TextAntialiasing = 2
    def __init__(self, widget): self.operations = []; self.widget = widget
    def setRenderHint(self, *args): pass
    def fillRect(self, *args): pass
    def fillPath(self, *args): pass
    def setPen(self, *args): pass
    def setFont(self, *args): pass
    def setBrush(self, *args): pass
    def drawPath(self, *args): pass
    def drawLine(self, *args): pass
    def drawRect(self, *args): pass
    def drawText(self, *args):
        self.operations.append(('text', str(args[-1])))
    def translate(self, *args): pass
    def scale(self, *args): pass
    def save(self): pass
    def restore(self): pass
    def end(self): pass

class FakeWidget:
    def __init__(self, parent=None): self._min_height = 0
    def setObjectName(self, name): self.name = name
    def setMinimumSize(self, *args): self.minimum_size = args
    def setMinimumHeight(self, h): self._min_height = h
    def updateGeometry(self): pass
    def update(self): pass
    def rect(self): return Rect(0,0,930,1100)

class FakeFont:
    def __init__(self, *args): pass
    def setPixelSize(self, *args): pass
    def setBold(self, *args): pass

class FakeColor:
    def __init__(self, value): self.value = value

class FakePaintArg:
    def __init__(self, *args): pass

class TestFractionHelp(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = {'QWidget': FakeWidget, 'QRectF': Rect, 'QPointF': Point,
                   'QPainter': Paint, 'QPainterPath': PainterPath,
                   'QPen': FakePaintArg, 'QBrush': FakePaintArg,
                   'QColor': FakeColor, 'QFont': FakeFont, 'Qt': Qt,
                   'Sequence': list, 'Union': object, 'Tuple': tuple, 'EquationCell': object}
        module = ast.Module(body=[node], type_ignores=[])
        exec(compile(ast.fix_missing_locations(module), '<fraction-canvas>', 'exec'), cls.ctx)
        cls.widget_cls = cls.ctx['FractionHelpWidget']

    def test_all_five_pages_render_without_qt(self):
        for mode in self.widget_cls.MODES:
            with self.subTest(page=mode):
                view = self.widget_cls()
                view.activate_fact(mode)
                for dark in (False, True):
                    view.set_dark_mode(dark)
                    output = []
                    original = self.ctx['QPainter']
                    class CapturingPainter(Paint):
                        def end(self): output.extend(self.operations)
                    self.ctx['QPainter'] = CapturingPainter
                    try:
                        view.paintEvent(None)
                    finally:
                        self.ctx['QPainter'] = original
                    self.assertTrue(output)
                    self.assertGreater(view._min_height, 1000)

    def test_reference_math(self):
        self.assertEqual(Fraction(2,3)+Fraction(1,5),Fraction(13,15))
        self.assertEqual(Fraction(5,6)-Fraction(1,4),Fraction(7,12))
        self.assertEqual(Fraction(2,3)*Fraction(1,5),Fraction(2,15))
        self.assertEqual(Fraction(3,4)*Fraction(6,5),Fraction(9,10))
        self.assertEqual(Fraction(2,3)/Fraction(1,5),Fraction(10,3))
        self.assertEqual(Fraction(3,4)/Fraction(6,5),Fraction(5,8))

    def test_tree_and_dock_routing(self):
        import test_stage367_math_rules_widget_init as t
        mw = t.MathWidget()
        rules = mw.facts_tree.children[0]._child_items[0]
        divisibility = next(item for item in rules._child_items if item.label == 'Teilbarkeit')
        frac = divisibility._child_items[0]
        self.assertEqual(frac.label, 'Brüche')
        self.assertEqual([i.label for i in frac._child_items], [
            'Brüche addieren','Brüche subtrahieren',
            'Brüche multiplizieren','Brüche dividieren'])
        for key in self.widget_cls.MODES:
            mw.open_fact(key)
            self.assertIs(mw.content_stack._current, mw.fraction_help_scroll)
        self.assertEqual(mw.fraction_help_widget.theme_calls, [True])
        mw.set_dark_mode(False)
        self.assertEqual(mw.fraction_help_widget.theme_calls, [True,False])

    def test_vectors_not_raster_images(self):
        tree = ast.parse(SOURCE)
        self.assertNotIn('QPixmap(', SOURCE)
        self.assertNotIn('QImage(', SOURCE)
        self.assertIn('QPainterPath', SOURCE)
        self.assertIn('drawText(', SOURCE)
        self.assertIn('drawLine(', SOURCE)
        self.assertEqual(len(self.widget_cls.OVERVIEW),9)

if __name__ == '__main__': unittest.main()
