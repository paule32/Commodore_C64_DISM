# Stage 331 – Custom-Brush-Editor: Layout und Pixelwerkzeuge

Basis: `d64_dism_asm_330.zip`.

- 32 Palettenbuttons unterhalb der Zeichenfläche, angeordnet in zwei horizontalen Zeilen zu je 16 Farben.
- 128×128-Pixel-Kachelvorschau bleibt oben rechts; Pixelwiedergabe in Originalauflösung ohne Raster.
- Links: Width/Height-Spinboxen (1–128), danach Kopieren, Einfügen, Bereinigen, vier Verschiebepfeile und vertikales/horizontales Spiegeln.
- Resize erhält vorhandene Pixel oben links. Vergrößerungen füllen neue Bereiche mit Farbindex 1 (Standardweiß); Verkleinerungen schneiden den außerhalb liegenden Bereich ab.
- Kopieren schreibt das komplette JSON-Muster über den MIME-Typ `application/x-d64-custom-brush+json` sowie ein normales Bild in die Windows-Zwischenablage.
- Einfügen liest den eigenen MIME-Typ und übernimmt Geometrie, Palette und Pixelmatrix; die bisherige Datei-Referenz bleibt unverändert.
- Bereinigen setzt alle Pixel auf Farbindex 1 (Standardweiß); eine bestehende JSON-Datei bleibt auf Disk unverändert bis zu einer expliziten Speicherung.
- Pfeile verschieben jeweils um ein Pixel mit zyklischem Randüberlauf (kein Pixelverlust); Spiegelung vertauscht vertikal oben/unten, horizontal links/rechts.
- Jede Änderung aktualisiert die 128×128-Repeat-Vorschau.
- Die bisherige JSON-Struktur `d64-custom-brush-v1`, bestehende Speicherung und die Formular-Anbindung bleiben erhalten.

## Tests

`python -m unittest -v test_stage330_custom_brush_repeat.py test_stage331_custom_brush_tools.py`

8 Tests bestanden. Python-Syntaxprüfung erfolgreich. Eine visuelle PyQt5-Überprüfung unter Windows steht aus (PyQt5 ist in der Testumgebung nicht installiert).
