"""Stage 364: Algebra/Zinsrechnung im bestehenden Mathematik-Dock, ohne PyQt5.
Testet echte extrahierte Methoden mit schmalen Qt-Testdoubles.
"""
import ast
import textwrap
import unittest
from pathlib import Path

import test_stage367_math_rules_widget_init as math_doubles

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')

def method(cls, name):
    section_start=SOURCE.index('    class '+cls+'(')
    start=SOURCE.index('        def '+name+'(',section_start)
    end=SOURCE.find('\n        def ',start+9)
    if end<0: end=SOURCE.find('\n    class ',start+9)
    region=textwrap.dedent(SOURCE[start:end])
    parsed=ast.parse(region)
    return compile(parsed,'isolated_stage364_'+name+'.py','exec')

class FakeFont:
    def setBold(self,value): self.bold=value
class FakeItem:
    DontShowIndicatorWhenChildless = 0  # Qt5 childless leaf policy
    def __init__(self, args):
        self.label=args[0];self.children=[];self.parent=None;self.data_values={};self.expanded=False
    def font(self,c):return FakeFont()
    def setFont(self,c,f):pass
    def flags(self):return 7
    def setFlags(self,f):pass
    def setChildIndicatorPolicy(self, policy):pass
    def addChild(self,item):self.children.append(item);item.parent=self
    def setData(self,c,r,v):self.data_values[(c,r)]=v
    def setExpanded(self,value):self.expanded=value
    def text(self,c):return self.label
    def data(self,c,r):return self.data_values.get((c,r))
class FakeTree:
    def __init__(self):self.children=[];self.current=None
    def clear(self):self.children=[]
    def addTopLevelItem(self,item):self.children.append(item)
    def setCurrentItem(self,item):self.current=item
    def scrollToItem(self,item):pass
class FakeQt:
    ItemNeverHasChildren = 128
    ItemIsSelectable=1
    UserRole=32
    OtherFocusReason=0

class FakeSlot:
    def __init__(self):self.values=[]
    def emit(self,val):self.values.append(val)

class TestStage364(unittest.TestCase):
    def test_instantiate_cards_with_qt5_compatible_doubles(self):
        """Run the real widget setup / theme path with minimal Qt5 surface."""
        section = SOURCE[SOURCE.index('    class InterestCalculationFactWidget(QWidget):'):
                         SOURCE.index('    class BasicMathRulesFactWidget(QWidget):')]
        section = ''.join(line[4:] if line.startswith('    ') else line
                          for line in section.splitlines(keepends=True))
        class Obj:
            def __init__(self,*args):self.calls=[];self.properties={}
            def __getattr__(self,name):
                def method(*args):self.calls.append((name,args))
                return method
            def font(self):return Obj()
            def setProperty(self,k,v):self.properties[k]=v
        class Frame(Obj):
            NoFrame=0; HLine=4
        class Qt:
            AlignCenter=4; TextSelectableByMouse=8
        ctx={'QWidget':Obj,'QFrame':Frame,'QLabel':Obj,'QVBoxLayout':Obj,
             'QHBoxLayout':Obj,'QGridLayout':Obj,'QFont':Obj,'Qt':Qt}
        exec(compile(section,'stage364_interest_qt_doubles.py','exec'),ctx)
        obj=ctx['InterestCalculationFactWidget']()
        self.assertEqual(len(obj._cards),7)
        self.assertEqual(len([c for c in obj._cards if c.properties.get('interestCard')]),7)
        self.assertFalse(obj._dark_mode)
        obj.set_dark_mode(True)
        self.assertTrue(obj._dark_mode)
        self.assertTrue(any(c[0]=='setStyleSheet' for c in obj.calls))

    def test_tile_content_and_formulas(self):
        section = SOURCE[SOURCE.index('    class InterestCalculationFactWidget(QWidget):'):
                         SOURCE.index('    class BasicMathRulesFactWidget(QWidget):')]
        for expected in (
            'Prozentsatz   =  p', 'Grundwert     =  G', 'Prozentwert   =  W',
            "('Grundwert berechnen', 'G', 'W', 'p', '× 100')",
            "('Prozentwert berechnen', 'W', 'G × p', '100', '')",
            "('Prozentsatz berechnen', 'p', 'W', 'G', '× 100')",
            'G = 30 €', 'W = ?', 'p = 40 %', '40 % = 12,00 €',
            'W = 15 €', 'p = 30 %', '100 % = 50 €',
            'G = 50 €', 'W = 15 €', '2 % = 1 €', '30 % = 15 €',
            'QGridLayout()', 'interest_fraction_bar', 'def set_dark_mode(self, enabled)'
        ):
            with self.subTest(token=expected):self.assertIn(expected,section)
        self.assertIn('interestCard',section)
        self.assertIn('#1c2a3a',section)
        self.assertIn('#ffffff',section)

    def test_tree_hierarchy_existing_geometry_preserved(self):
        ctx={'QTreeWidgetItem':FakeItem,'Qt':FakeQt,
             'BasicMathRulesFactWidget': math_doubles.ctx['BasicMathRulesFactWidget'],
             'AreaFactWidget':type('Area',(),{'FACTS':{
                 'area_rectangle':{'title':'Rechteck'},'area_square':{'title':'Quadrat'}}})}
        exec(method('MathematicsLearningDockWidget','_populate_facts_tree'),ctx)
        class Obj:
            facts_tree=FakeTree()
        obj=Obj()
        ctx['_populate_facts_tree'](obj)
        grund=obj.facts_tree.children[0]
        self.assertEqual(grund.label,'Grundwissen')
        self.assertEqual([x.label for x in grund.children],['Rechengesetze','Algebra','Geometrie','Trigometrie'])
        self.assertEqual([x.label for x in grund.children[0].children],
                         ['Grundrechen-Arten', 'Punkt-vor-Strich-Rechnung', 'Vorzeichen-Regeln',
                          'Teilbarkeit', 'Potenzen', 'Wurzel-Gesetze', 'Kommutativ-Gesetz',
                          'Assoziativ-Gesetz Addition', 'Assoziativ-Geset Multiplikation',
                          'Distributiv-Gesetz'])
        _rules,alg,geo,_trig=grund.children
        self.assertEqual([x.label for x in alg.children],['Zinsrechnung'])
        self.assertEqual(alg.children[0].data(0,FakeQt.UserRole),'interest_calculation')
        self.assertEqual([x.label for x in geo.children],['Flächen','Volumen'])
        self.assertEqual(len(geo.children[1].children),11)
        self.assertIs(obj._fact_items['area_rectangle'].parent,geo.children[0])
        self.assertIs(obj._fact_items['volume_cube'].parent,geo.children[1])

    def test_open_interest_page_in_existing_content_stack(self):
        tree=SOURCE[SOURCE.index('    class MathematicsLearningDockWidget(QWidget):'):
                    SOURCE.index('    class MusicStaffCanvas(QWidget):')]
        self.assertIn('interest_focus_changed = pyqtSignal(bool)',tree)
        self.assertIn("self.interest_focus_changed.emit(fact_key == 'interest_calculation')",tree)
        self.assertIn('self.content_stack.setCurrentWidget(self.interest_calculation_scroll)',tree)
        self.assertIn('self.interest_focus_changed.emit(False)',tree)
        self.assertIn('self.interest_calculation_widget.set_dark_mode(enabled)',tree)
        self.assertNotIn('QDockWidget(',tree)

    def test_focus_hides_and_restores_other_docks(self):
        qt=type('Qt',(),{})
        ctx={'QDockWidget':FakeItem,'QTimer':type('Timer',(),{'singleShot':staticmethod(lambda delay,fn:None)})}
        exec(method('D64DismMainWindow','_set_math_interest_focus'),ctx) if '    class D64DismMainWindow(' in SOURCE else None
        # The main-window class has different name across stages; pull method directly.
        start=SOURCE.index('        def _set_math_interest_focus(self, enabled: bool) -> None:')
        end=SOURCE.index('        def _prepare_math_learning_workspace(',start)
        body=textwrap.dedent(SOURCE[start:end])
        ns={'QDockWidget':FakeItem,'QTimer':ctx['QTimer']}
        exec(body,ns)
        class Dock:
            def __init__(self):self.visible=True;self.blocked=False
            def isVisible(self):return self.visible
            def blockSignals(self,block):old=self.blocked;self.blocked=block;return old
            def hide(self):self.visible=False
            def show(self):self.visible=True
        main,protokoll,other=Dock(),Dock(),Dock()
        class Root:
            math_learning_dock=main
            _math_interest_focus_active=False
            _math_interest_extra_docks=[]
            def findChildren(self,cls):return [main,protokoll,other]
            def _enforce_math_learning_height_limit(self):pass
            def _expand_math_learning_dock(self):pass
        obj=Root()
        ns['_set_math_interest_focus'](obj,True)
        self.assertTrue(main.visible)
        self.assertFalse(protokoll.visible)
        self.assertFalse(other.visible)
        self.assertTrue(obj._math_interest_focus_active)
        ns['_set_math_interest_focus'](obj,False)
        self.assertTrue(protokoll.visible)
        self.assertTrue(other.visible)
        self.assertFalse(obj._math_interest_focus_active)

    def test_no_new_dock_and_existing_dock_kept(self):
        self.assertIn('widget.interest_focus_changed.connect(self._set_math_interest_focus)',SOURCE)
        self.assertIn('self._set_math_interest_focus(False)\n            self._math_learning_workspace_active = False',SOURCE)
        self.assertIn("self._math_interest_focus_active",SOURCE)
        self.assertIn('self.interest_calculation_scroll = _add_fact_scroll_page(',SOURCE)
        self.assertIn("'interest_calculation_scroll_area'",SOURCE)
        self.assertIn('self.resizeDocks([dock], [100000], Qt.Horizontal)',SOURCE)

if __name__=='__main__': unittest.main()
