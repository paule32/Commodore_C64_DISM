# Stage 359 - SPC-Eintrag direkt anhoeren

Verbindliche Ausgangsbasis: Stage 358.

## Neue Option

```powershell
python speechConvert.py -oc samples/deu/deutsch.spc --test GUTENMORGEN
```

- Namen case-insensitiv im SPC1-Index finden.
- Eintragsdaten auf CRC32 pruefen, optional GZIP entpacken.
- Microsoft IMA-ADPCM (Mono, little endian, Low-Nibble zuerst)
  nach 16-Bit-PCM dekodieren; Fact-Samplezahl beruecksichtigen.
- PCM-WAV mit 8/16/24/32 Bit in 16-Bit-Mono umwandeln, falls erforderlich.
- Unter Windows direkt mit `winsound.PlaySound(SND_MEMORY|SND_SYNC)` abspielen.
- Fuer MP3/Ogg bei Bedarf VLC benutzen.
- Rein lesender Testmodus: kein Neuschreiben des Containers.
- Optional mit `--list` und `--verify` kombinieren.

## Pruefungen

- 12 neue Vorschau-Tests (WAV/ADPCM, Plain/GZIP, CRC, Fehlerpfade).
- 40 gezielte Tests der Stages 355-359 bestanden.
- Bitgenaue Uebereinstimmung zwischen Python- und C-Decoder beim Beispiel `du.wav`
  fuer beide SPC-Varianten (5.888 Samples).
- Windows-Soundausgabe hier nicht geprueft.
