"""Stage 344: isolierte Geographie-/Menue-Tests ohne installierten Qt5-Host."""
import ast
import base64
import hashlib
import importlib.util
from pathlib import Path
import struct
import unittest

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / "d64_dism.py").read_text(encoding="utf-8")
EXPECTED_SHA256 = "9cbf9fd3f4b2600ea22e170587e8fa9eb5f3401348707a2464cb5a0bccaa3810"


class Stage344GeographyTests(unittest.TestCase):
    def test_england_reference_png_exact_current_and_lazy(self):
        spec = importlib.util.spec_from_file_location("england", ROOT / "england.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        raw = base64.b85decode(mod.ENGLAND_MAP_IMAGE_B85)
        self.assertEqual(raw[:8], b"\x89PNG\r\n\x1a\n")
        self.assertEqual(hashlib.sha256(raw).hexdigest(), EXPECTED_SHA256)
        self.assertEqual(struct.unpack_from(">II", raw, 16), (371, 463))
        self.assertEqual((mod.ENGLAND_MAP_WIDTH, mod.ENGLAND_MAP_HEIGHT), (371, 463))
        self.assertIn("_free_england_module", SOURCE)

    def test_menu_structure_and_callbacks(self):
        self.assertIn('geography_menu = learning_menu.addMenu("Geographie")', SOURCE)
        self.assertIn('geography_menu.addAction(self.germany_geography_action)', SOURCE)
        self.assertIn('geography_menu.addAction(self.england_geography_action)', SOURCE)
        self.assertNotIn('deutsch_menu = learning_menu.addMenu("Deutsch")', SOURCE)
        self.assertIn('QAction("Deutschland", self)', SOURCE)
        self.assertIn('QAction("England", self)', SOURCE)
        self.assertIn('self.show_england_geography_dock', SOURCE)

    def test_both_docks_and_shared_zoom(self):
        self.assertIn('class EnglandMapDock(QDockWidget)', SOURCE)
        self.assertIn('class EnglandMapView(QGraphicsView)', SOURCE)
        self.assertIn('self._activate_geography_workspace(dock)', SOURCE)
        self.assertIn('self._visible_geography_dock()', SOURCE)
        self.assertIn('dock.blockSignals(True)', SOURCE)
        self.assertIn('dock.map_view.zoomChanged.connect(self._sync_germany_zoom_control_checks)', SOURCE)
        self.assertIn('elif isinstance(widget, (GermanyMapDock, EnglandMapDock, FranceMapDock)):', SOURCE)
        self.assertIn('elif isinstance(widget, (GermanyMapView, EnglandMapView, FranceMapView)):', SOURCE)

    def test_switch_between_countries_preserves_original_layout(self):
        # Die echten MainWindow-Methoden aus AST isoliert ausfuehren;
        # weder eine Qt-Anwendung noch Bilddaten muessen geladen werden.
        wanted = {
            "_visible_geography_dock", "_activate_geography_workspace",
            "_prepare_germany_geography_workspace", "_restore_germany_geography_workspace",
            "_germany_geography_visibility_changed", "_england_geography_visibility_changed",
        }
        tree = ast.parse(SOURCE)
        selected = {}
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in wanted:
                selected[node.name] = node
        self.assertEqual(set(selected), wanted)
        module = ast.Module(body=list(selected.values()), type_ignores=[])
        ast.fix_missing_locations(module)

        class FakeDock:
            def __init__(self, name, visible=False):
                self.name = name
                self.visible = visible
                self.blocked = False
                self.on_visibility = None

            def isVisible(self):
                return self.visible

            def blockSignals(self, value):
                old = self.blocked
                self.blocked = bool(value)
                return old

            def show(self):
                self.visible = True
                if not self.blocked and self.on_visibility:
                    self.on_visibility(True)

            def hide(self):
                self.visible = False
                if not self.blocked and self.on_visibility:
                    self.on_visibility(False)

        class FakeWindow:
            pass

        env = {"QDockWidget": FakeDock}
        exec(compile(module, "<main_window_geography>", "exec"), env)
        for name in wanted:
            setattr(FakeWindow, name, env[name])

        win = FakeWindow()
        side = FakeDock("Projekt", visible=True)
        center = FakeDock("editor", visible=True)
        ger = FakeDock("Deutschland")
        eng = FakeDock("England")
        win.germany_geography_dock = ger
        win.england_geography_dock = eng
        win.findChildren = lambda cls: [side, ger, eng]
        win.centralWidget = lambda: center
        win._disable_germany_zoom_controls = lambda: None
        win._bind_germany_zoom_controls = lambda dock: None
        # Beim Hide im Wechsel duerfen die Restore-Callbacks NICHT laufen.
        ger.on_visibility = win._germany_geography_visibility_changed
        eng.on_visibility = win._england_geography_visibility_changed

        win._activate_geography_workspace(ger)
        self.assertFalse(side.visible)
        self.assertFalse(center.visible)
        self.assertTrue(win._germany_geography_workspace_active)
        ger.visible = True
        win._activate_geography_workspace(eng)
        self.assertFalse(ger.visible)
        self.assertTrue(win._germany_geography_workspace_active)
        self.assertFalse(side.visible)
        self.assertFalse(center.visible)
        self.assertIs(win._active_geography_dock, eng)
        eng.visible = True
        self.assertIs(win._visible_geography_dock(), eng)
        eng.hide()
        self.assertFalse(win._germany_geography_workspace_active)
        self.assertTrue(side.visible)
        self.assertTrue(center.visible)
        self.assertFalse(ger.visible)

        # Gegenrichtung: England oeffnen, nach Deutschland wechseln, schliessen.
        win._activate_geography_workspace(eng)
        eng.visible = True
        win._activate_geography_workspace(ger)
        self.assertFalse(eng.visible)
        self.assertFalse(side.visible)
        self.assertFalse(center.visible)
        ger.visible = True
        ger.hide()
        self.assertTrue(side.visible)
        self.assertTrue(center.visible)
        self.assertFalse(win._germany_geography_workspace_active)


if __name__ == "__main__":
    unittest.main()
