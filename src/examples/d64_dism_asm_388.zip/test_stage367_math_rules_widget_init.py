"""Stage 367: regression for math dock initialization and math-rules routing.

Uses narrowly scoped Qt-compatible test doubles: no PyQt5 dependency.
"""
import ast
from pathlib import Path
import textwrap
import unittest

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
START = SOURCE.index('    class MathematicsLearningDockWidget(QWidget):')
END = SOURCE.index('\n    class MusicStaffCanvas(QWidget):', START)
CLASS = ''.join(line[4:] if line.startswith('    ') else line
                for line in SOURCE[START:END].splitlines(keepends=True))

class Signal:
    def __init__(self):
        self.listeners = []
        self.emissions = []
    def connect(self, callback):
        self.listeners.append(callback)
    def emit(self, *args):
        self.emissions.append(args)

class Attr:
    def __init__(self, *args, **kwargs):
        self.args = args
        self.calls = []
        self.children = []
        self.theme_calls = []
        self._current = None
        self.inputs = {'a': AttrInput()}
    def __getattr__(self, name):
        if name in ('itemDoubleClicked', 'clicked'):
            value = Signal()
            setattr(self, name, value)
            return value
        def fn(*args, **kwargs):
            self.calls.append((name, args, kwargs))
            return None
        return fn
    def __bool__(self): return True
    def addWidget(self, widget, *args):
        self.children.append(widget)
    def addTab(self, widget, text):
        self.children.append(widget)
    def addTopLevelItem(self, item):
        self.children.append(item)
    def clear(self): self.children.clear()
    def setCurrentWidget(self, widget): self._current = widget
    def setCurrentItem(self, item): self._current = item
    def set_dark_mode(self, flag): self.theme_calls.append(flag)
    def font(self, *args): return Attr()
    def flags(self): return 15

class AttrInput:
    def setFocus(self, *_): pass

class FakeTreeItem(Attr):
    DontShowIndicatorWhenChildless = 0  # QTreeWidgetItem.ChildIndicatorPolicy
    def __init__(self, titles):
        super().__init__()
        self.label = titles[0]
        self._data = {}
        self._child_items = []
    def addChild(self, child): self._child_items.append(child)
    def setData(self, column, role, value): self._data[(column, role)] = value
    def data(self, column, role): return self._data.get((column, role))
    def text(self, column): return self.label

class QtType(type):
    def __getattr__(cls, name): return 1
class Qt(metaclass=QtType): pass

class Tab(Attr):
    North = 1
class Frame(Attr):
    NoFrame = 0
class Scroll(Attr):
    AdjustIgnored = 0
class Policy:
    Expanding = 1
    Ignored = 2
    Preferred = 3

def fake_widget_class(name):
    if name == 'AreaFactWidget':
        return type(name, (Attr,), {'FACTS': {
            'area_rectangle': {'title':'Rechteck'},
            'area_circle': {'title':'Kreis'},
        }})
    return type(name, (Attr,), {})

ctx = dict(
    QWidget=Attr,
    QHBoxLayout=Attr, QVBoxLayout=Attr, QSplitter=Attr,
    QTabWidget=Tab, QTreeWidget=Attr, QTreeWidgetItem=FakeTreeItem,
    QLabel=Attr, QPushButton=Attr, QTextBrowser=Attr, QStackedWidget=Attr,
    QScrollArea=Attr, QFrame=Frame, QAbstractScrollArea=Scroll,
    Qt=Qt, QSizePolicy=Policy, pyqtSignal=lambda *args: Signal(),
)
for name in (
    'CantorDiagonalFactWidget', 'PascalTriangleFactWidget',
    'FibonacciSpiralFactWidget', 'InterestCalculationFactWidget',
    'BasicMathRulesFactWidget', 'MathMagic37FactWidget', 'MathMagic88FactWidget', 'MathAmazingFactWidget', 'FractionHelpWidget', 'AreaFactWidget', 'VolumeFactWidget',
    'GeometryCalculatorPanel', 'PrimeSolverFactWidget',
    'NumberPyramidTrainerWidget', 'ArithmeticTrainerWidget',
    'SudokuTrainerWidget', 'IsoMetricMathGameWidget',
    'GorillaParabolaMathGameWidget', 'MathMemoryGameWidget',
):
    ctx[name] = fake_widget_class(name)
    if name == 'BasicMathRulesFactWidget':
        tree = ast.parse(SOURCE)
        cls = next(n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == name)
        assignment = next(n for n in cls.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'MATRIX_TYPES' for t in n.targets))
        ctx[name].MATRIX_TYPES = ast.literal_eval(assignment.value)
        sign_assignment = next(n for n in cls.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SIGN_RULE_CARDS' for t in n.targets))
        ctx[name].SIGN_RULE_CARDS = ast.literal_eval(sign_assignment.value)
exec(compile(CLASS, 'math_widget_stage367_doubles.py', 'exec'), ctx)
MathWidget = ctx['MathematicsLearningDockWidget']

class TestStage367(unittest.TestCase):
    def setUp(self):
        # Executes the REAL entire Qt constructor with test doubles, including
        # initial set_dark_mode() and both fact/game tree population.
        self.math = MathWidget()

    def test_constructor_instantiates_rule_widget_and_scroll_before_theme(self):
        self.assertIsNotNone(self.math.basic_math_rules_widget)
        self.assertIsNotNone(self.math.basic_math_rules_scroll)
        self.assertIn(self.math.basic_math_rules_scroll, self.math.content_stack.children)
        self.assertEqual(self.math.basic_math_rules_widget.theme_calls, [True])
        self.assertEqual(self.math.basic_math_rules_scroll.args[0], self.math.content_stack)

    def test_rules_first_and_existing_fact_tree_kept(self):
        grundwissen = self.math.facts_tree.children[0]
        self.assertEqual(grundwissen.label, 'Grundwissen')
        self.assertEqual([x.label for x in grundwissen._child_items],
                         ['Rechengesetze','Algebra','Geometrie','Trigometrie'])
        rules = grundwissen._child_items[0]
        self.assertEqual([x.label for x in rules._child_items],
                         ['Grundrechen-Arten','Punkt-vor-Strich-Rechnung','Vorzeichen-Regeln','Teilbarkeit','Potenzen','Wurzel-Gesetze','Kommutativ-Gesetz','Assoziativ-Gesetz Addition','Assoziativ-Geset Multiplikation','Distributiv-Gesetz'])
        self.assertEqual([x.label for x in grundwissen._child_items[2]._child_items],
                         ['Flächen','Volumen'])

    def test_each_rule_opens_the_shared_scroll_page(self):
        for key in ('basic_arithmetic','divisibility_rules','powers_rules','calculation_rules',
                    'law_commutative','law_associative_add',
                    'law_associative_multiply','law_distributive','order_of_operations'):
            with self.subTest(key=key):
                self.math.open_fact(key)
                self.assertIs(self.math.content_stack._current,
                              self.math.basic_math_rules_scroll)
                self.assertIn(('activate_fact',(key,''),{}),
                              self.math.basic_math_rules_widget.calls)

    def test_theme_toggle_and_existing_interest_geometry_pages(self):
        self.math.set_dark_mode(False)
        self.assertEqual(self.math.basic_math_rules_widget.theme_calls, [True,False])
        self.math.open_fact('interest_calculation')
        self.assertIs(self.math.content_stack._current, self.math.interest_calculation_scroll)
        self.math.open_fact('area_rectangle')
        self.assertIs(self.math.content_stack._current, self.math.area_fact_scroll)
        self.math.open_fact('volume_cube')
        self.assertIs(self.math.content_stack._current, self.math.volume_fact_scroll)

if __name__ == '__main__':
    unittest.main()
