# Stage 335 – Neues dBase-Programm im Projektbaum

Basis: `d64_dism_asm_334.zip`.

- Im Kontextmenü von `dBase-Programme → Programme` steht **Neu Programm-Datei** als erste Aktion; vorhandene Aktionen bleiben darunter bestehen.
- Klick legt im Projektverzeichnis eine neue, leere `unbenannt.prg` an (bei Konflikt `unbenannt_1.prg` usw.), registriert sie als dBase-Programm im Projektbaum, speichert das Projekt und öffnet den dBase-Editor.
- Der **Speichern unter**-Dialog von dBase-Dokumenten bietet ausschließlich die Filter `.prg`, `.wfm`, `.sql`, `.txt` und alle Dateien `*.*`. Andere Editoren behalten ihre bisherige Filterauswahl.
- Die neue Menüaktion erzeugt absichtlich eine leere Quelldatei ohne Vorlage.

Prüfung: Python-Syntax und gezielter struktureller Regressionstest. Windows-/Qt5-GUI-Laufzeitprüfung steht aus.
