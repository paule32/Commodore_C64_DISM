"""Stage 381: Vorzeichen-Regeln als Sammelblatt auf Ebene Grundrechen-Arten."""
import ast
from pathlib import Path
import unittest
import test_stage367_math_rules_widget_init as harness

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')

class Stage381Tests(unittest.TestCase):
    def test_three_peer_leaves(self):
        widget = harness.MathWidget()
        rules = widget.facts_tree.children[0]._child_items[0]
        self.assertEqual([item.label for item in rules._child_items[:3]],
                         ['Grundrechen-Arten', 'Punkt-vor-Strich-Rechnung', 'Vorzeichen-Regeln'])
        for item in rules._child_items[:3]:
            self.assertFalse(item._child_items)
        self.assertNotIn('sign_mul_minus_minus', widget._fact_items)
        self.assertNotIn('sign_div_plus_plus', widget._fact_items)
        widget.open_fact('sign_rules', 'Vorzeichen-Regeln')
        self.assertIs(widget.content_stack._current, widget.basic_math_rules_scroll)

    def test_all_eight_sign_rules_and_nonoverlapping_card_geometry(self):
        rules = harness.ctx['BasicMathRulesFactWidget'].SIGN_RULE_CARDS
        self.assertEqual(len(rules), 8)
        for title, description, examples in rules.values():
            self.assertTrue(title and description)
            self.assertEqual(len(examples), 2)
            self.assertTrue(all(' = ' in equation for equation in examples))
        cls = next(node for node in ast.walk(ast.parse(SOURCE))
                   if isinstance(node, ast.ClassDef) and node.name == 'BasicMathRulesFactWidget')
        render = next(node for node in cls.body if isinstance(node, ast.FunctionDef)
                      and node.name == '_paint_sign_rules')
        code = ast.get_source_segment(SOURCE, render)
        self.assertIn('card_h = 143', code)
        self.assertIn('card_gap = 15', code)
        self.assertIn("painter.setPen(QColor('#ffd700'))", code)
        self.assertIn('self.SIGN_RULE_CARDS.values()', code)
        self.assertIn('rect.y()+112', code)
        self.assertIn('y += card_h + card_gap', code)

if __name__ == '__main__': unittest.main()
