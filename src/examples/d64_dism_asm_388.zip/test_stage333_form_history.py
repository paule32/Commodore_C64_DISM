"""Stage333 structural regressions (works without PyQt5 on CI)."""
from pathlib import Path


def test_history_contract():
    text = (Path(__file__).resolve().parent / 'd64_dism.py').read_text(encoding='utf-8')
    assert 'self._history_states = []' in text
    assert 'self._history_states.pop(0)' in text
    assert 'len(self._history_states) > 64' in text
    assert 'del self._history_states[self._history_index + 1:]' in text
    assert 'def history_undo(self)' in text and 'def history_redo(self)' in text
    assert 'def _history_restore(self, state)' in text
    assert 'self.removeItem(child)' in text
    assert 'scene.history_reset()  # Neue Datei' in text
    assert 'QShortcut(QKeySequence(key), shortcut_parent)' in text
    assert '("Ctrl+Z", scene.history_undo)' in text
    assert '("Ctrl+Y", scene.history_redo)' in text
    assert 'shortcut.setContext(Qt.WidgetWithChildrenShortcut)' in text

if __name__ == '__main__':
    test_history_contract()
    print('Stage 333: History- und Shortcut-Vertrag OK')
