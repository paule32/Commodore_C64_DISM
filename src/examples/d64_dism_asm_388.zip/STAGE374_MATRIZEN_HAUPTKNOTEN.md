# Stage 374 – Mathematik-Baum: Matrizen als Hauptknoten

Basis: `d64_dism_asm_373.zip`.

Gewünschte Baumstruktur:

```text
Grundwissen
├── Rechengesetze
├── Algebra
├── Geometrie
└── Trigometrie
Matrizen
├── Zeilenmatrix
├── Spaltenmatrix
└── ... (sämtliche bisherigen 38 Matrixarten)
Zahlen
├── Wahrscheinlichkeit
└── Primzahlen
Cantor
└── Diagonal Argument
... (weitere bisherige Hauptknoten bleiben bestehen)
```

Die Matrizen wurden durch `self.facts_tree.addTopLevelItem(matrices)` statt
`grundwissen.addChild(matrices)` auf dieselbe Ebene wie Grundwissen gesetzt.
Alle bisherigen 38 Matrix-Blätter, Navigationskennungen und Ansichten bleiben
erhalten. `Trigometrie` und `Wahrscheinlichkeit` sind bis zur Implementierung
eigener Inhalte nicht auswählbare Kategorien/Platzhalter.
