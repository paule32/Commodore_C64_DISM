# Stage 384 – Lustiges zu Mathe: 88 und Dark-Mode für 37

**Verbindliche Basis:** `d64_dism_asm_383.zip`.

## Änderungen

- Unter `Mathematik → Fakten → Zahlen → Lustiges zu Mathe` existieren nun die
  gleichrangigen Blätter `37` und `88`.
- Neue `MathMagic88FactWidget` als rechte, scrollbare Lernseite.
  Überschrift `The Beauty of Mathematics`, acht nachgerechnete Gleichungen von
  `9 × 9 + 7 = 88` bis `98765432 × 9 + 0 = 888888888` und Schlusszeile
  `Brilliant, isn't it?`.
- **Ausschließlich QLabel-Text** mit `QFont('Times New Roman', ...)`:
  weder Pixelgrafik noch eingebettete Bilddatei. Alle Texte markierbar/kopierbar.
- `MathMagic37FactWidget` verwendet im Dark-Mode keinen beigen Formelbereich mehr.
  Beide Seiten verwenden einen dunklen Hintergrund und weiße Schrift;
  Light-Mode verwendet helle Flächen und dunkle Schrift.
- Die bisherige Fakten-/Geometrie-/Compiler-Navigation bleibt unverändert.

## Verifikation

- Python-Syntax: `python -m py_compile d64_dism.py`
- `test_stage383_math_magic_37.py` (angepasste Baumstruktur)
- `test_stage384_math_magic_88_darkmode.py` (neu, 4 Tests)
- `test_stage367_math_rules_widget_init.py` (neues Qt-Testdouble)
- Gezielte Mathematik-Regressionsgruppe: 21 Tests in Restgruppe bestanden.
- **Einschränkung:** Kein nativer Windows-/PyQt5-GUI-Lauf in dieser Umgebung;
  Navigation und Stilsetzungen wurden mit Qt-kompatiblen Testdoubles geprüft.
