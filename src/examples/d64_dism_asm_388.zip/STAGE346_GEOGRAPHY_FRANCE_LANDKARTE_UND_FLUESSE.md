# Stage 346 - Lernen -> Geographie -> Frankreich -> Landkarte / Flüsse

## Bindende Basis
- Ausgangsbasis: `d64_dism_asm_345.zip`

## Umsetzung
- Das Geographie-Menü enthält nun:
  - `Lernen -> Geographie -> Deutschland`
  - `Lernen -> Geographie -> England`
  - `Lernen -> Geographie -> Frankreich -> Landkarte`
  - `Lernen -> Geographie -> Frankreich -> Flüsse`
- `Frankreich -> Landkarte` zeigt die bereinigte Frankreich-Karte mit deutschen Regionsnamen.
- `Frankreich -> Flüsse` verwendet **dieselbe** eingebettete Landkarte und zeichnet nur Vektorpfade darüber.
- Die Flüsse werden als 2 Pixel breite blaue Overlay-Pfade gezeichnet; es wird keine zweite Frankreich-Bitmap eingebettet.

## Technische Details
- `france.py` wurde auf die bereinigte Frankreich-Landkarte ohne Wasserzeichen umgestellt.
- `FranceMapView` unterstützt jetzt `show_rivers=False/True`.
- `FRANCE_RIVER_PATHS` enthält die Overlay-Polylinien für Seine, Loire, Garonne, Rhône und Rhein.
- Für `Frankreich` existieren jetzt zwei Dock-Varianten:
  - `france_landkarte_geography_dock`
  - `france_rivers_geography_dock`
- Beide Dock-Varianten verwenden denselben Zoom-/Workspace-Mechanismus wie die bestehenden Länder-Docks.

## Tests
- `test_stage345_geography_france.py` aktualisiert:
  - prüft die neue Frankreich-Landkarte
  - prüft das Untermenü `Frankreich` mit `Landkarte` und `Flüsse`
  - prüft das River-Overlay und den Dockwechsel
