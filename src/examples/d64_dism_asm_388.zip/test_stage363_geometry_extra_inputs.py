"""Stage 363: Erweiterte Maße, alternative Gleichungen, Ausrichtung, Titelleiste.
Ohne PyQt5 lauffähig; reale Fensterdarstellung ist gesondert zu prüfen.
"""
import math
import textwrap
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
start = SOURCE.index('    _GEOMETRY_INPUTS = {')
end = SOURCE.index('    class GeometryErrorTitleBar(QFrame):', start)
ctx = {'math':math}
exec(compile(textwrap.dedent(SOURCE[start:end]),'stage363_geometry_core.py','exec'),ctx)
FIELDS = ctx['_GEOMETRY_INPUTS']
SOLVE = ctx['_solve_geometry_fact']
CALC = ctx['_calculate_geometry_fact']

class ExtendedGeometryTests(unittest.TestCase):
    def test_all_19_have_additional_inputs(self):
        self.assertEqual(19,len(FIELDS))
        rect = dict(FIELDS['area_rectangle'])
        for symbol in ('a','b','A','U','d'):
            self.assertIn(symbol,rect)
        self.assertTrue(all('A' in dict(FIELDS[k]) for k in FIELDS if k.startswith('area_')))
        self.assertTrue(all('V' in dict(FIELDS[k]) for k in FIELDS if k.startswith('volume_')))
        self.assertIn('O',dict(FIELDS['volume_sphere']))
        self.assertIn('G',dict(FIELDS['volume_cylinder']))
        self.assertIn('s',dict(FIELDS['volume_cone']))
        self.assertIn('m',dict(FIELDS['area_trapezoid']))
        self.assertIn('p',dict(FIELDS['volume_triangular_prism']))

    def test_rectangle_from_area_or_perimeter_or_diagonal(self):
        cases = [({'A':'24','a':'6'},4,24,math.sqrt(52)),
                 ({'U':'20','a':'6'},4,24,math.sqrt(52)),
                 ({'d':'5','a':'3'},4,12,5)]
        for given,b,area,diagonal in cases:
            with self.subTest(given=given):
                result,_ = SOLVE('area_rectangle',given)
                self.assertAlmostEqual(result['b'],b)
                self.assertAlmostEqual(result['A'],area)
                self.assertAlmostEqual(result['d'],diagonal)
        result,_ = SOLVE('area_rectangle',{'U':'20','A':'24'})
        self.assertAlmostEqual(result['d'],math.sqrt(52))
        self.assertNotIn('a',result)
        self.assertNotIn('b',result)

    def test_more_area_inversions(self):
        pairs=[
            ('area_square',{'U':'20'},'a',5),
            ('area_square',{'d':str(5*math.sqrt(2))},'A',25),
            ('area_triangle',{'A':'16','g':'8'},'h',4),
            ('area_triangle',{'a':'3','b':'4','c':'5'},'A',6),
            ('area_circle',{'U':str(6*math.pi)},'r',3),
            ('area_semicircle',{'A':str(4.5*math.pi)},'d',6),
            ('area_ellipse',{'A':str(8*math.pi),'b':'2'},'a',4),
            ('area_rhombus',{'A':'24','f':'8'},'e',6),
            ('area_rhombus',{'A':'24','a':'5'},'h',4.8),
            ('area_trapezoid',{'A':'16','a':'5','c':'3'},'h',4),
            ('area_trapezoid',{'a':'5','c':'3','h':'4'},'m',4),
        ]
        for fact, raw, symbol, value in pairs:
            with self.subTest(fact=fact,raw=raw):
                result,_=SOLVE(fact,raw)
                self.assertAlmostEqual(result[symbol],value,places=6)

    def test_more_volume_inversions(self):
        pi=math.pi
        pairs=[
          ('volume_cube',{'O':'54'},'a',3),
          ('volume_rectangular',{'V':'24','b':'3','h':'4'},'l',2),
          ('volume_cylinder',{'V':str(36*pi),'r':'3'},'h',4),
          ('volume_cylinder',{'O':str(42*pi),'r':'3'},'h',4),
          ('volume_sphere',{'O':str(36*pi)},'r',3),
          ('volume_hemisphere',{'O':str(27*pi)},'r',3),
          ('volume_ellipsoid',{'V':str(32*pi),'b':'3','c':'4'},'a',2),
          ('volume_cone',{'V':str(12*pi),'h':'4'},'r',3),
          ('volume_cone',{'s':'5','r':'3'},'h',4),
          ('volume_frustum',{'V':str(28*pi),'R':'4','r':'2'},'h',3),
          ('volume_square_pyramid',{'V':'18','a':'3'},'h',6),
          ('volume_rectangular_pyramid',{'V':'12','l':'2','b':'3'},'h',6),
          ('volume_triangular_prism',{'V':'30','b':'3','h':'4'},'l',5),
        ]
        for fact,raw,symbol,value in pairs:
            with self.subTest(fact=fact,raw=raw):
                result,_=SOLVE(fact,raw)
                self.assertAlmostEqual(result[symbol],value,places=6)

    def test_fully_specified_rectangle_can_validate_and_confirm_area(self):
        result, supplied = SOLVE('area_rectangle',
            {'a':'3','b':'4','A':'12','U':'14','d':'5'})
        self.assertEqual(supplied, {'a','b','A','U','d'})
        self.assertEqual(result['A'], 12.0)
        self.assertAlmostEqual(result['d'],5.0)

    def test_consistency_validation(self):
        bad=[
            ('area_rectangle',{'a':'6','b':'4','A':'30'}),
            ('area_rectangle',{'U':'10','A':'50'}),
            ('area_rectangle',{'U':'7','A':'4'}),
            ('area_triangle',{'a':'1','b':'1','c':'9'}),
            ('volume_frustum',{'R':'2','r':'4','h':'1'}),
            ('volume_cone',{'s':'3','h':'5','r':'2'}),
            ('volume_rectangular',{'l':'2','b':'3','h':'4','O':'4'}),
            ('area_circle',{'r':'3','d':'10'}),
            ('volume_cube',{'a':'3','V':'9'}),
            ('volume_ellipsoid',{'O':'100'}),
            ('area_rectangle',{'A':'24'}),
            ('area_rectangle',{}),
        ]
        for fact,raw in bad:
            with self.subTest(fact=fact,raw=raw):
                with self.assertRaises(ValueError):SOLVE(fact,raw)
        for malformed in ('-3','1,5','1e3','a','1.0.0','nan','0'):
            with self.subTest(raw=malformed):
                with self.assertRaises(ValueError):SOLVE('area_circle',{'r':malformed})

    def test_calculation_screen_alignment(self):
        region=SOURCE[SOURCE.index('            def _add_geometry_fact_page(canvas, scroll_name):'):SOURCE.index('            self.area_fact_widget = AreaFactWidget()', SOURCE.index('            def _add_geometry_fact_page(canvas, scroll_name):'))]
        self.assertIn('row.setContentsMargins(10, 0, 10, 12)',region)
        self.assertIn('row.addWidget(calculator, 1, Qt.AlignLeft)',region)
        self.assertNotIn('row.addStretch(3)',region)
        panel=SOURCE[SOURCE.index('    class GeometryCalculatorPanel(QWidget):'):SOURCE.index('    class VolumeFactWidget(QWidget):')]
        self.assertIn('self.input_layout = QGridLayout()',panel)
        self.assertIn('index // 4, index % 4',panel)
        self.assertIn("self.result_edit.setPlaceholderText('Lösung')",panel)
        self.assertIn('self.result_edit.setReadOnly(True)',panel)
        self.assertIn('self.result_edit.setToolTip(result)',panel)

    def test_frameless_dialog_with_movable_gradient_title(self):
        first=SOURCE.index('    class GeometryErrorTitleBar(QFrame):')
        last=SOURCE.index('    class GeometryCalculatorPanel(QWidget):',first)
        code=SOURCE[first:last]
        for token in ('setFixedHeight(39)', 'qlineargradient(', 'mousePressEvent',
                      'mouseMoveEvent', 'event.globalPos()', 'self.dialog.move(',
                      'mouseReleaseEvent', 'Qt.LeftButton', 'GeometryErrorTitleBar(self, dark_mode)',
                      "setText('✕')", "QPushButton('OK'", "border: 3px solid",
                      'Daten Fehlen bzw. sind nicht gültig'):
            self.assertIn(token,code)

if __name__=='__main__':unittest.main()
