"""Stage 354: speech continuity, German lexicon, dBase mode and DLL ABI tests.

Tests use host C99 builds, not a claimed Windows PE32 audio runtime test.
"""
import ctypes
import os
import re
import shutil
import subprocess
import tempfile
import unittest
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'speech'


@unittest.skipUnless(shutil.which('gcc'), 'host C99 compiler required')
class SpeechAmigaFluencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='stage354_')
        cls.dir = Path(cls.temp.name)
        cls.lib = cls.dir / 'libretro354.so'
        subprocess.run(['gcc', '-std=c99', '-O2', '-Wall', '-Wextra', '-Werror',
                        '-shared', '-fPIC', str(SRC / 'retro_speech.c'), '-lm', '-o', str(cls.lib)],
                       capture_output=True, text=True, check=True)
        cls.dll = ctypes.CDLL(str(cls.lib))
        for name in ('SpeechInitialize', 'SpeechSetMix', 'SpeechSetPitch', 'SpeechSetSpeed',
                     'SpeechSetExpression', 'SpeechSetArticulation', 'SpeechSetFluency'):
            f = getattr(cls.dll, name)
            f.argtypes = [ctypes.c_int32]
            f.restype = ctypes.c_int32
        for name in ('SpeechRenderText', 'SpeechRenderPhonemes'):
            f = getattr(cls.dll, name)
            f.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_int16), ctypes.c_uint32]
            f.restype = ctypes.c_uint32
        cls.dll.SpeechSaveWav.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        cls.dll.SpeechSaveWav.restype = ctypes.c_int32
        cls.dll.SpeechGetPhonemeCount.restype = ctypes.c_int32
        cls.dll.SpeechGetLastError.restype = ctypes.c_int32

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        for name, value in [('SpeechInitialize', 22050), ('SpeechSetMix', 85),
                            ('SpeechSetPitch', 125), ('SpeechSetSpeed', 100),
                            ('SpeechSetExpression', 80), ('SpeechSetArticulation', 35),
                            ('SpeechSetFluency', 100)]:
            self.assertEqual(getattr(self.dll, name)(value), 1)

    def render(self, text, direct=False):
        if isinstance(text, str):
            text = text.encode('utf-8')
        f = self.dll.SpeechRenderPhonemes if direct else self.dll.SpeechRenderText
        n = f(text, None, 0)
        self.assertGreater(n, 0, text)
        data = (ctypes.c_int16 * n)()
        self.assertEqual(f(text, data, n), n)
        return list(data)

    def test_expanded_dictionary_valid_distinct_entries(self):
        text = (SRC / 'retro_speech.c').read_text(encoding='utf-8')
        phones_section = text.split('static const Phone phones[] = {', 1)[1].split('};', 1)[0]
        lex_section = text.split('static const Lexicon lexicon[] = {', 1)[1].split('};', 1)[0]
        phones = set(re.findall(r'\{"([^"\n]+)",', phones_section))
        words = re.findall(r'\{"([^"\n]+)",\s*"([^"\n]+)"\}', lex_section)
        self.assertGreaterEqual(len(words), 190)
        self.assertEqual(len(words), len({word for word, _ in words}))
        self.assertEqual([], [(word, token) for word, seq in words
                              for token in seq.split() if token not in phones])
        self.assertEqual(self.dll.SpeechGetPhonemeCount(), 81)

    def test_all_lexicon_entries_can_be_spoken(self):
        text = (SRC / 'retro_speech.c').read_text(encoding='utf-8')
        section = text.split('static const Lexicon lexicon[] = {', 1)[1].split('};', 1)[0]
        words = [key for key, _ in re.findall(r'\{"([^"\n]+)",\s*"([^"\n]+)"\}', section)]
        marker_translation = str.maketrans({'{': 'ä', '|': 'ö', '}': 'ü', '~': 'ß'})
        for word in words:
            with self.subTest(word=word):
                n = self.dll.SpeechRenderText(word.translate(marker_translation).encode('utf-8'), None, 0)
                self.assertGreater(n, 0)

    def test_connected_speech_has_no_artificial_intra_sentence_silence(self):
        pcm = self.render('Hallo ich bin dein Sprachcomputer und wünsche dir einen guten Morgen')
        max_run = run = 0
        for sample in pcm:
            if abs(sample) < 10:
                run += 1
                max_run = max(max_run, run)
            else:
                run = 0
        # Stage 353 had recurring 36 ms silent gaps; now no such extra gaps.
        self.assertLess(max_run, int(0.020 * 22050))

    def test_fluency_changes_pcm_but_not_duration(self):
        self.dll.SpeechSetFluency(0)
        segmented = self.render('Hallo ich bin dein Sprachcomputer')
        self.dll.SpeechSetFluency(100)
        fluent = self.render('Hallo ich bin dein Sprachcomputer')
        self.assertEqual(len(segmented), len(fluent))
        self.assertNotEqual(segmented, fluent)

    def test_punctuation_introduces_proper_pause(self):
        plain = self.render('Hallo ich bin dein Sprachcomputer')
        punct = self.render('Hallo, ich bin dein Sprachcomputer.')
        self.assertGreater(len(punct), len(plain))
        self.assertTrue(any(abs(v) < 5 for v in punct[-1000:]))

    def test_fluency_bounds_and_legacy_controls(self):
        for value in (-1, 101):
            self.assertEqual(self.dll.SpeechSetFluency(value), 0)
            self.assertEqual(self.dll.SpeechGetLastError(), 1)
        self.assertEqual(self.dll.SpeechSetFluency(75), 1)
        self.assertEqual(self.dll.SpeechGetLastError(), 0)
        self.assertGreater(len(self.render('PF A0 N @', True)), 1000)

    def test_lexical_wav_and_cli_preset(self):
        wav = self.dir / 'amiga354.wav'
        self.assertEqual(self.dll.SpeechSaveWav(os.fsencode(wav),
                                                'Guten Morgen, willkommen beim Amiga!'.encode('utf-8')), 1)
        with wave.open(str(wav), 'rb') as reader:
            self.assertEqual((reader.getnchannels(), reader.getframerate(), reader.getsampwidth()),
                             (1, 22050, 2))
            self.assertGreater(reader.getnframes(), 22050)
        exe = self.dir / 'retro_speech_demo'
        subprocess.run(['gcc', '-std=c99', '-Wall', '-Wextra', '-Werror',
                        str(SRC / 'retro_speech_demo.c'), '-L' + str(self.dir),
                        '-lretro354', '-o', str(exe)], check=True, capture_output=True)
        env = {**os.environ, 'LD_LIBRARY_PATH': str(self.dir)}
        result = subprocess.run([str(exe), '--preset', 'amiga', '--fluency', '90',
                                 '--text', 'Hallo Computer', '--no-play', '--wav', str(wav)],
                                env=env, check=True, capture_output=True, text=True)
        self.assertIn('fluency: 90%', result.stdout)

    def test_dbase_speech_modes_and_controls(self):
        from d64dbase.compiler import (DBaseCompilerError, compile_dbase_to_assembly,
                                       parse_dbase_statements)
        src = 'SET SPEECH MODE AMIGA\nSET SPEECH ON\nSET SPEECH FLUENCY 95\nSAY "Hallo!"'
        parsed = parse_dbase_statements(src, filename='speech.prg')
        self.assertTrue(any(getattr(item, 'option', '') == 'fluency' for item in parsed))
        asm = compile_dbase_to_assembly(src, filename='speech.prg', target='pe32').assembly
        for snippet in ('import SpeechSetFluency, "retro_speech.dll", "SpeechSetFluency"',
                        '    call SpeechSetFluency', '__dbase_speech_fluency:', '    push 100', '    push 95'):
            self.assertIn(snippet, asm)
        for src in ('SET SPEECH FLUENCY -1', 'SET SPEECH FLUENCY 101',
                    'SET SPEECH EXPRESSION 101', 'SET SPEECH ARTICULATION 110'):
            with self.subTest(src=src), self.assertRaises(DBaseCompilerError):
                compile_dbase_to_assembly(src, target='pe32')


if __name__ == '__main__':
    unittest.main(verbosity=2)
