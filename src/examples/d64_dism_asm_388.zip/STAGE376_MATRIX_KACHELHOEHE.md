# Stage 376 – Beispielrechnungs-Kacheln vergrößert

Basis: `d64_dism_asm_375.zip`.

- Rechnungskachel: Höhe von 92 auf 192 Pixel (+100 Pixel).
- Die Eltern-Kachel wird anhand der benötigten Gesamthöhe **vor** dem Zeichnen berechnet und erweitert, bei Bedarf auch um mehr als 120 Pixel.
- Zwischenraum (10 Pixel) und unterer Innenabstand (22 Pixel) bleiben innerhalb der Eltern-Kachel.
- Eine oder zwei Rechnungen abhängig vom verfügbaren Platz.
- Matrixform-Kachel wächst bei mehrzeiligen Matrixdaten ebenfalls bei Bedarf.
- Keine Änderungen an den Matrixdaten oder anderen Mathematik-Funktionen.

## Prüfung

`python -m unittest -q test_stage375_matrix_examples test_stage373_math_matrices_close test_stage376_matrix_card_height`

Ein nativer Windows-/PyQt5-Oberflächentest ist weiterhin erforderlich.
