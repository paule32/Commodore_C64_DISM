# Stage 345 – Lernen → Geographie → Frankreich

**Verbindliche Ausgangsbasis:** `d64_dism_asm_344.zip`.

## Menü

```text
Lernen
└─ Geographie
   ├─ Deutschland
   ├─ England
   └─ Frankreich
```

Neuer Eintrag `france_geography_action` mit Callback
`MainWindow.show_france_geography_dock()`; die Deutschland- und England-Aktionen
bleiben unverändert.

## Frankreich-Karte

- Die vom Benutzer bereitgestellte Bilddatei wird **bytegenau unverändert** in `france.py` als Base85 eingebettet und erst beim Öffnen dekodiert.
- Originalformat: PNG RGB, **1000 × 1024 Pixel**; SHA256: `7a13ce143030552237c2314e0e623c5448bc538b13538953d7b44838cb0e2e39`.
- `FranceMapView` (QGraphicsView/QGraphicsScene) mit Zoom 50–400 % über `Ansicht → Zoom` beziehungsweise `STRG + Mausrad`.
- `FranceMapDock` nimmt im Geographie-Workspace den verfügbaren Bereich ein; Dark-/Light-Mode färbt nur die Fläche außerhalb der Karte.
- Nach dem Schließen werden Qt-Bilddaten und die lazy-geladenen Bilddaten freigegeben.
- Die Karte enthält bereits Regionsnamen und Städte im Bild. Sie sind **keine interaktiven Qt-Region-Polygone**; Hover-/Regions-Hit-Testing ist nicht implementiert.

## Länderwechsel und Layout

Die vorhandene Geographie-Workspace-Logik aus Stage 344 wird unverändert gemeinsam genutzt. Frankreich wurde zur Suche des aktiven Landesdocks und zur Dark-/Light-Mode-Verteilung ergänzt. Beim Wechsel Deutschland ↔ England ↔ Frankreich wird das vorherige Karten-Dock mit blockierten Visibility-Signalen ausgeblendet, damit das ursprüngliche Dock-Layout erst beim Schließen des aktiven Geographie-Docks wiederhergestellt wird. Ansicht-Zoom-Aktionen werden an das jeweils aktive Land gebunden.

## Tests

- `python -m py_compile d64_dism.py france.py england.py`
- `python -m unittest test_stage344_geography_menu test_stage345_geography_france -v`: 8 gezielte Tests, darunter Originalbild-Prüfsumme und simulierte Länderwechsel über die echten isolierten MainWindow-Methoden.
- ZIP-Sektions- und Integritätskontrolle.

**Grenze:** Hier ist keine native Windows-PyQt5-GUI verfügbar. Darstellung, Zoom mit echter Maus und das tatsächliche GUI-Verhalten müssen auf Windows überprüft werden.
