# Stage 373 – Mathematik: Schließen, Hochstellungen, Matrizen

Verbindliche Grundlage: Stage 372 (`d64_dism_asm_372.zip`).

## Änderungen

- `MathematicsLearningDockWidget`: rechts in der Tab-Leiste des linken `QTabWidget`, neben den Reitern inklusive „Informationen“, steht ein Button `Schließen` (`setCornerWidget`). Klick löst `close_requested` aus; MainWindow verbindet dieses Signal mit `math_learning_dock.close()`. Damit greift die bestehende Dock-Visibility-/Workspace-Wiederherstellung.
- Potenzen: Drei Formeln mit Caret-Schreibweise wurden auf Unicode-Hochstellungen für Variablen und geklammerte Exponenten umgestellt.
- Unter `Fakten -> Grundwissen` steht der gleichrangige Knoten `Matrizen`, mit 38 eigenständigen Matrixarten als Blattknoten. Jeder Eintrag öffnet rechts im vorhandenen Rechengesetz-Widget eine beschriftete Lernkarte mit Beschreibung und Beispiel. Kategorien sind bewusst eine breite Auswahl gebräuchlicher Typen, keine mathematisch abgeschlossene Liste sämtlicher denkbarer Matrixklassen.
- Bestehende Themen und ihre Navigation bleiben erhalten.

## Tests

`python -m unittest -q test_stage373_math_matrices_close test_stage367_math_rules_widget_init test_stage370_potenzen_leaf_items test_stage372_england_flag test_stage344_geography_menu`

Ergebnis: 16 Tests erfolgreich (Testdoubles ohne PyQt5, inklusive Syntaxprüfung). Ein nativer Windows-/PyQt5-GUI-Lauf wurde hier nicht durchgeführt.
