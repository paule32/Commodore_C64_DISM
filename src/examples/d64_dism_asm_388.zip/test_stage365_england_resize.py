# -*- coding: utf-8 -*-
"""Stage 365: England map must not depend on France river-hover state."""
import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / 'd64_dism.py').read_text(encoding='utf-8')


def class_tree(name, successor):
    part = SOURCE[SOURCE.index('class ' + name + '('):SOURCE.index('\nclass ' + successor + '(')]
    return next(node for node in ast.parse(part).body if isinstance(node, ast.ClassDef)), part


class Stage365EnglandResizeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.england, cls.england_text = class_tree('EnglandMapView', 'EnglandMapDock')
        cls.france, cls.france_text = class_tree('FranceMapView', 'FranceMapDock')

    def test_england_has_no_france_specific_event_handlers(self):
        methods = {m.name: m for m in self.england.body if isinstance(m, ast.FunctionDef)}
        self.assertIn('resizeEvent', methods)
        self.assertNotIn('mouseMoveEvent', methods)
        self.assertNotIn('leaveEvent', methods)
        self.assertIn('wheelEvent', methods)
        self.assertIn('release_resources', methods)
        forbidden={'_show_rivers','_active_river_overlay','_river_info_label','_find_river_at_scene_pos','_hide_river_overlay'}
        fields={n.attr for n in ast.walk(self.england) if isinstance(n,ast.Attribute)}
        self.assertFalse(forbidden & fields, forbidden & fields)

    def test_england_resize_can_run_before_loading_any_france_state(self):
        resize = next(n for n in self.england.body if isinstance(n,ast.FunctionDef) and n.name=='resizeEvent')
        code=ast.Module(body=[ast.ClassDef(name='EnglandMapView',bases=[ast.Name(id='FakeQGraphicsView',ctx=ast.Load())],keywords=[],body=[resize],decorator_list=[])],type_ignores=[])
        ast.fix_missing_locations(code)
        class FakeQGraphicsView:
            def resizeEvent(self,event):
                self.called.append(('base_resize',event))
        ns={'FakeQGraphicsView':FakeQGraphicsView}
        exec(compile(code,'<england_resize>','exec'),ns)
        widget=ns['EnglandMapView']()
        widget.called=[]
        widget._apply_zoom=lambda:widget.called.append(('apply_zoom',))
        evt=object()
        # Stage 364 raised AttributeError when this event fired.
        widget.resizeEvent(evt)
        self.assertEqual(widget.called, [('base_resize',evt),('apply_zoom',)])
        widget.resizeEvent(evt)
        self.assertEqual(len(widget.called),4)

    def test_france_fluss_hover_unchanged(self):
        methods={m.name:m for m in self.france.body if isinstance(m,ast.FunctionDef)}
        self.assertTrue({'resizeEvent','mouseMoveEvent','leaveEvent','_hide_river_overlay','_reposition_river_overlay'} <= set(methods))
        self.assertIn('self._show_rivers', self.france_text)
        self.assertIn('self._reposition_river_overlay',self.france_text)
        self.assertIn('self._hide_river_overlay()',self.france_text)

    def test_germany_and_england_share_simple_resize_layout(self):
        germany,_=class_tree('GermanyMapView','GermanyMapDock')
        e=next(n for n in self.england.body if isinstance(n,ast.FunctionDef) and n.name=='resizeEvent')
        g=next(n for n in germany.body if isinstance(n,ast.FunctionDef) and n.name=='resizeEvent')
        self.assertEqual(ast.dump(ast.Module(body=e.body,type_ignores=[]),include_attributes=False),
                         ast.dump(ast.Module(body=g.body,type_ignores=[]),include_attributes=False))

if __name__=='__main__':
    unittest.main()
