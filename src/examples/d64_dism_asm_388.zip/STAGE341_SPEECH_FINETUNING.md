# Stage 341 – Feintuning der Retro-Hybrid-Sprachausgabe

**Verbindliche Basis:** d64_dism_asm_340.zip.

## Implementierung

`speech/retro_speech.c` implementiert weiterhin eine eigenstaendige
C99-Formantsynthese ohne Sprachsamples und ohne externe Text-to-Speech-Dienste.
Das Finetuning verbessert die vorhandenen DSP- und Sprachregeln:

1. Wortakzente auf ausgewaehlten Vokalen; grammatische Kurzwoerter bleiben
   standardmaessig unbetont. Einige haeufige Fremdwoerter nutzen abweichende
   Betonung. Vokaldauer +18 ms bei Akzent.
2. Aussage-, Frage- und Ausrufsaetze unterscheiden sich in ihrer F0-Kontur.
   Bei Fragezeichen steigt die Tonhoehe zum Ende der gesprochenen Phrase,
   unabhaengig von der folgenden Satzpause.
3. Eine kontinuierlich geglaettete Grundfrequenz und neue Formantuebergaenge
   ersetzen die bisher starre Lautkette. Stimmhafte Nachbarlaute werden an
   ihrer gemeinsamen Grenze nicht mehr vollstaendig auf null ausgeblendet.
4. Ausgewaehlte deutsche Lautgruppen und Wortendungen besitzen zusaetzliche
   Umwandlungsregeln (`ck`, `pf`, `ph`, `th`, `-er`, `-en`, `aa`, `ee`, `oo`).
5. Eine einfache weiche Pegelbegrenzung vermeidet starke harte Spitzen.

## Neue DLL-Exporte

- `SpeechSetExpression(int32_t percent)` (`__stdcall`, 0..100; Vorgabe 60)
- `SpeechSetArticulation(int32_t percent)` (`__stdcall`, 0..100; Vorgabe 65)

Die bisherigen Exportfunktionen bleiben ABI-kompatibel. Der unveraenderte
Stage-340-PE32-Build erzeugt ueber `--add-stdcall-alias` beide Exportnamen.

## Demo

`retro_speech_demo.exe --preset c64|hybrid|amiga` setzt Profile fuer Mix,
Tonhoehe, Tempo, Ausdruck und Artikulation. Alle Parameter koennen danach
mit `--mix`, `--pitch`, `--speed`, `--expression`, `--articulation`
individuell uebersteuert werden. CLI-Parameter werden von links nach rechts
angewandt.

Beispiel:

    python speech/build_pe32.py
    speech/bin/retro_speech_demo.exe --preset hybrid --expression 75

## Pruefung

- `test_stage341_speech_finetune.py`: DSP-Parameter und Grenzen,
  Frageintonation auch bei kurzem Satz, PCM-Determinismus, WAV,
  direkte Phonemfolgen, deutsche Woerter und drei CLI-Profile.
- Bestehende Tests Stages 339 und 340 weiterhin erfolgreich.
- Host: GCC C99 mit `-Wall -Wextra -Werror`; dynamische Demo via `.so`
  testweise gelinkt und ausgefuehrt.
- **Nicht getestet:** Kompilierung und Audioausgabe auf Windows 10/MINGW32.
  Dafuer ist weiterhin ein nativer Test auf dem Rechner des Nutzers notwendig.

## Grenzen

Kein Machine-Learning-Finetuning, kein natuerlicher Neural-TTS-Klang.
Die deutsche Graphem-zu-Phonem-Konvertierung ist noch heuristisch.
Keine nativen dBase-`SAY`-Befehle in dieser Stage; das bleibt ein naechster
Integrationsschritt. Externe MinGW32-Toolchain wird nur fuer die Sprach-DLL und
Demo benoetigt, nicht fuer zukuenftige mit d64_dism erstellte dBase-Programme.
