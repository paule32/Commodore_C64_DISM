# Stage 358 – Diagnose und Fallback für Windows-Piper-Absturz 0xC0000409

Grundlage: `d64_dism_asm_357.zip` / `speechConvert.py` aus Stage 357.

## Anlass

Der Aufruf

```powershell
python speechConvert.py --text "Guten Morgen" -a GUTENMORGEN -l de_DE --voice kerstin --quality low -gz -oc samples/deu/deutsch.spc
```

lieferte `Piper hat keine WAV-Datei erzeugt (Exit 3221226505)`.
Dieser Status entspricht `0xC0000409` (Windows Fail Fast / STATUS_STACK_BUFFER_OVERRUN). Er bedeutet nicht zwingend, dass die Python-Containerverwaltung einen Speicherfehler hat; er stammt aus dem gestarteten Piper-Prozess. Für die ältere Windows-Ausgabe von Piper 1.2.0 wurden Abstürze genau dieses Typs während der ONNX-Modellinitialisierung gemeldet (https://github.com/OHF-Voice/piper1-gpl/issues/260, https://github.com/rhasspy/piper/issues/681).

## Neue CLI-Optionen

| Argument | Bedeutung |
|---|---|
| `--piper-backend auto` | Standard: EXE; nur bei fehlendem EXE-Programm oder Exit 0xC0000409 Python-Piper ausprobieren |
| `--piper-backend exe` | Nur bisherige native `piper.exe` ausführen |
| `--piper-backend python` | `python -m piper` statt `piper.exe` ausführen |
| `--piper-python <PFAD>` | Eigenen Python-Interpreter für das Python-Backend verwenden (z.B. ein venv) |

Der Python-Fallback ist bewusst **nicht** für beliebige Fehler aktiv. Syntaxfehler, falsche Modelle und sonstige Fehler liefern wie bisher eine klare Fehlermeldung. Die Fehlermeldung enthält nun den dezimalen und hexadezimalen Exit-Code sowie stdout/stderr von Piper, soweit vorhanden.

## Alternative Installation unter Windows

```powershell
python -m pip install --upgrade piper-tts
python speechConvert.py --text "Guten Morgen" -a GUTENMORGEN -l de_DE --voice kerstin --quality low -gz -oc samples/deu/deutsch.spc --piper-backend python
```

Die Paket-Installation muss im gleichen Python erfolgen, das `speechConvert.py` verwendet, oder über `--piper-python` gezielt angegeben werden.

Das Modell `de_DE-kerstin-low.onnx` und die Datei `de_DE-kerstin-low.onnx.json` müssen wie bisher lokal installiert sein. Die neuere Python-Variante von Piper bietet den Aufruf `python -m piper` an; ob diese Variante einen möglichen ONNX-Runtime-Konflikt auf dem konkreten Windows-System umgeht, ist noch **nicht** nachgewiesen.

## Unabhängiger Test der nativen EXE

```powershell
"Guten Morgen" | .\speech\piper\piper.exe --model .\speech\piper\de_DE-kerstin-low.onnx --output_file test.wav
$LASTEXITCODE
```

Wenn derselbe Exit-Code dabei erscheint, ist der Crash von `speechConvert.py` unabhängig. `winver` zeigt die Windows-Buildnummer. Für eine genauere Untersuchung kann die Windows-Ereignisanzeige beim abgestürzten Prozess und dem fehlerhaften Modul helfen.

## Teststatus

- 7 zusätzliche Tests für Fehlertext, NTSTATUS, selektiven Fallback, Python-Backend und unveränderte Container bei Fehlern.
- 9 bestehende Stage-357-Tests (Merge, Stimmenauswahl, simulierte Piper-Ausgabe).
- 7 bestehende Stage-356-Tests (SPC-Lesen, gzip, CRC, IMA-ADPCM, nativer C-Decoder).
- 19 bestehende Stage-353–355-Sprachtests.
- 42 Tests insgesamt auf diesem Linux-Build erfolgreich; die native Windows-Piper-Ausführung konnte hier nicht getestet werden.

SPC-Format, dBase-Compiler und bestehende DLL bleiben unverändert.
