"""Stage 343: Sprachimporte bleiben Namen, veraltete DLLs werden ersetzt."""
from __future__ import annotations
import ast
from pathlib import Path
import shutil
import tempfile
import textwrap
import unittest
from unittest import mock

from regression_test_helpers import pe_namespace

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / 'd64_dism.py').read_text(encoding='utf-8')


def get_method(name):
    tree = ast.parse(SOURCE)
    method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name)
    return textwrap.dedent(ast.get_source_segment(SOURCE, method))


class OrdinalImportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ns = pe_namespace()

    def test_speech_import_by_name_without_any_runtime_dll(self):
        source = (
            'import SpeechSetExpression, "retro_speech.dll", "SpeechSetExpression"\n'
            'import SpeechSetArticulation, "retro_speech.dll", "SpeechSetArticulation"\n'
            'import SpeechSpeakCP1252, "retro_speech.dll", "SpeechSpeakCP1252"\n'
        )
        result = self.ns['rewrite_pe_assembly_imports_to_ordinals'](
            source, target='pe32', search_paths=(), require_all=True)
        self.assertEqual(result, source)

    def test_other_imports_still_follow_ordinal_option(self):
        source = (
            'import SpeechSetExpression, "retro_speech.dll", "SpeechSetExpression"\n'
            'import ExitProcess, "kernel32.dll", "ExitProcess"\n'
        )
        ns = dict(self.ns)
        called = []
        def fake_convert(specs, **opts):
            called.extend(specs.values())
            self.assertTrue(opts['require_all'])
            return {key: (dll, 123) for key, (dll, func) in specs.items()}
        ns['_pe_import_specs_with_local_ordinals'] = fake_convert
        f = ns['rewrite_pe_assembly_imports_to_ordinals']
        # The global lookup belongs to the function's original namespace.
        with mock.patch.dict(f.__globals__, {'_pe_import_specs_with_local_ordinals': fake_convert}):
            result = f(source, target='pe32', require_all=True)
        self.assertIn('import SpeechSetExpression, "retro_speech.dll", "SpeechSetExpression"', result)
        self.assertIn('import ExitProcess, "kernel32.dll", "#123"', result)
        self.assertEqual(called, [('kernel32.dll','ExitProcess')])

    def test_low_level_import_optimizer_preserves_speech_names(self):
        optimize = self.ns['_pe_import_specs_with_local_ordinals']
        result = optimize(
            {'speech':('retro_speech.dll','SpeechSetExpression')},
            machine=self.ns['IMAGE_FILE_MACHINE_I386'], enabled=True,
            require_all=True, search_paths=())
        self.assertEqual(result['speech'], ('retro_speech.dll','SpeechSetExpression'))

    def test_speech_can_be_linked_by_name_through_internal_pe32_linker(self):
        from d64dbase.compiler import compile_dbase_to_assembly
        src = 'SET SPEECH ON\nSET SPEECH MODE HYBRID\nSAY "Hallo"'
        asm = compile_dbase_to_assembly(src, filename='speech.prg', target='pe32').assembly
        rewritten = self.ns['rewrite_pe_assembly_imports_to_ordinals'](
            asm, target='pe32', search_paths=(), require_all=False)
        self.assertIn('import SpeechSetExpression, "retro_speech.dll", "SpeechSetExpression"', rewritten)
        pe = self.ns
        pe['PE32_TEXT_COMPRESSION_MSZIP_DEFAULT'] = False
        obj = pe['write_coff32_object'](pe['assemble_pe32_object_source'](rewritten))
        linked = pe['link_coff32_objects']([obj], entry_symbol='_start', gui=True)
        self.assertIn(b'retro_speech.dll', linked.executable)
        self.assertIn(b'SpeechSetExpression',linked.executable)


class RuntimeDeploymentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        code = get_method('_prepare_dbase_speech_runtime')
        cls.method_ns = {
            'Path':Path, 'shutil':shutil,
            'IMAGE_FILE_MACHINE_I386':0x014c,
            '__file__':str(ROOT / 'd64_dism.py'),
        }
        exec(code, cls.method_ns)
        cls.prepare = staticmethod(cls.method_ns['_prepare_dbase_speech_runtime'])

    def test_replaces_stale_examples_dll_with_updated_speech_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            output = root / 'examples' / 'hello.exe'
            output.parent.mkdir()
            old = output.parent / 'retro_speech.dll'
            old.write_bytes(b'OLD_DLL')
            new = root / 'speech' / 'bin' / 'retro_speech.dll'
            new.parent.mkdir(parents=True)
            new.write_bytes(b'CURRENT_DLL')
            required = (
                'SpeechInitialize SpeechSetMix SpeechSetPitch SpeechSetSpeed '
                'SpeechSetExpression SpeechSetArticulation SpeechSpeak '
                'SpeechSpeakCP1252 SpeechShutdown'
            ).split()
            def exports(path, machine):
                return {name:n for n,name in enumerate(required,1)} if path.read_bytes()==b'CURRENT_DLL' else {'SpeechInitialize':1}
            class GUI:
                current_directory = root
                def __init__(self): self.logs=[];self.errors=[]
                def log(self,msg):self.logs.append(msg)
                def show_error(self,title,message):self.errors.append((title,message))
            gui=GUI()
            f=self.method_ns['_prepare_dbase_speech_runtime']
            with mock.patch.dict(self.method_ns, {'_pe_export_name_ordinals':exports}):
                self.assertTrue(f(gui,output))
            self.assertEqual(old.read_bytes(),b'CURRENT_DLL')
            self.assertFalse(gui.errors)
            self.assertTrue(any('speechsetexpression' in msg.lower() for msg in gui.logs))

    def test_incompatible_dll_without_new_build_shows_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            output=root/'examples'/'hello.exe'
            output.parent.mkdir()
            (output.parent/'retro_speech.dll').write_bytes(b'OLD_DLL')
            class GUI:
                current_directory=root
                def __init__(self):self.errors=[]
                def log(self, msg):pass
                def show_error(self, title, message):self.errors.append((title,message))
            gui=GUI()
            f=self.method_ns['_prepare_dbase_speech_runtime']
            with mock.patch.dict(self.method_ns, {'_pe_export_name_ordinals':lambda *a:{'SpeechInitialize':1}}):
                self.assertFalse(f(gui,output))
            self.assertIn('retro_speech.dll', gui.errors[0][0])

    def test_workstation_checks_dll_before_start(self):
        source = get_method('_launch_assembled_document')
        self.assertLess(source.index('_prepare_dbase_speech_runtime(output_path)'),
                        source.index('_launch_via_workstation_runner('))
        self.assertNotIn('_prepare_dbase_speech_runtime(output_path)',
                         get_method('_launch_dbase_qt5_gui'))

if __name__ == '__main__':
    unittest.main(verbosity=2)
