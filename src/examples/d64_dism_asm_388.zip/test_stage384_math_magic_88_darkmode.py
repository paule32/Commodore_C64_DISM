"""Stage 384: 37/88 in Dark-Mode dunkel und weiss; 88 als Times-New-Roman-Text.

Tests laufen ohne installierte Qt-Runtime mit realem Quelltext, Qt-Testdoubles.
"""
import ast
from pathlib import Path
import unittest

import test_stage367_math_rules_widget_init as doubles
from test_stage383_math_magic_37 import RecordingFont, build_font_page

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)


def build_magic_88_page():
    cls = next(n for n in ast.walk(TREE)
               if isinstance(n, ast.ClassDef) and n.name == 'MathMagic88FactWidget')
    module = ast.Module(body=[cls], type_ignores=[])
    ast.fix_missing_locations(module)
    ctx = dict(QWidget=doubles.Attr, QVBoxLayout=doubles.Attr,
               QFrame=doubles.Frame, QLabel=doubles.Attr,
               QFont=RecordingFont, Qt=doubles.Qt)
    exec(compile(module, 'math_magic_88_qt_doubles.py', 'exec'), ctx)
    return ctx['MathMagic88FactWidget']


def last_style(page):
    return next(args[0] for name, args, _ in reversed(page.calls)
                if name == 'setStyleSheet')


class Stage384MathMagicTests(unittest.TestCase):
    def test_88_equations_are_mathematically_correct_and_in_order(self):
        page = build_magic_88_page()()
        expected = [
            '9 × 9 + 7 = 88',
            '98 × 9 + 6 = 888',
            '987 × 9 + 5 = 8888',
            '9876 × 9 + 4 = 88888',
            '98765 × 9 + 3 = 888888',
            '987654 × 9 + 2 = 8888888',
            '9876543 × 9 + 1 = 88888888',
            '98765432 × 9 + 0 = 888888888',
        ]
        self.assertEqual([label.args[0] for label in page.equation_labels], expected)
        for equation in expected:
            left, right = equation.split(' = ')
            first, rest = left.split(' × 9 + ')
            self.assertEqual(int(first) * 9 + int(rest), int(right))
        self.assertEqual(page.title_label.args[0], 'The Beauty of Mathematics')
        self.assertEqual(page.caption_label.args[0], "Brilliant, isn't it?")

    def test_every_88_label_has_times_new_roman_and_selectable_text(self):
        page = build_magic_88_page()()
        for label in [page.title_label, *page.equation_labels, page.caption_label]:
            (font,) = next(args for name, args, _ in label.calls if name == 'setFont')
            self.assertEqual(font.family, 'Times New Roman')
            self.assertTrue(font.bold)
            self.assertIn(('setTextInteractionFlags',
                           (doubles.Qt.TextSelectableByMouse,), {}), label.calls)
        cls = next(n for n in ast.walk(TREE)
                   if isinstance(n, ast.ClassDef) and n.name == 'MathMagic88FactWidget')
        snippet = ast.get_source_segment(SOURCE, cls)
        for pixel in ('QPixmap(', 'QImage(', 'setPixmap(', 'QPainter('):
            self.assertNotIn(pixel, snippet)

    def test_37_and_88_share_dark_bright_theme_contrast(self):
        for builder in (build_font_page, build_magic_88_page):
            with self.subTest(page=builder.__name__):
                page = builder()()
                dark = last_style(page)
                self.assertIn('background: #151e2b', dark)
                self.assertIn('background: #1c2939', dark)
                self.assertIn('color: #ffffff', dark)
                self.assertNotIn('#f9f1dc', dark)
                page.set_dark_mode(False)
                light = last_style(page)
                self.assertIn('background: #f8f6f1', light)
                self.assertIn('color: #181818', light)

    def test_navigation_for_88_and_37_without_affecting_other_nodes(self):
        dock = doubles.MathWidget()
        zahlen = dock.facts_tree.children[2]
        funny = zahlen._child_items[2]
        self.assertEqual(funny.label, 'Lustiges zu Mathe')
        self.assertEqual([node.label for node in funny._child_items], ['37', '88', 'Amazing'])
        magic_88 = funny._child_items[1]
        self.assertEqual(magic_88.data(0, doubles.Qt.UserRole), 'math_magic_88')
        self.assertIs(dock._fact_items['math_magic_88'], magic_88)
        self.assertIn(dock.math_magic_88_scroll, dock.content_stack.children)
        self.assertEqual(dock.math_magic_88_widget.theme_calls, [True])
        dock.open_fact('math_magic_88', '88')
        self.assertIs(dock.content_stack._current, dock.math_magic_88_scroll)
        dock.open_fact('math_magic_37', '37')
        self.assertIs(dock.content_stack._current, dock.math_magic_37_scroll)
        dock.set_dark_mode(False)
        self.assertEqual(dock.math_magic_88_widget.theme_calls, [True, False])
        self.assertEqual(dock.math_magic_37_widget.theme_calls, [True, False])


if __name__ == '__main__':
    unittest.main()
