"""Stage 385: Amazing-Blatt, nine correct equations, text, navigation/themes."""
import ast
from pathlib import Path
import unittest

import test_stage367_math_rules_widget_init as doubles
from test_stage383_math_magic_37 import RecordingFont

SOURCE=Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)


def build_amazing_page():
    cls=next(x for x in ast.walk(TREE) if isinstance(x,ast.ClassDef) and x.name=='MathAmazingFactWidget')
    module=ast.Module(body=[cls], type_ignores=[])
    ast.fix_missing_locations(module)
    ctx=dict(QWidget=doubles.Attr, QVBoxLayout=doubles.Attr,
             QFrame=doubles.Frame, QLabel=doubles.Attr,
             QFont=RecordingFont, Qt=doubles.Qt)
    exec(compile(module,'math_amazing_qt_doubles.py','exec'),ctx)
    return ctx['MathAmazingFactWidget']


def last_style(page):
    return next(args[0] for name,args,_ in reversed(page.calls) if name=='setStyleSheet')


class Stage385AmazingTests(unittest.TestCase):
    def test_nine_equations_match_reference_and_are_true(self):
        page=build_amazing_page()()
        self.assertEqual(page.title_label.args[0],"It's Amazing!")
        expected=[
            '1 × 8 + 1 = 9',
            '12 × 8 + 2 = 98',
            '123 × 8 + 3 = 987',
            '1234 × 8 + 4 = 9876',
            '12345 × 8 + 5 = 98765',
            '123456 × 8 + 6 = 987654',
            '1234567 × 8 + 7 = 9876543',
            '12345678 × 8 + 8 = 98765432',
            '123456789 × 8 + 9 = 987654321',
        ]
        self.assertEqual([label.args[0] for label in page.equation_labels],expected)
        for equation in expected:
            operation,expected_answer=equation.split(' = ')
            left,n=operation.split(' × 8 + ')
            self.assertEqual(int(left)*8+int(n),int(expected_answer))
        self.assertNotIn('Like our page',SOURCE[SOURCE.index('    class MathAmazingFactWidget'):SOURCE.index('    class MathematicsLearningDockWidget')])
        self.assertNotIn('Learn 2 Think',SOURCE[SOURCE.index('    class MathAmazingFactWidget'):SOURCE.index('    class MathematicsLearningDockWidget')])

    def test_times_new_roman_text_and_no_bitmaps(self):
        page=build_amazing_page()()
        for label in [page.title_label,*page.equation_labels]:
            font=next(args[0] for name,args,_ in label.calls if name=='setFont')
            self.assertEqual(font.family,'Times New Roman')
            self.assertTrue(font.bold)
            self.assertIn(('setTextInteractionFlags',(doubles.Qt.TextSelectableByMouse,),{}),label.calls)
        cls=next(x for x in ast.walk(TREE) if isinstance(x,ast.ClassDef) and x.name=='MathAmazingFactWidget')
        snippet=ast.get_source_segment(SOURCE,cls)
        for forbidden in ('QPixmap(', 'QImage(', 'setPixmap(', 'QPainter('):
            self.assertNotIn(forbidden,snippet)

    def test_dark_light_appearance_and_red_multiplier_are_native_text(self):
        page=build_amazing_page()()
        style=last_style(page)
        self.assertIn('background: #151e2b',style)
        self.assertIn('background: #1c2939',style)
        self.assertIn('color: #ffffff',style)
        self.assertIn('color: #ff7474',style)
        for label in page.equation_labels:
            markup=next(args[0] for name,args,_ in reversed(label.calls) if name=='setText')
            self.assertIn('<span style="color:#ff7474;">8</span>',markup)
        page.set_dark_mode(False)
        style=last_style(page)
        self.assertIn('background: #f8f6f1',style)
        self.assertIn('color: #181818',style)
        self.assertIn('color: #ad2222',style)

    def test_navigation_and_theme_do_not_disrupt_37_88(self):
        dock=doubles.MathWidget()
        funny=dock.facts_tree.children[2]._child_items[2]
        self.assertEqual([x.label for x in funny._child_items],['37','88','Amazing'])
        item=funny._child_items[2]
        self.assertEqual(item.data(0,doubles.Qt.UserRole),'math_amazing')
        self.assertIs(dock._fact_items['math_amazing'],item)
        self.assertIn(dock.math_amazing_scroll,dock.content_stack.children)
        self.assertEqual(dock.math_amazing_widget.theme_calls,[True])
        dock.open_fact('math_amazing','Amazing')
        self.assertIs(dock.content_stack._current,dock.math_amazing_scroll)
        for key,widget in [('math_magic_37',dock.math_magic_37_scroll),('math_magic_88',dock.math_magic_88_scroll)]:
            dock.open_fact(key)
            self.assertIs(dock.content_stack._current,widget)
        dock.set_dark_mode(False)
        self.assertEqual(dock.math_amazing_widget.theme_calls,[True,False])


if __name__=='__main__':
    unittest.main()
