# Stage 349 – Geografisch belegte Frankreich-Flüsse

## Verbindliche Grundlage

`d64_dism_asm_348.zip`, nur die Fluss-Overlay-SVG-Grafik und ihre Anbindung wurden verändert; Deutschland/England/Frankreich-Menüs, Landkarte, Zoom und Dock-Anordnung bleiben erhalten.

## Datenquelle und Lizenz

- Quelle: GSHHG / CIA World Data Bank II (WDBII), Linien der Fließgewässer in geografischen WGS84-Koordinaten.
- Ausgangsdaten: `basemap-data` 2.0.0 / GSHHG v2.3.6, `rivers_i.dat` (mittlere Auflösung, keine handgezeichneten Flüsse).
- Lizenz GSHHG-Daten: **GNU LGPL-3.0-or-later**; beigefügte Lizenztexte: `licenses/GSHHG_LGPL3_COPYING.txt` und `licenses/GSHHG_LGPL3_COPYING_LESSER.txt`.
- Ursprung: https://www.soest.hawaii.edu/wessel/gshhg/ und https://www.ngdc.noaa.gov/mgg/shorelines/shorelines.html.

## Verarbeitung

1. 499 geographisch codierte Fluss-Liniensegmente im Frankreich-/Grenzbereich wurden aus WDBII eingelesen.
2. Abbildung von WGS84 nach Lambert-93 (EPSG:2154); anschließend stückweise affine Georeferenzierung der **vorhandenen, nicht georeferenzierten** Schulkarte anhand von zwölf eingezeichneten Städten.
3. Die Linien wurden mithilfe der regionalen Füllfarben auf das französische Mutterland begrenzt.
4. Das Ergebnis enthält 241 geographisch abgeleitete Teillinien mit rund 5.100 Linienpunkten.
5. **Keine Kubik-/Bézier-/Splinekurven:** Das SVG enthält ausschließlich echte geographische Linienzüge (`M` und `L`).
6. Schrift- und Farbdarstellung der bestehenden Frankreich-Basiskarte bleiben unverändert.
7. `Lernen -> Geographie -> Frankreich -> Flüsse` nutzt dieselbe Basiskarte und das separat eingebettete SVG mit **2 Pixel blauer Strichbreite** `#0066ff`.
8. `france_rivers_overlay.svg` liegt auch offen im Projekt, um die Ausgabe prüfen und ggf. anhand hochwertigerer GIS-Daten aktualisieren zu können.
9. Eine beschädigte SVG-Datei bzw. fehlendes PyQt5.QtSvg werden nicht mehr stillschweigend übergangen, sondern erzeugen eine konkrete Fehlermeldung.

## Präzisionsgrenze

Die WDBII-Daten beschreiben reale geografische Flusslagen, aber die hinterlegte, **illustrativ gezeichnete** Karte ist nicht georeferenziert. Ihre Umrechnung über zwölf Stadtmarkierungen ist eine Näherung, keine meter- oder pixelgenaue GIS-Koordinatentransformation. Für garantiert deckungsgleiche Fluss- und Länderlinien wäre eine tatsächlich georeferenzierte Basiskarte aus demselben Geodatensatz notwendig.

## Test

- `python -m unittest -q test_stage349_france_rivers_geodata.py test_stage344_geography_menu.py test_stage345_geography_france.py`
- `python -m py_compile d64_dism.py france.py`
- Windows/PyQt5-Runtime und QtSvg-Ausgabe sind in der lokalen Linux-Umgebung nicht abschließend bestätigt.
