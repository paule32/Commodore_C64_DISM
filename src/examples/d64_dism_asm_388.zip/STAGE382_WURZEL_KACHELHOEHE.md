# Stage 382 – Wurzel-Gesetz-Kacheln +26 Pixel

Basis: `d64_dism_asm_381(1).zip`

## Änderung
- Kachelhöhe in `Wurzel-Gesetze`: 116 px → 142 px.
- Die gelbe Lösungszeile wurde von `y+88` auf `y+114` verschoben.
- Der Abstand zwischen aufeinanderfolgenden Kacheln bleibt 14 px:
  Schrittweite 130 px → 156 px.
- Regel, Beispiel und Lösung überzeichnen sich damit nicht mehr.

## Unverändert
- Inhalte und Reihenfolge der vorhandenen Wurzel-Gesetze.
- Navigation und übrige Mathematik-Ansichten.
