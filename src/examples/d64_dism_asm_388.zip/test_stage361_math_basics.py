"""Stage 361: Geometrische Grundwissen-Seiten, Nachtpalette und Formeln.
Benötigt kein PyQt5; tatsächliche GUI-Zeichnung unter Windows separat testen.
"""
from pathlib import Path
import math
import textwrap
import unittest

SRC = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')

class Color:
    def __init__(self, value, *extra):
        if isinstance(value, Color):
            self.r, self.g, self.b, self.a = value.r, value.g, value.b, value.a
        elif isinstance(value, str):
            self.r = int(value[1:3], 16); self.g = int(value[3:5], 16)
            self.b = int(value[5:7], 16); self.a = 255
        else:
            self.r, self.g, self.b, self.a = (value, *extra, 255)[:4]
    def darker(self, percent):
        out=Color(self)
        for c in ('r','g','b'):
            setattr(out,c,round(getattr(out,c)*100/percent))
        return out
    def lighter(self, percent):
        out=Color(self)
        for c in ('r','g','b'):
            setattr(out,c,min(255,round(getattr(out,c)*percent/100)))
        return out
    def setAlpha(self, a): self.a=a
    def __repr__(self): return f'rgba({self.r},{self.g},{self.b},{self.a})'

class Point:
    def __init__(self,x,y): self.xx=float(x);self.yy=float(y)
    def x(self): return self.xx
    def y(self): return self.yy
    def __add__(self,o): return Point(self.xx+o.xx,self.yy+o.yy)
class Rect:
    def __init__(self,x,y,w,h):self.xx=x;self.yy=y;self.ww=w;self.hh=h
    def left(self):return self.xx
    def right(self):return self.xx+self.ww
    def top(self):return self.yy
    def bottom(self):return self.yy+self.hh
    def width(self):return self.ww
    def height(self):return self.hh
    def center(self):return Point(self.xx+self.ww/2,self.yy+self.hh/2)
class Pen:
    def __init__(self,c,*args):self.c=c
class Font:
    Bold=1
    def __init__(self,*args):pass
class Gradient:
    def __init__(self,*args):self.colors=[]
    def setColorAt(self,where,color): self.colors.append((where,color))
class Path:
    def __init__(self,*args):self.cmd=[]
    def moveTo(self,*args):self.cmd.append(('move',args))
    def arcTo(self,*args):self.cmd.append(('arc',args))
    def lineTo(self,*args):self.cmd.append(('line',args))
    def cubicTo(self,*args):self.cmd.append(('cubic',args))
class Widget:
    def __init__(self,*args):self._w=1050;self._h=620
    def setMinimumSize(self,*a):pass
    def setSizePolicy(self,*a):pass
    def update(self):pass
    def width(self):return self._w
    def height(self):return self._h
    def rect(self):return Rect(0,0,self._w,self._h)
class SizePolicy:
    Expanding=1
class Qt:
    AlignLeft=1; AlignVCenter=2; AlignCenter=4; NoBrush=8; NoPen=16
    DashLine=32; SolidLine=64; TextWordWrap=128
class Painter:
    Antialiasing=1; TextAntialiasing=2
    def __init__(self,widget=None):self.calls=[];self.brush=None;self.pen=None
    def setRenderHint(self,*a):pass
    def save(self):self.calls.append(('save',))
    def restore(self):self.calls.append(('restore',))
    def setPen(self,p):self.pen=p
    def setBrush(self,b):self.brush=b
    def setFont(self,f):pass
    def translate(self,*a):pass
    def scale(self,*a):pass
    def drawRoundedRect(self,*a):self.calls.append(('rounded',self.brush))
    def fillRect(self,*a):self.calls.append(('fill',a[-1]))
    def drawRect(self,*a):self.calls.append(('rect',self.brush))
    def drawEllipse(self,*a):self.calls.append(('ellipse',self.brush))
    def drawPolygon(self,*a):self.calls.append(('poly',self.brush))
    def drawPath(self,*a):self.calls.append(('path',self.brush))
    def drawLine(self,*a):self.calls.append(('line',self.pen))
    def drawText(self,*a):self.calls.append(('text',a[-1]))
    def end(self):pass

start=SRC.index('    class VolumeFactWidget(QWidget):')
end=SRC.index('    class PrimeSearchThread(QThread):',start)
ctx={'QWidget':Widget,'QSizePolicy':SizePolicy,'QColor':Color,'QFont':Font,
     'QRectF':Rect,'QPointF':Point,'QPen':Pen,'QPolygonF':list,
     'QPainterPath':Path,'QPainter':Painter,'QLinearGradient':Gradient,
     'QRadialGradient':Gradient,'Qt':Qt,'math':math}
exec(compile(textwrap.dedent(SRC[start:end]),'isolated_stage361_math.py','exec'),ctx)
Volume=ctx['VolumeFactWidget']
Area=ctx['AreaFactWidget']

class Stage361MathTests(unittest.TestCase):
    def test_all_eight_area_shapes_draw_and_formulas(self):
        expected=['Rechteck','Quadrat','Dreieck','Kreis','Halbkreis','Ellipse','Rhombus','Trapez']
        self.assertEqual([a['title'] for a in Area.FACTS.values()],expected)
        for key,spec in Area.FACTS.items():
            with self.subTest(figure=key):
                area=Area();area.set_dark_mode(True);area.activate_fact(key)
                area.paintEvent(None)  # vollständige QPainter-Zeichenroutine (Mock)
                area.set_dark_mode(False)
                area.paintEvent(None)  # Gegenprüfung mit heller Palette
                area.set_dark_mode(True)
                painter=Painter()
                area._draw_shape(painter,Rect(320,12,680,590),area._palette(),spec)
                self.assertTrue(any(c[0] in ('ellipse','rect','poly','path') for c in painter.calls))
                p=Painter()
                area._draw_panel(p,Rect(18,18,300,565),area._palette(),spec)
                formula_lines=[x[1] for x in p.calls if x[0]=='text']
                self.assertIn(spec['formula'],formula_lines)
                for formula in spec['calculations']:
                    self.assertIn(formula,formula_lines)
    def test_light_and_dark_material_colors(self):
        for key in Volume.FACTS:
            volume=Volume()
            volume.set_dark_mode(False)
            light=volume._shape_fill(Volume.FACTS[key])
            volume.set_dark_mode(True)
            dark=volume._shape_fill(Volume.FACTS[key])
            self.assertLess(sum((dark.r,dark.g,dark.b)),sum((light.r,light.g,light.b)))
            self.assertLess(dark.a,255)
            self.assertEqual(light.a,255)
    def test_cube_back_and_front_visible_in_dark(self):
        v=Volume();v.set_dark_mode(True)
        p=Painter();v._draw_shape(p,Rect(320,12,680,590),v._palette(),Volume.FACTS['volume_cube'])
        faces=[c[1] for c in p.calls if c[0]=='poly'][:4]
        self.assertGreaterEqual(len(faces),4)
        self.assertTrue(all(isinstance(face,Color) and face.a<255 for face in faces))
        self.assertLess(faces[0].r,faces[-1].r)
        self.assertTrue(any(c[0]=='line' for c in p.calls))
    def test_cylinder_gradient_side_and_rear(self):
        v=Volume();v.set_dark_mode(True)
        p=Painter();v._draw_shape(p,Rect(320,12,680,590),v._palette(),Volume.FACTS['volume_cylinder'])
        self.assertTrue(any(c[0]=='rect' and isinstance(c[1],Gradient) for c in p.calls))
    def test_new_tree_parent_relationship_and_order(self):
        section=SRC[SRC.index('        def _populate_facts_tree(self) -> None:'):SRC.index('        def _populate_games_tree(self) -> None:')]
        self.assertIn("QTreeWidgetItem(['Grundwissen'])",section)
        self.assertIn("QTreeWidgetItem(['Flächen'])",section)
        self.assertLess(section.index("QTreeWidgetItem(['Flächen'])"),section.index("QTreeWidgetItem(['Volumen'])"))
        self.assertIn('geometry.addChild(flaechen)',section)
        self.assertIn('geometry.addChild(volume)',section)
        self.assertIn('for key, spec in AreaFactWidget.FACTS.items():',section)
        self.assertIn("self._fact_items['area_rectangle']",section)
    def test_dark_mode_propagated_and_dispatch(self):
        section=SRC[SRC.index('    class MathematicsLearningDockWidget(QWidget):'):]
        self.assertIn('self.area_fact_widget = AreaFactWidget()',section)
        self.assertIn('self.area_fact_widget.set_dark_mode(enabled)',section)
        self.assertIn("elif fact_key.startswith('area_'):",section)
        self.assertIn('self.content_stack.setCurrentWidget(self.area_fact_scroll)',section)
        self.assertIn('self.volume_fact_widget.activate_fact(fact_key, title)',section)
    def test_area_formulas_math_check(self):
        rectangle=3*4
        square=5**2
        triangle=8*6/2
        circle=math.pi*3**2
        semicircle=circle/2
        ellipse=math.pi*4*2
        rhombus=12*8/2
        trapezoid=(7+3)*5/2
        self.assertEqual([rectangle,square,triangle,round(circle,2),round(semicircle,2),round(ellipse,2),rhombus,trapezoid],
                         [12,25,24,28.27,14.14,25.13,48,25])

if __name__=='__main__':unittest.main()
