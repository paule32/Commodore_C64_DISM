"""Stage 378: Matrix-Additionsbeispiele zeigen vollständigen Lösungsweg."""
from pathlib import Path
import ast
import unittest

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')


def _method_node(class_name: str, method_name: str):
    tree = ast.parse(SOURCE)
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == method_name:
                    return item
    raise AssertionError(f'{class_name}.{method_name} nicht gefunden')


class Stage378MatrixAdditionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        methods = [
            _method_node('BasicMathRulesFactWidget', '_parse_displayed_matrix'),
            _method_node('BasicMathRulesFactWidget', '_compute_matrix_value_sum'),
            _method_node('BasicMathRulesFactWidget', '_build_matrix_addition_solution'),
            _method_node('BasicMathRulesFactWidget', '_matrix_calculation_examples'),
        ]
        module = ast.Module(body=methods, type_ignores=[])
        ast.fix_missing_locations(module)
        ns = {}
        exec(compile(module, '<stage378_methods>', 'exec'), ns)

        class FakeWidget:
            pass

        FakeWidget._parse_displayed_matrix = ns['_parse_displayed_matrix']
        FakeWidget._compute_matrix_value_sum = ns['_compute_matrix_value_sum']
        FakeWidget._build_matrix_addition_solution = ns['_build_matrix_addition_solution']
        FakeWidget._matrix_calculation_examples = ns['_matrix_calculation_examples']
        cls.widget = FakeWidget()

    def test_generic_addition_solution_is_explicit(self):
        text = self.widget._build_matrix_addition_solution('[ 1, 2 ]\n[ 3, 4 ]')
        self.assertIn('A = [ 1, 2 ]\n[ 3, 4 ]', text)
        self.assertIn('B = [ 1, 2 ]\n[ 3, 4 ]', text)
        self.assertIn('A + B = [ 1 + 1, 2 + 2 ]\n[ 3 + 3, 4 + 4 ]', text)
        self.assertIn('= [ 2, 4 ]\n[ 6, 8 ]', text)
        self.assertIn('§§SOLUTION§§', text)

    def test_square_matrix_uses_detailed_addition(self):
        examples = self.widget._matrix_calculation_examples('matrix_square', '[ 1, 2 ]\n[ 3, 4 ]')
        title, text = examples[0]
        self.assertEqual(title, 'Addition')
        self.assertIn('[ 1 + 1, 2 + 2 ]', text)
        self.assertIn('[ 3 + 3, 4 + 4 ]', text)
        self.assertIn('[ 2, 4 ]', text)
        self.assertIn('[ 6, 8 ]', text)

    def test_solution_marker_is_supported_by_draw_routine(self):
        self.assertIn("marker = '\\n§§SOLUTION§§\\n'", SOURCE)
        self.assertIn("str(text).split(marker, 1)", SOURCE)


if __name__ == '__main__':
    unittest.main()
