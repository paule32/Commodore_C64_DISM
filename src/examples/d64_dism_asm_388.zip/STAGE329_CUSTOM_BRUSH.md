# Stage 329 – dBase Form Designer: Custom Brush

Basis: `d64_dism_asm_328.zip`.

## Eigenschaften
- Brush -> Style: letzter Eintrag `Custom`.
- Unter Style: `Cust. Width`, `Cust. Height` (1 bis 128 Pixel, Vorgabe 16x16).
- Auswählen von Custom öffnet den Pixelmuster-Editor.
- Raster: pro Bildpixel eine bemalbare Zelle; 2px Trennlinien, 12px Farbfläche.
- 32 Farben als 2 Spalten zu 16 Einträgen; Doppelklick auf Palette öffnet QColorDialog.
- Linke Aktionsleiste: Speichern, Speichern unter..., Laden.
- Musterkachel wird im Designer als echtes QPixmap/QBrush wiederholt.

## Dateiformat
JSON-Objekt mit `format`, `width`, `height`, `palette` (32 Hexfarben) und `pixels` (2D-Palettenindizes).
Speichern/OK persistiert die JSON-Datei; Abbrechen ändert die Auswahl nicht.

## Persistenz
Der Designer-Snapshot führt `brush_custom_width`, `brush_custom_height`, `brush_custom_file`, `brush_custom_data`.
In WFM-Texten werden `Style.CustomWidth`, `Style.CustomHeight` und `Style.CustomFile` ausgegeben.
Die referenzierte JSON-Datei muss beim erneuten Laden erreichbar sein. Datei-Pfade sind absolute Pfade, sofern im Speicherdialog so gewählt.

## Einschränkung
Die Qt5-Designeroberfläche und WFM-Dateiablage sind integriert. Die Darstellung benutzerdefinierter Muster in der kompilierten nativen WFM-EXE erfordert zusätzliche Erweiterungen der C++-WFM-Runtime und wurde in dieser Stage nicht implementiert oder unter Windows getestet.

## Prüfumfang
Python-Syntax geprüft; strukturelle Quellcode-Prüfungen. Echte PyQt5-GUI-Tests sind in dieser Linux-Umgebung mangels PyQt5 nicht möglich.
