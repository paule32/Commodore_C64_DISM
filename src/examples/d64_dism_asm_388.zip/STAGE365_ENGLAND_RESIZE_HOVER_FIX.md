# Stage 365 – EnglandMapView: AttributeError bei resizeEvent

## Fehler

`AttributeError: 'EnglandMapView' object has no attribute '_show_rivers'`
bei `EnglandMapView.resizeEvent()` (Stage 364, Zeile 8205).

## Ursache

Die Frankreich-spezifischen Overlay-Ereignishandler waren versehentlich
auch in der Klasse `EnglandMapView` eingefügt. England besitzt weder
`_show_rivers`, `_active_river_overlay` noch `_river_info_label`.

## Korrektur

Die England-Klasse enthält in `resizeEvent()` wieder ausschließlich
`super().resizeEvent(event)` und `self._apply_zoom()`. Die fehlplatzierten
`mouseMoveEvent`-/`leaveEvent`-Methoden wurden aus England entfernt.
Die originale Bilddarstellung, Zoomsteuerung, Dock-Anbindung und
`release_resources()` bleiben unverändert. Alle Frankreich-Fluss-Hover-
Ereignishandler bleiben vollständig erhalten.

## Tests

`python -m unittest test_stage365_england_resize -v`

Ein Windows-Laufzeittest mit PyQt5 ist zusätzlich erforderlich; diese
Umgebung enthält kein PyQt5.
