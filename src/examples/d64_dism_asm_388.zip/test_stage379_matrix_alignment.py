import ast
from pathlib import Path
import unittest

SRC = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')

class Stage379Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root=ast.parse(SRC)
        fn=next(n for n in ast.walk(root) if isinstance(n,ast.FunctionDef) and n.name=='_align_matrix_rows')
        ns={}
        ast.fix_missing_locations(fn)
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'<align>','exec'),ns)
        cls.align=staticmethod(ns['_align_matrix_rows']).__get__(None,object)

    def test_a_and_b(self):
        raw='A = [ 2, 0 ]\n[ 0, 3 ]\nB = [ 1, 2 ]\n[ 2, 1 ]'
        self.assertEqual(self.align(raw),'A = [ 2, 0 ]\n    [ 0, 3 ]\nB = [ 1, 2 ]\n    [ 2, 1 ]')

    def test_yellow_solution_alignment(self):
        raw='A + B = [ 2 + 1, 0 + 2 ]\n[ 0 + 2, 3 + 1 ]\n= [ 3, 2 ]\n[ 2, 4 ]'
        self.assertEqual(self.align(raw),'A + B = [ 2 + 1, 0 + 2 ]\n        [ 0 + 2, 3 + 1 ]\n= [ 3, 2 ]\n  [ 2, 4 ]')

    def test_height_and_painter(self):
        self.assertIn('calc_h = 274.0',SRC)
        self.assertIn('self._align_matrix_rows(task)',SRC)
        self.assertIn('self._align_matrix_rows(answer)',SRC)

if __name__=='__main__': unittest.main()
