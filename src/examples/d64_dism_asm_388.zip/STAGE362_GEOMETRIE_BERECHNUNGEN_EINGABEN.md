# Stage 362 – Geometrie-Fakten: Eingabe, Berechnung und Fehlerdialog

**Verbindliche Grundlage:** `d64_dism_asm_361.zip`. Es wurden keine bisherigen Zeichnungen, Animationen oder Sprach-/Compilerpfade ersetzt.

## UI

`Lernen → Mathe → Mathematik` (Fakten) → `Grundwissen → Flächen / Volumen`:

- 8 zweidimensionale Flächenfiguren und 11 dreidimensionale Volumenkörper besitzen auf der rechten Seite **unter der bisherigen QPainter-Figur** ein Eingabepanel.
- Je Figur werden die notwendigen Parameter mit deutschen Placeholdern angezeigt (z. B. „Länge“, „Breite“, „Höhe“, „Radius“). Die zugehörigen Parameter-Symbole sind im Tooltip lesbar.
- Das `Berechnen`-Bedienelement steht unter den Eingaben; daneben befindet sich ein schreibgeschütztes QLineEdit mit Placeholder **„Lösung“**. Die Ausgabe lautet `A = <Zahl>` bzw. `V = <Zahl>` (bis zu 12 signifikante Ziffern).
- Eingabevalidator: nur ASCII-Ziffern und maximal ein Dezimalpunkt. Kein Komma, Minus, Plus, Exponent oder Text. Alle benötigten Maße müssen endlich und > 0 sein. Für den Kegelstumpf ist `R >= r` erforderlich.
- Bei ungültiger/unvollständiger Eingabe erscheint ein selbständiger modaler `QDialog` mit exakt „**Daten Fehlen bzw. sind nicht gültig**“, einem **3-Pixel-Rahmen**, Hintergrundverlauf **schwarz → grau** im Dark-Mode, einem Schließen-Icon **✕** und einer **OK**-Schaltfläche. Light-Mode verwendet weiß/hellgrau.
- Beim Wechsel des ausgewählten Fakten-Blattes werden die Eingaben der jeweiligen Figur während der laufenden Sitzung gespeichert. Die bisherige Lösung wird zurückgesetzt und erst mit `Berechnen` erneut ermittelt.
- Die bestehenden QPainter-Körper und Materialfarben bleiben unverändert. Beide Fakten-Panels werden über die bisherigen `QScrollArea`-Seiten eingebettet. So bleibt das Hauptfenster kompakt; bei zu wenig Platz kann die Inhaltsseite scrollen.

## Berechnungen

| Fläche | Eingabefelder | Primäre Berechnung |
|---|---|---|
| Rechteck | a (Länge), b (Breite) | A = ab |
| Quadrat | a (Seitenlänge) | A = a² |
| Dreieck | g (Grundseite), h (Höhe) | A = gh/2 |
| Kreis | r (Radius) | A = πr² |
| Halbkreis | r (Radius) | A = πr²/2 |
| Ellipse | a, b (Halbachsen) | A = πab |
| Rhombus | e, f (Diagonalen) | A = ef/2 |
| Trapez | a, c (parallele Seiten), h | A = (a+c)h/2 |

| Volumen | Eingabefelder | Primäre Berechnung |
|---|---|---|
| Würfel | a (Seitenlänge) | V = a³ |
| Quader („Rechteck“ im vorhandenen Menü) | l, b, h | V = lbh |
| Zylinder | r, h | V = πr²h |
| Kugel | r | V = 4πr³/3 |
| Kugelschnitt / Halbkugel | r | V = 2πr³/3 |
| Ellipsoid („Ellipse“ im Menü) | a, b, c | V = 4πabc/3 |
| Kegel | r, h | V = πr²h/3 |
| Kegelstumpf | R, r, h | V = πh(R²+Rr+r²)/3 |
| Quadratische Pyramide | a, h | V = a²h/3 |
| Rechteckige Pyramide | l, b, h | V = lbh/3 |
| Dreieckiges Prisma | b, h, l | V = bhl/2 |

Alle Maße sind **ohne Einheit**; bei Eingaben in cm ergibt sich folglich cm² oder cm³. Die bestehenden erläuternden Formeln und Berechnungsmöglichkeiten der Fakten-Panels bleiben sichtbar.

## Tests

```bash
python -m py_compile d64_dism.py
python -m unittest -q test_stage362_geometry_calculator test_stage361_math_basics test_stage360_two_unit_circles
```

Die Stage-362-Tests prüfen alle 19 Formeln numerisch, ungültige/invollständige Eingaben, Eingabevalidatoren, Zustandswechsel, die Berechnen-Aktion, Ergebnisdarstellung und Dialog-Eigenschaften. Zusätzlich wurden die vorhandenen Stage-359/352-Tests geprüft.

**Einschränkung:** PyQt5 steht in der hiesigen Testumgebung nicht zur Verfügung. GUI-/Dark-Mode-Layout und tatsächlicher QDialog-Rahmen müssen noch unter Windows getestet werden.
