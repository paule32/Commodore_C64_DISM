"""Stage 342: dBase SAY/SET SPEECH PE32 integration regression tests."""
from __future__ import annotations
import ctypes
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from d64dbase.compiler import (
    DBaseCompilerError, DBaseSayStatement, DBaseSetSpeechStatement,
    compile_dbase_to_assembly, parse_dbase_statements,
)
from regression_test_helpers import pe_namespace

HERE = Path(__file__).resolve().parent
SAMPLE = (HERE / 'examples/dbase_speech_stage342.prg').read_text(encoding='utf-8')


class SpeechCompilerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pe = pe_namespace()
        cls.pe["PE32_TEXT_COMPRESSION_MSZIP_DEFAULT"] = False

    def compile(self, source, **kwargs):
        return compile_dbase_to_assembly(source, filename='speech.prg', target='pe32', **kwargs)

    def test_exact_example_parser(self):
        a = parse_dbase_statements(SAMPLE, filename='speech.prg')
        self.assertEqual([s.option for s in a if isinstance(s,DBaseSetSpeechStatement)],
                         ['state','mode','mix','pitch','speed'])
        self.assertEqual(sum(isinstance(s,DBaseSayStatement) for s in a),1)

    def test_codegen_imports_utf8_and_lifetime(self):
        asm=self.compile(SAMPLE).assembly
        self.assertIn('import SpeechInitialize, "retro_speech.dll", "SpeechInitialize"',asm)
        self.assertIn('import SpeechSpeak, "retro_speech.dll", "SpeechSpeak"',asm)
        self.assertIn('    call SpeechShutdown',asm)
        self.assertIn('    call SpeechSetPitch',asm)
        self.assertIn('    call SpeechSetSpeed',asm)
        self.assertIn('    call SpeechSetMix',asm)
        self.assertIn('    call SpeechSetExpression',asm)
        self.assertIn('    call SpeechSetArticulation',asm)
        self.assertIn('    call SpeechSpeak',asm)
        self.assertIn('    push 22050',asm)
        self.assertIn('    push 55',asm)
        self.assertIn('__dbase_speech_ready:',asm)
        self.assertIn('section .bss',asm)

    def test_utf8_literal_keeps_german_diacritics(self):
        asm=self.compile('SET SPEECH ON\nSAY "Grüße und schöne Äpfel!"').assembly
        self.assertIn('    db 71, 114, 195, 188, 195, 159, 101',asm)

    def test_dynamically_modified_string_uses_cp1252_bridge(self):
        src='''SET SPEECH ON
STORE "Grüße" TO Satz
IF ISUPPER("A")
    STORE "Mädchen" TO Satz
ENDIF
SAY Satz'''
        asm=self.compile(src).assembly
        self.assertIn('    call SpeechSpeakCP1252',asm)
        self.assertIn('    push dword ptr [__dbase_speech_text_',asm)

    def test_conditional_and_routine_support(self):
        src='''PROCEDURE Begruessung()
SAY "Guten Morgen!"
RETURN
SET SPEECH ON
IF 1 = 1
    SET SPEECH MODE C64
    Begruessung()
ENDIF
SET SPEECH OFF'''
        asm=self.compile(src).assembly
        self.assertIn('    call SpeechSpeak',asm)
        self.assertIn('    call SpeechShutdown',asm)
        self.assertIn('    push 130',asm)
        self.assertIn('    push 105',asm)

    def test_speech_free_program_has_no_dependency(self):
        asm=self.compile('?? "Hallo"').assembly
        self.assertNotIn('retro_speech.dll',asm)
        self.assertNotIn('__dbase_speech_ready',asm)

    def test_speech_settings_validation(self):
        for src in ('SET SPEECH PITCH 0','SET SPEECH MIX 101',
                    'SET SPEECH SPEED 20','SET SPEECH MODE WRONG',
                    'SET SPEECH X 50','SET SPEECH ON NOW','SAY 5','SAY'):
            with self.subTest(src=src), self.assertRaises(DBaseCompilerError):
                self.compile(src)

    def test_pe64_rejected_for_pe32_only_speech_dll(self):
        with self.assertRaisesRegex(DBaseCompilerError, 'PE32'):
            compile_dbase_to_assembly(SAMPLE, target='pe64')

    def test_coff32_and_pe32_link_for_example_and_dynamic(self):
        for src in (SAMPLE, '''SET SPEECH ON
STORE "Ein" TO s
IF ISLOWER("a")
    STORE "Änderung" TO s
ENDIF
SAY s'''):
            with self.subTest(case=src[:25]):
                asm=self.compile(src).assembly
                obj=self.pe['assemble_pe32_object_source'](asm)
                coff=self.pe['write_coff32_object'](obj)
                self.assertTrue(coff.startswith(b'\x4c\x01'))
                pe=self.pe['link_coff32_objects']([coff],entry_symbol='_start',gui=True)
                self.assertGreater(len(pe.executable),2000)
                self.assertIn(b'retro_speech.dll',pe.executable)
                self.assertIn(b'SpeechSpeak',pe.executable)

    def test_c99_bridge_compiles_and_rejects_malformed_length(self):
        if not __import__('shutil').which('gcc'):
            self.skipTest('gcc nicht verfuegbar')
        with tempfile.TemporaryDirectory() as tmp:
            lib=Path(tmp)/'speech.so'
            subprocess.run(['gcc','-shared','-fPIC','-std=c99','-Wall','-Wextra','-Werror',
                            str(HERE/'speech/retro_speech.c'),'-lm','-o',str(lib)],check=True,capture_output=True)
            dll=ctypes.CDLL(str(lib))
            f=dll.SpeechSpeakCP1252
            f.argtypes=(ctypes.c_char_p,ctypes.c_uint32)
            f.restype=ctypes.c_int32
            self.assertEqual(f(None,1),0)
            self.assertEqual(f(b'abc',100000),0)
            dll.SpeechInitialize.argtypes=(ctypes.c_int32,)
            dll.SpeechInitialize.restype=ctypes.c_int32
            self.assertEqual(dll.SpeechInitialize(22050),1)
            # Under POSIX, output returns the 'unsupported waveOut' error;
            # conversion and synthesis still complete without memory error.
            self.assertEqual(f('Grüße'.encode('cp1252'),5),0)
            dll.SpeechGetLastError.restype=ctypes.c_int32
            self.assertEqual(dll.SpeechGetLastError(),5)


if __name__ == '__main__':
    unittest.main(verbosity=2)
