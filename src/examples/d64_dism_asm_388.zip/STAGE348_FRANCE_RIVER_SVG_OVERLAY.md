# Stage 348 - Frankreich-Fluesse als SVG-Overlay

## Ziel
Die Fluesse fuer `Lernen -> Geographie -> Frankreich -> Fluesse` werden nicht
mehr als direkt im Python-Code erzeugte Punktlisten ueber `QPainterPath`
gezeichnet. Stattdessen wird ein eingebettetes SVG-Overlay verwendet.

## Umsetzung
- `france.py`
  - erweitert um `FRANCE_RIVER_OVERLAY_SVG_B85`
  - die Frankreich-Karte bleibt separat als `FRANCE_MAP_IMAGE_B85` erhalten
- `d64_dism.py`
  - `FranceMapView` laedt bei `show_rivers=True` jetzt das SVG-Overlay
  - Anzeige erfolgt ueber `QGraphicsSvgItem` + `QSvgRenderer`
  - das Overlay wird auf die Groesse der eingebetteten Frankreich-Karte skaliert
- zusaetzlich liegt die bearbeitbare Quelldatei `france_rivers_overlay.svg` im Projekt

## Effekt
- nur eine Basis-Landkarte fuer Frankreich bleibt eingebettet
- Fluesse koennen spaeter ohne Aenderung an der Basiskarte verfeinert werden
- Vektoroverlay bleibt bei Zoom scharf
- 2-Pixel-blaue Fluesse bleiben als separates Overlay darstellbar
