"""Stage 345/346: Frankreich-Kartenasset, Menu und Overlay-Struktur (Qt-unabhaengig)."""
import ast
import base64
from hashlib import sha256
import importlib.util
from pathlib import Path
import struct
import unittest

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / 'd64_dism.py').read_text(encoding='utf-8')
EXPECTED_SHA = '65b5b8e5f47f6b5fdd6d4b761cfb3fb68d7dc8f2d30155e62ccf6d5b3ca1f625'


class Stage345FranceGeographyTests(unittest.TestCase):
    def test_france_clean_image_embedded(self):
        spec = importlib.util.spec_from_file_location('france_test', ROOT / 'france.py')
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        decoded = base64.b85decode(mod.FRANCE_MAP_IMAGE_B85)
        self.assertEqual(decoded[:8], b'\x89PNG\r\n\x1a\n')
        self.assertEqual(sha256(decoded).hexdigest(), EXPECTED_SHA)
        self.assertEqual(struct.unpack_from('>II', decoded, 16), (1254, 1254))
        self.assertEqual((mod.FRANCE_MAP_WIDTH, mod.FRANCE_MAP_HEIGHT), (1254, 1254))
        self.assertIn('def _free_france_module(', SOURCE)
        self.assertIn('loaded.FRANCE_MAP_IMAGE_B85 = b""', SOURCE)

    def test_menu_structure_and_overlay_actions(self):
        self.assertIn('self.france_geography_menu = geography_menu.addMenu("Frankreich")', SOURCE)
        self.assertIn('self.france_geography_menu.addAction(self.france_landkarte_geography_action)', SOURCE)
        self.assertIn('self.france_geography_menu.addAction(self.france_rivers_geography_action)', SOURCE)
        self.assertIn('QAction("Landkarte", self)', SOURCE)
        self.assertIn('QAction("Flüsse", self)', SOURCE)
        self.assertIn('self.show_france_geography_dock', SOURCE)
        self.assertIn('self.show_france_rivers_geography_dock', SOURCE)

    def test_river_overlay_and_docks_exist(self):
        for clause in [
            'FRANCE_RIVER_OVERLAY_SVG_B85',
            'QGraphicsSvgItem()',
            'def _ensure_france_rivers_geography_dock(self):',
            'def show_france_rivers_geography_dock(self, _checked=False):',
            'show_rivers=True',
            'object_name="france_rivers_geography_dock"',
        ]:
            self.assertIn(clause, SOURCE)
        self.assertIn('for name in ("france_rivers_geography_dock", "france_landkarte_geography_dock", "france_geography_dock", "england_geography_dock", "germany_geography_dock"):', SOURCE)

    def test_two_france_docks_and_restore(self):
        wanted = {
            '_visible_geography_dock', '_activate_geography_workspace',
            '_prepare_germany_geography_workspace', '_restore_germany_geography_workspace',
            '_germany_geography_visibility_changed', '_england_geography_visibility_changed',
            '_france_geography_visibility_changed', '_france_rivers_geography_visibility_changed'
        }
        nodes = {node.name: node for node in ast.walk(ast.parse(SOURCE))
                 if isinstance(node, ast.FunctionDef) and node.name in wanted}
        self.assertEqual(set(nodes), wanted)
        module = ast.Module(body=list(nodes.values()), type_ignores=[])
        ast.fix_missing_locations(module)

        class FakeDock:
            def __init__(self, name, visible=False):
                self.name, self.visible, self.blocked, self.on_visibility = name, visible, False, None
            def isVisible(self): return self.visible
            def set_dark_mode(self, value): pass
            def blockSignals(self, value):
                old = self.blocked
                self.blocked = bool(value)
                return old
            def show(self):
                self.visible = True
                if not self.blocked and self.on_visibility: self.on_visibility(True)
            def hide(self):
                self.visible = False
                if not self.blocked and self.on_visibility: self.on_visibility(False)

        class FakeWindow: pass
        class FakeQTimer:
            @staticmethod
            def singleShot(delay, callback): pass
        env = {'QDockWidget': FakeDock, 'QTimer': FakeQTimer}
        exec(compile(module, '<stage346_docks>', 'exec'), env)
        for method in wanted: setattr(FakeWindow, method, env[method])
        win = FakeWindow()
        side, center = FakeDock('project', True), FakeDock('editor', True)
        ger, eng, fra_land, fra_riv = FakeDock('Germany'), FakeDock('England'), FakeDock('FranceLand'), FakeDock('FranceRiv')
        win.germany_geography_dock = ger
        win.england_geography_dock = eng
        win.france_geography_dock = fra_land
        win.france_landkarte_geography_dock = fra_land
        win.france_rivers_geography_dock = fra_riv
        win.findChildren = lambda cls: [side, ger, eng, fra_land, fra_riv]
        win.centralWidget = lambda: center
        win.dark_mode_enabled = False
        win._disable_germany_zoom_controls = lambda: None
        win._bind_germany_zoom_controls = lambda dock: None
        win._expand_france_geography_dock = lambda: None
        win._expand_france_rivers_geography_dock = lambda: None
        win._expand_england_geography_dock = lambda: None
        win._expand_germany_geography_dock = lambda: None
        fra_land.on_visibility = win._france_geography_visibility_changed
        fra_riv.on_visibility = win._france_rivers_geography_visibility_changed
        eng.on_visibility = win._england_geography_visibility_changed
        ger.on_visibility = win._germany_geography_visibility_changed

        for chain in [(fra_land, fra_riv, ger), (eng, fra_land, fra_riv)]:
            self.assertTrue(side.visible)
            self.assertTrue(center.visible)
            for dock in chain:
                win._activate_geography_workspace(dock)
                dock.show()
                self.assertIs(win._visible_geography_dock(), dock)
                self.assertFalse(side.visible)
                self.assertFalse(center.visible)
            chain[-1].hide()
            self.assertTrue(side.visible)
            self.assertTrue(center.visible)
            self.assertFalse(getattr(win, '_germany_geography_workspace_active'))
            self.assertFalse(any(x.visible for x in (ger, eng, fra_land, fra_riv)))


if __name__ == '__main__':
    unittest.main()
