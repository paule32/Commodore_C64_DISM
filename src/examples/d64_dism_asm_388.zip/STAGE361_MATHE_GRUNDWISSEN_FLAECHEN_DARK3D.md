# Stage 361 – Mathematik-Fakten: Grundwissen, Flächen und Dark-Mode-3D

**Verbindliche Ausgangsbasis:** `d64_dism_asm_360.zip`.

## Fakten-Baum

```
Fakten
├─ Grundwissen
│  ├─ Flächen
│  │  ├─ Rechteck
│  │  ├─ Quadrat
│  │  ├─ Dreieck
│  │  ├─ Kreis
│  │  ├─ Halbkreis
│  │  ├─ Ellipse
│  │  ├─ Rhombus
│  │  └─ Trapez
│  └─ Volumen
│     ├─ Würfel
│     ├─ Rechteck
│     ├─ Zylinder
│     ├─ Kugel
│     ├─ Kugelschnitt
│     ├─ Ellipse
│     ├─ Kegel
│     ├─ Kegelstumpf
│     ├─ Quadratische Pyramide
│     ├─ Rechteckige Pyramide
│     └─ Dreieckiges Prisma
├─ Zahlen (unverändert)
├─ Cantor (unverändert)
├─ Pascal Dreieck (unverändert)
└─ Fibonacci Spirale (unverändert)
```

## Flächenfiguren

Der neue `AreaFactWidget` nutzt die bestehende Formel-/Legenden-Gestaltung des
`VolumeFactWidget`. Die acht Formen werden direkt mit `QPainter` gezeichnet,
inklusive Maße, Hilfslinien und Bemaßungspfeilen. Keine externen Grafiken.

| Form | Flächeninhalt | Weitere Relationen (Auswahl) |
|---|---|---|
| Rechteck | `A = a·b` | `U=2(a+b)`, `a=A/b`, `b=A/a`, Diagonale |
| Quadrat | `A = a²` | `U=4a`, `a=√A`, Diagonale |
| Dreieck | `A = g·h/2` | Umfang, Umstellungen, Heron |
| Kreis | `A = πr²` | `U=2πr`, `r=√(A/π)`, `d=2r` |
| Halbkreis | `A = πr²/2` | Umfang einschließlich Durchmesser, Radius |
| Ellipse | `A = πab` | Umfangsnäherung von Ramanujan, Halbachsen |
| Rhombus | `A = ef/2 = a·h` | Umfang, Höhe, Diagonalen |
| Trapez | `A = (a+c)h/2` | Umfang, Höhe, Mittellinie |

Die Auswahlschlüssel `area_*` sind bewusst von den vorhandenen `volume_*`
getrennt. Die Seiten werden über dieselbe scrollbare QStackedWidget-Arbeitsfläche
geöffnet, ohne Mindestgröße des Hauptfensters zu erzwingen.

## Darstellung im Dark-Mode

- Material-Grundfarben der 3D-Volumenkörper ungefähr halbiert (`QColor.darker(200)`).
- Vorderflächen mit Alpha 225/255, sodass dunklere verdeckte Rückflächen teilweise
  sichtbar bleiben (nicht einfach vollständig übermalt werden).
- Unterschiedliche Flächenhelligkeiten für Rück-/Seiten-/Deck-/Vorderflächen,
  zusätzliche echte obere Flächen bei Würfel und Quader.
- Zylinder: hinteren Boden vor dem Körper zeichnen, Körper als horizontalen
  Beleuchtungsverlauf, elliptische Deckfläche zuletzt.
- Verdeckte Hilfskanten im Dark-Mode mit gedämpfterer Farbe.
- Im Light-Mode bleiben die bisherigen hellen Pastellfarben und opaken Flächen.

## Prüfungen

- `python -m py_compile d64_dism.py`
- `python -m unittest -q test_stage361_math_basics test_stage360_two_unit_circles`
- Regressionen aus Stage 359/352 können zusätzlich ausgeführt werden.
- `test_stage361_math_basics.py` prüft alle acht Figuren im QPainter-Mock
  einschließlich Formeln sowie Baumstruktur, Dark-Mode, Zylinder und Würfel.
- **Nicht hier testbar:** Native PyQt5-Wiedergabe/Renderprüfung unter Windows,
  da keine PyQt5-Installation im Testcontainer vorhanden ist.
