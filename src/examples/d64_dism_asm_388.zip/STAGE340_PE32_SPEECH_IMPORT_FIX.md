# Stage 340 – MinGW32-DLL-Import fuer Retro Speech korrigiert

Verbindliche Basis: `d64_dism_asm_339.zip`.

## Gemeldeter Fehler

Die Stage-339-DLL wurde mit `-Wl,--kill-at` erstellt. Beim anschliessenden
Linken der Demo schlug der Import von 32-Bit-`__stdcall`-Funktionen fehl:
`undefined reference to _imp__SpeechInitialize@4`, `...SpeechSetMix@4`,
`...SpeechShutdown@0` usw. Die Headerdatei nutzt `__declspec(dllimport)`
und `__stdcall`, weshalb dekorierte Import-Symbole benoetigt werden.

## Korrektur

In `speech/build_pe32.py` wird `-Wl,--kill-at` durch
`-Wl,--add-stdcall-alias` ersetzt. Die DLL soll damit **beide** Namen
exportieren:

- `SpeechInitialize@4` fuer MinGW32 `__stdcall`-Importe und die Importbibliothek
- `SpeechInitialize` fuer den d64_dism-PE32-Linker mit Import per Name

Die Aufrufkonvention, alle Funktionssignaturen und die eigentliche C99-
Sprachengine bleiben unveraendert. Dokumentation in `speech/retro_speech.h`
und `speech/README.md` wurde entsprechend angepasst.

## Erneuter Build unter Windows 10 (MSYS2 MINGW32)

```
cd /t/GitHub/dBase2Many/src/asmjit/compiler/frontend/c64/speech
python build_pe32.py
objdump -p bin/retro_speech.dll | grep SpeechInitialize
nm -g bin/libretro_speech.dll.a | grep SpeechInitialize
objdump -p bin/retro_speech_demo.exe | grep retro_speech.dll
./bin/retro_speech_demo.exe --no-play --wav test_hallo.wav
```

Falls das `nm`-Ergebnis keine dekorierten `_imp__...@4`-Symbole enthaelt,
bitte die Ausgaben von `objdump -p` und `nm -g` uebermitteln. Die DLL muss
mit der **gleichzeitig neu erzeugten** Importbibliothek gelinkt werden.

## Tests

- 9 existierende Stage-339-Tests des Synthesizers unter Linux bestanden.
- 3 neue Buildskript-Regressionstests mit simulierter MINGW32-Toolchain
  pruefen Flag-Kombination, PE32-Target-Schutz und `dllimport`/`stdcall`.
- Python-Syntaxpruefung und ZIP-Integritaet.

Ein realer MINGW32-Build und ein Test auf Windows 10 sind in dieser
Umgebung nicht moeglich; keine Aussage ueber den tatsaechlichen Laufzeitstart.
