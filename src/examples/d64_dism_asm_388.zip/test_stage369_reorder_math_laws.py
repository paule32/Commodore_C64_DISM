"""Stage 369: Rechengesetze werden UMSORTIERT; keine neuen Mathematikinhalte.

Die Testdoubles stammen aus der vorhandenen Stage-367-Regression.
"""
import ast
from pathlib import Path
import unittest

import test_stage367_math_rules_widget_init as regression

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
START = SOURCE.index('    class BasicMathRulesFactWidget(QWidget):')
END = SOURCE.index('\n    class MathematicsLearningDockWidget(QWidget):', START)
CODE = ''.join(l[4:] if l.startswith('    ') else l
               for l in SOURCE[START:END].splitlines(keepends=True))


class TestStage369(unittest.TestCase):
    def setUp(self):
        self.widget = regression.MathWidget()
        self.rules = self.widget.facts_tree.children[0]._child_items[0]

    def test_only_reordering_no_extra_rules_leaf(self):
        labels = [item.label for item in self.rules._child_items]
        self.assertEqual(labels, ['Grundrechen-Arten', 'Punkt-vor-Strich-Rechnung', 'Vorzeichen-Regeln', 'Teilbarkeit', 'Potenzen', 'Wurzel-Gesetze', 'Kommutativ-Gesetz', 'Assoziativ-Gesetz Addition', 'Assoziativ-Geset Multiplikation', 'Distributiv-Gesetz'])
        self.assertNotIn('calculation_rules', self.widget._fact_items)
        self.assertEqual([item.label for item in self.rules._child_items[0]._child_items],
                         [])
        self.assertEqual([item.label for item in self.rules._child_items[6:]], [
            'Kommutativ-Gesetz', 'Assoziativ-Gesetz Addition',
            'Assoziativ-Geset Multiplikation', 'Distributiv-Gesetz'])
        self.assertEqual([item.label for item in self.rules._child_items[3]._child_items],
                         ['Brüche'])

    def test_relocated_blades_show_previous_content(self):
        expected = (
            ('law_commutative', 'Kommutativgesetz: a + b = b + a   |   a · b = b · a'),
            ('law_associative_add', 'Assoziativgesetz: (a + b) + c = a + (b + c)'),
            ('law_associative_multiply', 'Assoziativgesetz: (a · b) · c = a · (b · c)'),
            ('law_distributive', 'Distributivgesetz: a · (b + c) = a · b + a · c'),
            ('order_of_operations', 'Punktrechnung vor Strichrechnung'),
        )
        class FakeWidget:
            def __init__(self): self._mode = None; self.calls = []
            def _paint_placeholder(self, _painter, _colors, title, lines):
                self.calls.append((title, tuple(lines)))
        code_ast = ast.parse(CODE)
        cls = next(n for n in code_ast.body if isinstance(n, ast.ClassDef)
                   and n.name == 'BasicMathRulesFactWidget')
        rules_const = next(n for n in cls.body if isinstance(n, ast.Assign)
                           and any(isinstance(t, ast.Name) and t.id=='RELOCATED_LAWS'
                                   for t in n.targets))
        laws = ast.literal_eval(rules_const.value)
        for key, line in expected:
            with self.subTest(key=key):
                self.assertEqual(laws[key][1], (line,))
                self.widget.open_fact(key)
                self.assertIs(self.widget.content_stack._current,
                              self.widget.basic_math_rules_scroll)
                self.assertIn(('activate_fact', (key,''), {}),
                              self.widget.basic_math_rules_widget.calls)

    def test_existing_topics_still_work(self):
        for key, page in (
            ('basic_arithmetic', 'basic_math_rules_scroll'),
            ('powers_rules', 'basic_math_rules_scroll'),
            ('divisibility_rules', 'basic_math_rules_scroll'),
            ('fraction_add', 'fraction_help_scroll'),
            ('interest_calculation', 'interest_calculation_scroll'),
            ('volume_cube', 'volume_fact_scroll'),
        ):
            with self.subTest(key=key):
                self.widget.open_fact(key)
                self.assertIs(self.widget.content_stack._current, getattr(self.widget, page))

    def test_same_formulas_no_duplication(self):
        code_ast = ast.parse(CODE)
        cls = next(n for n in code_ast.body if isinstance(n, ast.ClassDef) and n.name=='BasicMathRulesFactWidget')
        value = next(n.value for n in cls.body if isinstance(n, ast.Assign)
                     and any(isinstance(t,ast.Name) and t.id=='RELOCATED_LAWS' for t in n.targets))
        laws = ast.literal_eval(value)
        self.assertEqual(len(laws), 5)
        self.assertEqual(len({t for _, val in laws.values() for t in val}), 5)

if __name__ == '__main__': unittest.main()
