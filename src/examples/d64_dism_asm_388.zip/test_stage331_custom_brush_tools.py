"""Tests der Stage-331-Pixeloperationen ohne installierte PyQt5-Laufzeit."""
import ast
import unittest
from pathlib import Path
from types import SimpleNamespace

SOURCE = Path(__file__).with_name('d64_custom_brush.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)
DIALOG = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == 'D64CustomBrushDialog')

def method(name):
    node = next(n for n in DIALOG.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return compile(ast.Module(body=[node], type_ignores=[]), '<d64_custom_brush>', 'exec')

def call(name, owner, *args):
    scope = {}
    exec(method(name), scope)
    return scope[name](owner, *args)

class Owner:
    def __init__(self, pixels):
        self.data = dict(width=len(pixels[0]), height=len(pixels), pixels=pixels)
        self.refreshes = 0
    def _changed(self): self.refreshes += 1

class FakeSpin:
    def __init__(self, n): self.n = n
    def value(self): return self.n

class FakeGrid:
    def __init__(self): self.resizes = 0
    def resize_grid(self): self.resizes += 1

class BrushToolsTests(unittest.TestCase):
    def test_layout_structure_and_controls(self):
        for name in ('d64CustomBrushCopy', 'd64CustomBrushPaste', 'd64CustomBrushClear',
                     'd64CustomBrushMoveUp', 'd64CustomBrushMoveDown',
                     'd64CustomBrushMoveLeft', 'd64CustomBrushMoveRight',
                     'd64CustomBrushFlipHorizontal', 'd64CustomBrushFlipVertical',
                     'd64CustomBrushWidth', 'd64CustomBrushHeight'):
            self.assertIn(name, SOURCE)
        self.assertIn('editor_col.addLayout(colors)', SOURCE)
        self.assertIn('right.addWidget(self.repeat_preview', SOURCE)
        self.assertIn('colors.addWidget(button, index // 16, index % 16)', SOURCE)

    def test_shift_wraps_without_loss(self):
        original = [[0, 1, 2], [3, 4, 5]]
        o = Owner([r[:] for r in original])
        call('shift_pattern', o, 1, 0)
        self.assertEqual(o.data['pixels'], [[2, 0, 1], [5, 3, 4]])
        call('shift_pattern', o, -1, 0)
        self.assertEqual(o.data['pixels'], original)
        call('shift_pattern', o, 0, -1)
        self.assertEqual(o.data['pixels'], [[3, 4, 5], [0, 1, 2]])
        call('shift_pattern', o, 0, 1)
        self.assertEqual(o.data['pixels'], original)
        self.assertEqual(o.refreshes, 4)

    def test_flip(self):
        o = Owner([[0, 1, 2], [3, 4, 5]])
        call('flip_pattern', o, 'horizontal')
        self.assertEqual(o.data['pixels'], [[2, 1, 0], [5, 4, 3]])
        call('flip_pattern', o, 'vertical')
        self.assertEqual(o.data['pixels'], [[5, 4, 3], [2, 1, 0]])

    def test_resize_preserves_content(self):
        o = Owner([[2, 3], [4, 5]])
        o.width_spin, o.height_spin = FakeSpin(3), FakeSpin(3)
        o.grid = FakeGrid()
        call('_resize_from_spinboxes', o)
        self.assertEqual(o.data['pixels'], [[2, 3, 1], [4, 5, 1], [1, 1, 1]])
        o.width_spin, o.height_spin = FakeSpin(1), FakeSpin(2)
        call('_resize_from_spinboxes', o)
        self.assertEqual(o.data['pixels'], [[2], [4]])
        self.assertEqual(o.grid.resizes, 2)

    def test_clear_does_not_change_file_reference(self):
        o = Owner([[4, 5], [2, 3]])
        o.file_path = 'existing.json'
        call('clear_pattern', o)
        self.assertEqual(o.data['pixels'], [[1, 1], [1, 1]])
        self.assertEqual(o.file_path, 'existing.json')

if __name__ == '__main__':
    unittest.main()
