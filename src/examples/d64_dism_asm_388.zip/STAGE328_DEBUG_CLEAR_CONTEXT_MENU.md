# Stage 328 – Debug-Kontextmenü „Bereinigen“ / Refresh-Unterbrechung

Verbindliche Basis: `d64_dism_asm_327.zip`. Alle dort enthaltenen Dateien
bleiben erhalten; die Änderungen betreffen nur die Debug-Editor-Integration.

## Debug-Kontextmenü (normaler Start und Workstation)

Das gemeinsame Qt5-Widget `D64DebugOutputTextEdit` in
`d64qt5/d64_debug_context_menu.hpp` erzeugt jetzt in dieser Reihenfolge:

1. `Bereinigen` (QAction, `objectName=d64DebugContextClear`,
   `d64LocalizationKey=debug.context.clear`)
2. Separator (`objectName=d64DebugContextClearSeparator`)
3. `Kopieren` – echtes Qt-Shortcut `Ctrl+C` rechts in der Menüspalte
4. `Alles makieren` – echtes Qt-Shortcut `Ctrl+A` rechts in der Menüspalte

Die bestehenden `objectName`-/Lokalisierungsmarker bleiben bestehen.
Die Trennlinie erhält eine zum Dark-/Light-Mode passende Farbe.

`Bereinigen` löscht `QPlainTextEdit::clear()` den gesamten Dokumenttext,
setzt den `QTextCursor` an `QTextCursor::Start` und setzt die horizontale
und vertikale Scrollposition auf das Minimum. Dank `ScrollBarAsNeeded`
verschwinden die Balken am leeren Dokument automatisch und werden bei
späterer Ausgabe wieder normal aktiviert. Die navyblauen Scrollbars mit
gelben Pfeilen bleiben unverändert.

## Stabiler Workstation-Context-Popup (Runner)

Ursache: Der Runner hob den Debug-Dialog über zwei voneinander unabhängige
500-ms-Pfade regelmäßig in den Vordergrund. Das kann ein per `QMenu::exec()`
geöffnetes Popup verdecken/beenden, bevor eine Aktion gewählt wird.

* `setContextMenuStateHandler()` meldet Öffnen und Schließen des Menüs.
* Während `menu.exec()` pausiert der Qt5-500-ms-Debug-Watchdog und der
  gebündelte 16-ms-Ausgabe-Refresh. Der Win32-500-ms-Timer bleibt für
  allgemeine Housekeeping-Aufgaben aktiv; seine Debug-Raise-/Console-
  Vordergrundfunktion ist während des Kontextmenüs gesperrt.
* Die zuvor nicht abbrechbare 16-ms-`QTimer::singleShot` wurde durch
  einen abbrechbaren, wiederverwendbaren Single-Shot-`QTimer` ersetzt.
* Eingehende Textnachrichten werden während des Popup-Lebenszyklus
  weiterhin angenommen und FIFO gepuffert, jedoch nicht gerendert.
* `Bereinigen` verwirft zusätzlich diesen noch nicht angezeigten Puffer.
* Nach dem Schließen des Menüs und nach der QAction-Ausführung werden
  Theme und Timer reaktiviert, der Textpuffer gegebenenfalls gezeichnet
  und ein durch `SET DEBUG OFF` ausstehendes Ausblenden angewendet.
* Eine eventuell laufende Erkennungs-/Aktivierungsschleife eines
  gestarteten Formulars hebt im Popup-Zustand ebenfalls kein Fremdfenster an.

## Standalone-/lokales Qt5-Debug-Fenster

Der lokale `DBaseDebugOutputDialog` verwendet dasselbe Menü. Für während
des Menüs eintreffende lokale Textausgaben gibt es ebenfalls einen
Zwischenpuffer. Bei „Bereinigen“ wird dieser geleert. Nach dem Popup
werden spätere Ausgaben wieder normal angefügt.

## Geänderte Dateien

- `d64qt5/d64_debug_context_menu.hpp`
- `d64qt5/workstation_runner.cpp`
- `d64qt5/d64qt5_bridge.cpp`
- Quellcode-Regressionsprüfungen Stage 319 / Stage 320 aktualisiert
- Neu: `test_debug_clear_menu_stage328.py`

## Windows-Integrationstest (noch erforderlich)

1. `libd64_qt5.dll` und `d64_workstation_runner.exe` aus Stage 328 neu bauen.
2. `SET DEBUG ON`, lange Textausgaben in `Form1.wfm` / `.prg` erzeugen.
3. Im aktiven Workstation Mode das Kontextmenü aufklappen und länger als
   1–2 Sekunden offen halten. Es darf nicht automatisch schließen.
4. `Kopieren` und `Alles makieren` wie zuvor testen.
5. `Bereinigen` auswählen: leerer Editor, Cursor an Position 0,
   kein sichtbarer Scrollbalken solange der Inhalt hineinpasst.
6. Neue Debug-Ausgabe erzeugen: Ausgabe erscheint wieder, die Scrollbalken
   werden nur bei Bedarf angezeigt.
7. `SET DEBUG OFF` und `SET DEBUG ON` ausführen; normale Fenstersteuerung
   und Theme-Auswahl müssen erhalten bleiben.
8. Dieselben Prüfungen im Nicht-Workstation-Modus wiederholen.

Hinweis: Quellcode-Tests beweisen nicht das tatsächliche Kontextmenü-Fokus-
verhalten auf Windows. Die hier vorhandene Umgebung stellt weder Qt5-Windows-
Headers noch einen MinGW-/Windows-Desktop zur Laufzeitprüfung bereit.
