"""Stage 337: focused structural regressions; actual Qt GUI testing on Windows remains necessary."""
from pathlib import Path
p = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
assert 'if self.open_document(path, language_override="dbase"):' in p
assert 'and not self.language_override\n                and self.path.suffix.lower() in self.BINARY_EXTENSIONS' in p
focus = p.split('def focus_preferred_editor(self)', 1)[1].split('def _view_modification_changed', 1)[0]
assert 'and not self.language_override' in focus
assert 'self.raw_editor.setFocus()' in focus
assert 'self._set_tab_visible_for_widget(self.hex_editor, not self.is_dbase_document)' in p
assert 'self._set_tab_visible_for_widget(self.hints_editor, not self.is_dbase_document)' in p
assert 'QLineEdit(old_name, dialog)' in p
assert 'self._commit_dbase_program_rename(item, name_edit.text(), old_name)' in p
assert 'self._show_dbase_rename_collision_warning()' in p
print('Stage 337: focused source regressions passed')
