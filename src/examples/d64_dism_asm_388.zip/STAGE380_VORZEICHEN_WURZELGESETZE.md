# Stage 380 – Vorzeichenregeln, Wurzel-Gesetze und Matrixkacheln

Basis: `d64_dism_asm_379.zip`.

- Matrix-Rechnungskacheln von 292 auf **242 px** gekürzt (50 px weniger); die äußere Kachel bemisst sich weiterhin am Inhalt.
- Unter `Grundwissen → Rechengesetze → Grundrechen-Arten` acht neue Endblätter eingefügt:
  `Minus MUL Minus`, `Minus MUL Plus`, `Plus MUL Minus`, `Plus MUL Plus`,
  `Minus DIV Minus`, `Minus DIV Plus`, `Plus DIV Minus`, `Plus DIV Plus`.
- Jede Vorzeichenregel enthält die Erklärung und zwei konkrete Aufgaben samt gelb markiertem Ergebnis.
- `Wurzel-Gesetze` als eigenes Endblatt direkt **nach Potenzen** unter `Grundwissen → Rechengesetze`.
- Dort fünf Wurzelgesetze mit Definitionsbedingungen, Zahlenbeispielen und Lösungen.
- Bestehende Mathematik-Navigation und Matrix-Ansichten bleiben erhalten.

## Prüfumgebung
- `python -m py_compile d64_dism.py` erfolgreich.
- Acht Navigation-/Darstellungstests der Stages 370, 373 und 377 erfolgreich.
- Nativer Windows/PyQt5-Oberflächentest steht aus.
