# -*- coding: utf-8 -*-
"""Stage 352: Regression fuer Qt5 NoBrush und Umschalten der Nebenfluss-Overlays.

Qt-abhaengigkeitsfrei: ein strenger Qt-API-Stub faengt den in Stage 351
aufgetretenen setBrush(Qt.NoBrush)-Typfehler ab.
"""
import ast
from pathlib import Path
import unittest

SOURCE = (Path(__file__).resolve().parent / "d64_dism.py").read_text(encoding="utf-8")
FRANCE_CLASS_SOURCE = SOURCE[SOURCE.index("class FranceMapView("):SOURCE.index("\nclass FranceMapDock(")]


class Stage352FranceTributaryTests(unittest.TestCase):
    def test_no_brush_is_a_qbrush_not_a_brushstyle(self):
        cls = next(n for n in ast.parse(FRANCE_CLASS_SOURCE).body if isinstance(n, ast.ClassDef) and n.name == "FranceMapView")
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "_create_tributary_overlay_items")
        fragment = ast.get_source_segment(FRANCE_CLASS_SOURCE, method)
        self.assertIn("item.setBrush(QBrush(Qt.NoBrush))", fragment)
        self.assertNotIn("item.setBrush(Qt.NoBrush)", fragment)

    def test_tributaries_create_and_switch_visibility(self):
        cls = next(n for n in ast.parse(FRANCE_CLASS_SOURCE).body if isinstance(n, ast.ClassDef) and n.name == "FranceMapView")
        functions = [n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name in (
            "_create_tributary_overlay_items", "_hide_all_tributary_items", "_show_tributaries_for_river")]
        code = ast.Module(body=functions, type_ignores=[])
        ast.fix_missing_locations(code)

        class Qt:
            NoBrush = object()
            RoundCap = object()
            RoundJoin = object()

        class QBrush:
            def __init__(self, style):
                assert style is Qt.NoBrush
                self.style = style

        class QColor:
            def __init__(self, *args): pass

        class QPen:
            def __init__(self, color): pass
            def setWidth(self, width): pass
            def setCapStyle(self, style): pass
            def setJoinStyle(self, style): pass

        class QPointF:
            def __init__(self, x, y): pass

        class QPainterPath:
            def __init__(self, point): pass
            def lineTo(self, x, y): pass

        class QGraphicsPathItem:
            def __init__(self, path): self.visible = False
            def setPen(self, pen): pass
            def setBrush(self, brush):
                if not isinstance(brush, QBrush):
                    raise TypeError("setBrush expected QBrush, not BrushStyle")
            def setZValue(self, z): pass
            def setVisible(self, visible): self.visible = bool(visible)

        class FakeScene:
            def __init__(self): self.items = []
            def addItem(self, item): self.items.append(item)

        env = dict(Qt=Qt, QBrush=QBrush, QColor=QColor, QPen=QPen,
                   QPointF=QPointF, QPainterPath=QPainterPath,
                   QGraphicsPathItem=QGraphicsPathItem)
        exec(compile(code, "<stage352_methods>", "exec"), env)

        class View:
            _create_tributary_overlay_items = env["_create_tributary_overlay_items"]
            _hide_all_tributary_items = env["_hide_all_tributary_items"]
            _show_tributaries_for_river = env["_show_tributaries_for_river"]

        view = View()
        view._scene = FakeScene()
        view._visible_tributary_river = ""
        view._river_hover_data = [
            {"name": "Loire", "tributaries": [
                {"name": "Cher", "points": [(2, 3), (4, 5)]},
                {"name": "Indre", "points": [(7, 8), (9, 10)]}]},
            {"name": "Seine", "tributaries": [
                {"name": "Marne", "points": [(1, 3), (4, 6)]}]},
        ]
        view._create_tributary_overlay_items()  # Hier stuerzte Stage 351 ab.
        self.assertEqual(len(view._scene.items), 3)
        self.assertFalse(any(item.visible for item in view._scene.items))
        view._show_tributaries_for_river("Loire")
        self.assertEqual(sum(item.visible for item in view._scene.items), 2)
        view._show_tributaries_for_river("Seine")
        self.assertEqual(sum(item.visible for item in view._scene.items), 1)
        self.assertTrue(view._tributary_items_by_river["Seine"][0].visible)
        self.assertTrue(all(not item.visible for item in view._tributary_items_by_river["Loire"]))
        view._hide_all_tributary_items()
        self.assertFalse(any(item.visible for item in view._scene.items))

if __name__ == "__main__":
    unittest.main()
