"""Stage 371: Rechengesetze und Potenzen sind gleichrangige Endblätter."""
from pathlib import Path
import ast
import unittest

import test_stage367_math_rules_widget_init as stage367


class TestStage370PotenzenLeaves(unittest.TestCase):
    LAW_NAMES = (
        ('law_commutative', 'Kommutativ-Gesetz'),
        ('law_associative_add', 'Assoziativ-Gesetz Addition'),
        ('law_associative_multiply', 'Assoziativ-Geset Multiplikation'),
        ('law_distributive', 'Distributiv-Gesetz'),
    )

    def setUp(self):
        self.math = stage367.MathWidget()
        self.rules = self.math.facts_tree.children[0]._child_items[0]
        self.powers = self.rules._child_items[4]

    def test_four_laws_are_childless_and_keep_their_navigation(self):
        self.assertEqual(self.powers.label, 'Potenzen')
        self.assertEqual(self.powers._child_items, [])
        self.assertEqual([item.label for item in self.rules._child_items[6:]],
                         [title for _, title in self.LAW_NAMES])
        for key, title in self.LAW_NAMES:
            with self.subTest(key=key):
                leaf = self.math._fact_items[key]
                self.assertEqual(leaf.label, title)
                self.assertEqual(leaf._child_items, [])
                self.assertTrue(any(name == 'setChildIndicatorPolicy'
                                    for name, _args, _kwargs in leaf.calls))
                self.assertTrue(any(name == 'setFlags'
                                    for name, _args, _kwargs in leaf.calls))
                self.math.open_fact(key, title)
                self.assertIs(self.math.content_stack._current,
                              self.math.basic_math_rules_scroll)
                self.assertIn(('activate_fact', (key, title), {}),
                              self.math.basic_math_rules_widget.calls)

    def test_no_other_tree_structure_changes(self):
        self.assertEqual([item.label for item in self.rules._child_items],
                         ['Grundrechen-Arten', 'Punkt-vor-Strich-Rechnung', 'Vorzeichen-Regeln', 'Teilbarkeit', 'Potenzen', 'Wurzel-Gesetze', 'Kommutativ-Gesetz', 'Assoziativ-Gesetz Addition', 'Assoziativ-Geset Multiplikation', 'Distributiv-Gesetz'])
        self.assertEqual([item.label for item in self.rules._child_items[0]._child_items],
                         [])
        self.assertEqual([item.label for item in self.rules._child_items[3]._child_items],
                         ['Brüche'])
        self.assertEqual([item.label for item in self.math.facts_tree.children[0]._child_items],
                         ['Rechengesetze', 'Algebra', 'Geometrie', 'Trigometrie'])

    def test_uses_native_qt5_leaf_flags_without_children(self):
        src = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
        pos = src.index("('law_commutative', 'Kommutativ-Gesetz')", src.index('def _populate_facts_tree'))
        part = src[pos:src.index('# Stage 368:', pos)]
        self.assertIn('QTreeWidgetItem.DontShowIndicatorWhenChildless', part)
        self.assertIn('Qt.ItemNeverHasChildren', part)
        self.assertEqual(part.count('rules.addChild(law_item)'), 1)


if __name__ == '__main__':
    unittest.main()
