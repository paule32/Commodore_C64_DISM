import ast
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("d64_dism.py").read_text(encoding="utf-8")

class Stage377Tests(unittest.TestCase):
    def test_yellow_solution_routine(self):
        tree = ast.parse(SOURCE)
        method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == "_draw_matrix_calculation_box")
        body = ast.get_source_segment(SOURCE, method)
        self.assertIn("QColor('#ffd700')", body)
        self.assertIn("answer_top", body)
        self.assertIn("task_top", body)
        self.assertIn("task, answer", body)
    def test_calc_boxes_use_solution_routine(self):
        self.assertIn("self._draw_matrix_calculation_box(painter, calc_box, heading, formula, colors)", SOURCE)
        self.assertIn("calc_h = 274.0", SOURCE)
        self.assertIn("self._draw_matrix_example_box(painter, matrix_box, 'Matrixform', matrix_text, colors)", SOURCE)

if __name__ == "__main__": unittest.main()
