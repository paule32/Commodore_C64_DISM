"""Stage 341: phonetic/prosodic DSP tuning regression tests (no Windows playback needed)."""
import ctypes
import hashlib
import os
import shutil
import subprocess
import tempfile
import unittest
import wave
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'speech'

@unittest.skipUnless(shutil.which('gcc'), 'GCC required for portable DSP testing')
class FineTuneTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temps=tempfile.TemporaryDirectory(prefix='stage341_')
        cls.tmp=Path(cls.temps.name)
        cls.so=cls.tmp/'libretro341.so'
        subprocess.run(['gcc','-std=c99','-O2','-Wall','-Wextra','-Werror',
                        '-fPIC','-shared',str(SRC/'retro_speech.c'),'-lm','-o',str(cls.so)],
                       check=True,capture_output=True)
        cls.dll=ctypes.CDLL(str(cls.so))
        for name in ('SpeechInitialize','SpeechSetMix','SpeechSetPitch','SpeechSetSpeed',
                     'SpeechSetExpression','SpeechSetArticulation'):
            f=getattr(cls.dll,name);f.argtypes=[ctypes.c_int32];f.restype=ctypes.c_int32
        for name in ('SpeechRenderText','SpeechRenderPhonemes'):
            f=getattr(cls.dll,name)
            f.argtypes=[ctypes.c_char_p,ctypes.POINTER(ctypes.c_int16),ctypes.c_uint32]
            f.restype=ctypes.c_uint32
        cls.dll.SpeechSaveWav.argtypes=[ctypes.c_char_p,ctypes.c_char_p]
        cls.dll.SpeechSaveWav.restype=ctypes.c_int32
        cls.dll.SpeechGetLastError.restype=ctypes.c_int32
        cls.dll.SpeechGetLastErrorText.restype=ctypes.c_char_p
    @classmethod
    def tearDownClass(cls):cls.temps.cleanup()
    def setUp(self):
        for name,arg in [('SpeechInitialize',22050),('SpeechSetMix',55),('SpeechSetPitch',125),
                         ('SpeechSetSpeed',100),('SpeechSetExpression',60),('SpeechSetArticulation',65)]:
            self.assertEqual(getattr(self.dll,name)(arg),1)
    def render(self,text,method='SpeechRenderText'):
        if isinstance(text,str):text=text.encode('utf-8')
        f=getattr(self.dll,method)
        n=f(text,None,0)
        self.assertGreater(n,0)
        buf=(ctypes.c_int16*n)()
        self.assertEqual(f(text,buf,n),n)
        return bytes(buf)
    def test_expression_changes_actual_pcm_without_changing_duration(self):
        self.dll.SpeechSetExpression(0)
        flat=self.render('Hallo, ich bin dein Sprachcomputer.')
        self.dll.SpeechSetExpression(100)
        expressive=self.render('Hallo, ich bin dein Sprachcomputer.')
        self.assertEqual(len(flat),len(expressive))
        self.assertNotEqual(hashlib.sha256(flat).digest(),hashlib.sha256(expressive).digest())
    def test_articulation_controls_consonants_without_changing_duration(self):
        self.dll.SpeechSetArticulation(0)
        soft=self.render('Sprache, Tisch und Schrank')
        self.dll.SpeechSetArticulation(100)
        crisp=self.render('Sprache, Tisch und Schrank')
        self.assertEqual(len(soft),len(crisp))
        self.assertNotEqual(soft,crisp)
    def test_question_rises_before_pause_even_for_short_sentence(self):
        statement=self.render('Ja.')
        question=self.render('Ja?')
        # Same voiced beginning; check before punctuation starts, not pause length.
        self.assertNotEqual(statement[:2400],question[:2400])
    def test_new_german_clusters_and_umlauts(self):
        text='Willkommen! Heute sprechen wir über Äpfel, Frösche, Pferde und Pfützen.'
        data=self.render(text)
        self.assertGreater(len(data),10000)
        self.assertLess(len(data),22050*2*90)
    def test_determinism_and_direct_phonemes(self):
        a=self.render('Hallo Welt!')
        self.assertEqual(a,self.render('Hallo Welt!'))
        self.assertGreater(len(self.render('H A L O ?','SpeechRenderPhonemes')),0)
    def test_new_controls_validate_bounds_and_reset_error(self):
        self.assertEqual(self.dll.SpeechSetExpression(-1),0)
        self.assertEqual(self.dll.SpeechGetLastError(),1)
        self.assertEqual(self.dll.SpeechSetExpression(101),0)
        self.assertEqual(self.dll.SpeechSetArticulation(-1),0)
        self.assertEqual(self.dll.SpeechSetArticulation(101),0)
        self.assertEqual(self.dll.SpeechSetExpression(80),1)
        self.assertEqual(self.dll.SpeechGetLastError(),0)
    def test_wav_saved_and_has_audio_content(self):
        filename=self.tmp/'fine.wav'
        self.assertEqual(self.dll.SpeechSaveWav(os.fsencode(filename),'Guten Tag!'.encode()),1)
        with wave.open(str(filename),'rb') as wav:
            self.assertEqual((wav.getframerate(),wav.getsampwidth(),wav.getnchannels()),(22050,2,1))
            self.assertGreater(wav.getnframes(),20000)
            self.assertTrue(any(wav.readframes(wav.getnframes())))
    def test_cli_presets_and_override_order(self):
        exe=self.tmp/'demo_presets'
        subprocess.run(['gcc','-std=c99','-O2','-Wall','-Wextra','-Werror',
                        str(SRC/'retro_speech_demo.c'),'-L'+str(self.tmp),'-lretro341',
                        '-o',str(exe)],check=True,capture_output=True)
        env={**os.environ,'LD_LIBRARY_PATH':str(self.tmp)}
        a=self.tmp/'c64.wav';b=self.tmp/'amiga.wav'
        for preset,path in [('c64',a),('amiga',b)]:
            proc=subprocess.run([str(exe),'--no-play','--preset',preset,'--wav',str(path)],
                                capture_output=True,text=True,env=env,check=True)
            self.assertIn('Amiga:',proc.stdout)
        self.assertNotEqual(a.read_bytes(),b.read_bytes())
        overridden=subprocess.run([str(exe),'--no-play','--preset','c64',
                                 '--mix','44','--wav',str(self.tmp/'override.wav')],
                                capture_output=True,text=True,env=env,check=True)
        self.assertIn('Amiga: 44%',overridden.stdout)
        invalid=subprocess.run([str(exe),'--preset','unknown'],
                              capture_output=True,text=True,env=env)
        self.assertEqual(invalid.returncode,2)

    def test_demo_dynamic_linking_with_new_options(self):
        exe=self.tmp/'demo'
        subprocess.run(['gcc','-std=c99','-O2','-Wall','-Wextra','-Werror',
                        str(SRC/'retro_speech_demo.c'),'-L'+str(self.tmp),'-lretro341',
                        '-o',str(exe)],check=True,capture_output=True)
        wav=self.tmp/'demo.wav'
        result=subprocess.run([str(exe),'--no-play','--wav',str(wav),'--expression','85',
                               '--articulation','45','--text','Hallo!'],
                              check=True,capture_output=True,text=True,
                              env={**os.environ,'LD_LIBRARY_PATH':str(self.tmp)})
        self.assertIn('expression: 85%',result.stdout)
        self.assertIn('articulation: 45%',result.stdout)
        self.assertTrue(wav.exists())

if __name__=='__main__':unittest.main(verbosity=2)
