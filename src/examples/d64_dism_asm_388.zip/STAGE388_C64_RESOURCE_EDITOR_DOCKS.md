# Stage 388 – C64-Ressourcen-Editoren und Resource Alias Builder als Docking-Fenster

Verbindliche Basis: `d64_dism_asm_387.zip` (vollständige Datei wurde unverändert übernommen, mit gezielten Änderungen an `d64_dism.py`).

## Änderungen

* `C64CharacterEditorDialog`, `C64PaletteEditorDialog`, `C64TextScreenEditorDialog`, `C64PixelScreenEditorDialog` und `ResourceBuilderToolWindow` werden als `QWidget` instanziiert. Sie verwenden keine modalen QDialog-Fenster mehr.
* `C64ToolEditorDock(QDockWidget)` übernimmt das korrekte Schließen mit `_confirm_discard()` (Speichern / Verwerfen / Abbrechen) und das anschließende Freigeben.
* `ExplorerWindow._show_c64_tool_dock(kind, initial_path=...)` erzeugt genau einen Dock-Host pro Werkzeug, reaktiviert existierende Docks und lädt bei Bedarf andere Ressourcenblätter.
* Alle fünf Docks besitzen die in der IDE übliche Titelleiste (`DockTitleBar`), lassen sich schließen, verschieben, abdocken und links/rechts/oben/unten einrasten.
* Der Inhalt wird in einer `QScrollArea` dargestellt, damit breite Pixel-/Zeichen-Editoren nicht die Hauptfensterabmessungen erzwingen.
* Der Dock-Titel berücksichtigt den Bearbeitungsstatus `*` des eingebetteten Editors.
* `Schließen` im jeweiligen Editor schließt den zugehörigen Dock-Host und führt dessen Speicherrückfrage aus.
* `Datei > ... > Resource Builder` öffnet den Resource Alias Builder als Dock statt `exec_()`.
* Einzelklick auf einen Stage-387-Ressourceneintrag führt weiterhin über `open_project_c64_resource` in den passenden Editor-Dock.
* Beim Beenden der Anwendung werden noch offene, modifizierte C64-Editoren vorab gefragt.
* Der eigenständige C64-Sprite-Editor bleibt von dieser ausdrücklich auf fünf Werkzeuge beschränkten Änderung unberührt.

## Neue Dock-Objektnamen

- `c64_character_editor_dock`
- `c64_palette_editor_dock`
- `c64_text_screen_editor_dock`
- `c64_pixel_screen_editor_dock`
- `c64_resource_alias_builder_dock`

## Tests

* `python -m py_compile d64_dism.py` – bestanden.
* `python test_stage388_docking.py` – bestanden (statische AST-Prüfung und isolierte Lifecycle-Tests für fünf Docks einschließlich gleicher Datei, anderer Datei, Abbrechen, Close-Button und Alias Builder).
* GUI-Laufzeittest unter Windows/PyQt5 **nicht** ausgeführt (PyQt5 ist in der Testumgebung nicht installiert).

## Empfohlene manuelle Tests unter Windows

1. Projekt mit `.chr`, `.pal`, `.scr` und `.px16` öffnen; Ressourcenblatt anklicken.
2. Dialog darf nicht modal erscheinen; Dock verschieben, abdocken, wieder andocken.
3. Datei bearbeiten, dann Dock-X klicken: Speichern / Verwerfen / Abbrechen prüfen.
4. Dasselbe über die Schaltfläche `Schließen` prüfen.
5. Zweite Datei gleichen Typs im Projektbaum anklicken; vorherige Änderungen dürfen nicht ohne Rückfrage verloren gehen.
6. Datei erneut anklicken; kein Reload einer bereits geöffneten geänderten Datei.
7. Resource Builder aus dem Menü öffnen, Dock schließen und neu öffnen.
8. Anwendung mit ungespeicherten Ressourcen beenden und Abbruch prüfen.
