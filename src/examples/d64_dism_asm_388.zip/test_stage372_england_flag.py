"""Stage 372: England map contains a valid St. George's Cross in the top-right flag box."""

from base64 import b85decode
from io import BytesIO
from pathlib import Path
import importlib.util
import unittest

from PIL import Image


def _load_england_module():
    path = Path(__file__).with_name("england.py")
    spec = importlib.util.spec_from_file_location("stage372_england", path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


class TestStage372EnglandFlag(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        mod = _load_england_module()
        data = b85decode(mod.ENGLAND_MAP_IMAGE_B85)
        cls.image = Image.open(BytesIO(data)).convert("RGBA")

    def test_image_size_unchanged(self):
        self.assertEqual(self.image.size, (371, 463))

    def test_top_right_flag_box_shows_st_georges_cross(self):
        px = self.image.load()

        def rgb(x, y):
            r, g, b, _a = px[x, y]
            return (r, g, b)

        def is_white(c):
            r, g, b = c
            return r >= 240 and g >= 240 and b >= 240

        def is_red(c):
            r, g, b = c
            return r >= 150 and g <= 80 and b <= 80

        # outer corners inside the flag field remain white
        for point in ((268, 23), (335, 23), (268, 58), (335, 58)):
            with self.subTest(point=point):
                self.assertTrue(is_white(rgb(*point)), rgb(*point))

        # horizontal bar
        for point in ((270, 40), (287, 40), (316, 40), (334, 40)):
            with self.subTest(point=point):
                self.assertTrue(is_red(rgb(*point)), rgb(*point))

        # vertical bar
        for point in ((301, 24), (301, 32), (301, 50), (301, 58)):
            with self.subTest(point=point):
                self.assertTrue(is_red(rgb(*point)), rgb(*point))


if __name__ == '__main__':
    unittest.main()
