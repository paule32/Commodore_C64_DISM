# Stage 381 – Vorzeichen-Regeln als Sammelblatt

Verbindliche Basis: `d64_dism_asm_380.zip`.

- `Grundwissen → Rechengesetze → Grundrechen-Arten` ist ein Blatt (keine Kinder).
- `Punkt-vor-Strich-Rechnung` und `Vorzeichen-Regeln` sind direkt darunter gleichrangige Blätter.
- Die acht früheren einzelnen `Minus/Plus MUL/DIV`-Blätter wurden aus der Navigation entfernt.
- Die neue `Vorzeichen-Regeln`-Ansicht verwendet alle acht vorhandenen Regeln aus `SIGN_RULE_CARDS` und zeichnet pro Regel eine Kachel mit Erklärung, zwei Aufgaben und gelben Lösungen.
- Vorzeichen-Kachelhöhe von 122 auf 143 Pixel (+21 px); Innenabstände verhindern die bisherige vertikale Überzeichnung.
- `BasicMathRulesFactWidget._paint_sign_rule` bleibt für API-Kompatibilität erhalten.

Prüfung: Python-Syntax und gezielte Regressionstests. Native Windows/Qt5-Sichtprüfung ist noch ausstehend.
