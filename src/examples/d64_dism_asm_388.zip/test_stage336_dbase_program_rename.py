from pathlib import Path
import ast

source = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
ast.parse(source)
for name in ('_begin_dbase_program_rename', '_commit_dbase_program_rename', '_show_dbase_rename_collision_warning'):
    assert f'def {name}(' in source, name
assert 'menu.addAction("Umbenennen") if role == "programs"' in source
assert 'QLineEdit(old_name, dialog)' in source
assert 'Warnung: Datei mit gleichen Namen existiert bereits!' in source
assert 'DBaseTableDialogTitleBar(dialog, "Warnung", dark_mode=True)' in source
assert 'border:3px solid #707070' in source
assert 'old_path.rename(target)' in source
assert 'self._find_open_document(old_path)' in source
assert 'item.setText(0, old_name)' in source
assert 'self.save_project()' in source
print('Stage 336: structural tests passed')
