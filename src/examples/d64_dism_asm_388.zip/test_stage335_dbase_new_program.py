"""Stage 335: isolated source regression tests, no PyQt required."""
from pathlib import Path
s=Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
menu=s[s.index('        def _show_project_dbase_group_menu('):s.index('        def _show_project_dbase_file_menu(')]
assert 'if role == "programs":' in menu
assert menu.index('menu.addAction("Neu Programm-Datei")') < menu.index('menu.addAction("Hinzufügen"')
assert 'self._create_new_dbase_program_item(use_template=False)' in menu
new=s[s.index('        def _create_new_dbase_program_item('):s.index('        def _new_project_item_for_category(')]
assert '"unbenannt.prg" if number == 0' in new
assert 'self.open_document(path, language_override="dbase")' in new
save=s[s.index('        def _choose_document_filename('):s.index('        def _save_document(')]
for x in ('*.prg','*.wfm','*.sql','*.txt','*.*'):
    assert x in save
assert 'language_override' in save and 'if is_dbase_editor:' in save
print('Stage 335: Kontextmenü, Dateianlage, Editorstart, Filter OK')
