# Stage 375 – Matrixbeispiele mit Zeilenumbrüchen und Beispielrechnungen

Basis: `d64_dism_asm_374.zip`

## Änderungen
- Matrixbeispiele in den Lernansichten werden nicht mehr mit `;` in einer Zeile gezeigt.
- Jede durch `;` getrennte Matrixzeile wird jetzt in einer eigenen Zeile dargestellt.
- Die Einträge innerhalb einer Zeile werden mit Kommas formatiert.
- Unter der Matrixdarstellung werden ein oder zwei Beispielrechnungen gezeichnet,
  abhängig von der verfügbaren Höhe der Arbeitsfläche.

## Beispiel
Aus

```text
[ 1 2 3 ; 3 1 2 ; 2 3 1 ]
```

wird

```text
[ 1, 2, 3 ]
[ 3, 1, 2 ]
[ 2, 3, 1 ]
```

## Tests
- `test_stage375_matrix_examples.py`
- bestehende Mathematik-/Geographie-Regressionen unverändert ausführbar
