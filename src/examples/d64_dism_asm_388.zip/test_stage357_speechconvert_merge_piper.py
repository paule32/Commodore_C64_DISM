"""Stage 357: SPC merge compatibility and Piper model selection tests."""
import io
import contextlib
import os
from pathlib import Path
import subprocess
import ctypes
import shutil
import sys
import tempfile
import unittest
import wave

import speechConvert as sc

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / 'speechConvert.py'


def wav_file(path: Path, amplitude: int = 1700):
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes((int(amplitude).to_bytes(2, 'little', signed=True) * 480) + b'\x00' * 64)


class Stage357SpeechToolTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.root = Path(self.dir.name)
        self.audio = self.root / 'du.wav'
        wav_file(self.audio)
        self.first = self.root / 'first.spc'
        self.second = self.root / 'second.spc'
        self.run_tool(self.audio, '-s', '-a', 'DU', '-oc', self.first)
        self.run_tool(self.audio, '-s', '-a', 'ICH', '-oc', self.second, '-gz')

    def tearDown(self):
        self.dir.cleanup()

    def run_tool(self, *args, ok=True):
        stdout, stderr = io.StringIO(), io.StringIO()
        code = 0
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                code = sc.main([str(arg) for arg in args])
            except (sc.SpeechError, OSError, ValueError) as ex:
                print(f'Fehler: {ex}', file=sys.stderr)
                code = 1
            except SystemExit as ex:
                code = ex.code or 0
        self.assertEqual(code == 0, ok, stdout.getvalue() + '\n' + stderr.getvalue())
        return type('Result', (), {'returncode': code, 'stdout': stdout.getvalue(), 'stderr': stderr.getvalue()})()

    def test_merge_inplace_and_preserve_payload_bytes(self):
        src = self.second.read_bytes()
        old = self.first.read_bytes()
        p = self.run_tool('-m', self.first, self.second, '--verify')
        self.assertIn('CRC OK: 2', p.stdout)
        items = sc.read_container(self.first)
        self.assertEqual(set(items), {'du', 'ich'})
        self.assertEqual(items['ich'].codec & sc.CODEC_GZIP_FLAG, sc.CODEC_GZIP_FLAG)
        self.assertEqual(self.second.read_bytes(), src)
        self.assertNotEqual(self.first.read_bytes(), old)
        with self.second.open('rb') as f1, self.first.open('rb') as f2:
            source = sc.read_container(self.second)['ich']
            f1.seek(source.offset)
            f2.seek(items['ich'].offset)
            self.assertEqual(f1.read(source.size), f2.read(items['ich'].size))

    @unittest.skipUnless(shutil.which('gcc'), 'Native GCC needed')
    def test_native_container_reader_accepts_merged_gzip_entries(self):
        out = self.root / 'merge_native.spc'
        self.run_tool('--merge', self.first, self.second, '-oc', out, '--verify')
        shared = self.root / 'retro_speech.so'
        subprocess.run(['gcc', '-O2', '-std=c99', '-Wall', '-Wextra', '-Werror',
                        '-shared', '-fPIC', str(HERE / 'speech' / 'retro_speech.c'),
                        '-lm', '-o', str(shared)], check=True, timeout=45)
        dll = ctypes.CDLL(str(shared))
        dll.SpeechInitialize.argtypes = [ctypes.c_int32]
        dll.SpeechLoadContainer.argtypes = [ctypes.c_char_p]
        dll.SpeechLoadContainer.restype = ctypes.c_int32
        dll.SpeechRenderSample.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_int16), ctypes.c_uint32]
        dll.SpeechRenderSample.restype = ctypes.c_uint32
        self.assertEqual(dll.SpeechInitialize(16000), 1)
        self.assertEqual(dll.SpeechLoadContainer(os.fsencode(out)), 1)
        for name in (b'DU', b'ICH'):
            needed = dll.SpeechRenderSample(name, None, 0)
            self.assertGreater(needed, 400)
            buffer = (ctypes.c_int16 * needed)()
            self.assertEqual(dll.SpeechRenderSample(name, buffer, needed), needed)

    def test_merge_output_stays_separate(self):
        out = self.root / 'union.spc'
        original1 = self.first.read_bytes()
        original2 = self.second.read_bytes()
        self.run_tool('-m', self.first, self.second, '-oc', out, '--verify')
        self.assertEqual(self.first.read_bytes(), original1)
        self.assertEqual(self.second.read_bytes(), original2)
        self.assertEqual(set(sc.read_container(out)), {'du', 'ich'})

    def test_collision_default_keeps_first_and_override_replaces(self):
        self.run_tool(self.audio, '-c', 'pcm', '-a', 'DU', '-oc', self.second, '-gz')
        out = self.root / 'keep.spc'
        self.run_tool('--merge', self.first, self.second, '-oc', out)
        self.assertEqual(sc.read_container(out)['du'].codec & 0x7f, sc.CODECS['ima-adpcm'])
        self.run_tool('--merge', self.first, self.second, '-oc', out, '--on-conflict', 'replace')
        self.assertEqual(sc.read_container(out)['du'].codec & 0x7f, sc.CODECS['pcm'])
        before = self.first.read_bytes()
        self.run_tool('-m', self.first, self.second, '--on-conflict', 'error', ok=False)
        self.assertEqual(self.first.read_bytes(), before)

    def test_invalid_second_does_not_change_first(self):
        damaged = self.root / 'bad.spc'
        damaged.write_bytes(b'not an spc')
        original = self.first.read_bytes()
        self.run_tool('-m', self.first, damaged, ok=False)
        self.assertEqual(self.first.read_bytes(), original)

    def test_same_source_rejected(self):
        self.run_tool('-m', self.first, self.first, ok=False)

    def test_voice_catalog_and_language_alias(self):
        p = self.run_tool('--list-voices', '-l', 'en-US')
        self.assertIn('en_US-amy-medium.onnx', p.stdout)
        self.assertNotIn('de_DE-thorsten-high.onnx', p.stdout)
        self.assertEqual(sc.normalize_language('DE-de'), 'de_DE')
        self.run_tool('--list-voices', '-l', 'some-invalid', ok=False)

    def test_piper_model_selection_requires_matching_locale_and_json(self):
        folder = self.root / 'models'
        folder.mkdir()
        file = folder / 'en_US-amy-medium.onnx'
        file.write_bytes(b'example')
        config = Path(str(file) + '.json')
        config.write_text('{}')
        parser = sc._arg_parser()
        args = parser.parse_args(['--text', 'Hello', '-l', 'en_US', '--model-dir', str(folder)])
        self.assertEqual(sc.piper_model_path(args), file)
        args = parser.parse_args(['--text', 'Hallo', '--model', str(file), '-l', 'de_DE'])
        with self.assertRaises(sc.SpeechError):
            sc.piper_model_path(args)
        config.unlink()
        args = parser.parse_args(['--text', 'Hello', '-l', 'en_US', '--model-dir', str(folder)])
        with self.assertRaises(sc.SpeechError):
            sc.piper_model_path(args)

    @unittest.skipIf(os.name == 'nt', 'Fake executable uses a POSIX shebang')
    def test_mock_piper_writes_wav_and_adds_to_container(self):
        folder = self.root / 'piper'
        folder.mkdir()
        model = folder / 'en_US-amy-medium.onnx'
        model.write_bytes(b'fake')
        Path(str(model) + '.json').write_text('{}')
        executable = folder / 'piper'
        executable.write_text('#!/usr/bin/env python3\n'
                              'import sys, wave, pathlib\n'
                              'assert "--model" in sys.argv\n'
                              'assert sys.stdin.read().strip()=="Hello from Piper"\n'
                              'p=pathlib.Path(sys.argv[sys.argv.index("--output_file")+1])\n'
                              'with wave.open(str(p),"wb") as w:\n'
                              '  w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(b"\\x00\\x01"*800)\n')
        executable.chmod(0o755)
        destination = self.root / 'voice.spc'
        p = self.run_tool('--text', 'Hello from Piper', '-l', 'en_US', '--model-dir', folder,
                          '--piper', executable, '-oc', destination, '-a', 'HELLO', '--verify')
        self.assertIn('ADD: HELLO', p.stdout)
        self.assertIn('hello', sc.read_container(destination))
        out = self.root / 'tts.wav'
        self.run_tool('--text', 'Hello from Piper', '-l', 'en_US', '--model-dir', folder,
                      '--piper', executable, '-c', 'pcm', '-ow', out)
        with wave.open(str(out), 'rb') as w:
            self.assertEqual(w.getnframes(), 800)


if __name__ == '__main__':
    unittest.main(verbosity=2)
