import unittest
from d64dbase.class_model import DBaseClassRegistry, DBaseClassError, parse_dbase_class_metadata
from d64dbase.wfm import parse_dbase_wfm

class TObjectMetadataTests(unittest.TestCase):
    def test_default_parent_and_chain(self):
        reg = parse_dbase_class_metadata('''CLASS TPerson
 PROPERTY Name
 METHOD Create()
 RETURN
ENDCLASS
CLASS TEmployee OF TPerson
ENDCLASS''')
        self.assertEqual(reg.get('TPerson').parent, 'TObject')
        self.assertEqual(reg.ancestors('TEmployee'), ('TPerson', 'TObject'))
        self.assertTrue(reg.inherits_from('temployee', 'TOBJECT'))
        self.assertEqual(reg.class_name('temployee'), 'TEmployee')
        self.assertIn('Create', reg.class_type('TPerson').methods)
    def test_tv_app(self):
        reg = parse_dbase_class_metadata('CLASS TApplication OF TV_Application\nENDCLASS')
        self.assertEqual(reg.ancestors('TApplication'), ('TV_Application', 'TV_Object', 'TObject'))
    def test_reject_missing_and_cycles(self):
        with self.assertRaises(DBaseClassError):
            parse_dbase_class_metadata('CLASS Broken OF Missing\nENDCLASS')
        with self.assertRaises(DBaseClassError):
            parse_dbase_class_metadata('CLASS A OF B\nENDCLASS\nCLASS B OF A\nENDCLASS')
    def test_wfm_compat(self):
        form = parse_dbase_wfm('CLASS Form1 OF FORM\nENDCLASS')
        self.assertEqual(form.base_class, 'FORM')
        self.assertEqual(form.class_registry.ancestors('Form1'), ('FORM','TObject'))
    def test_bad_end(self):
        with self.assertRaises(DBaseClassError):
            parse_dbase_class_metadata('CLASS A\n')

if __name__ == '__main__': unittest.main()
