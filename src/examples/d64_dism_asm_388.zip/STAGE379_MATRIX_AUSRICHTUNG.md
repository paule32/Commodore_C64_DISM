# Stage 379 – Matrixberechnungen ausrichten und vergrößern

Basis: `d64_dism_asm_378.zip`.

- Beispielrechnungs-Kachel: 292 Pixel statt 192 Pixel.
- Parent-Kachel passt sich weiter dynamisch der Gesamthöhe an.
- Bei mehrzeiligen Matrizen werden Fortsetzungszeilen unter die erste öffnende Matrixklammer eingerückt. Das gilt für Aufgabe und gelbe Lösung.
- Die durch `;` getrennten Matrixzeilen und die vorhandenen Rechenwege bleiben erhalten.

Ein nativer PyQt5-Oberflächentest unter Windows steht aus.
