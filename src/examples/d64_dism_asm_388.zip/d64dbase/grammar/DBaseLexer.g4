lexer grammar DBaseLexer;

// ---------------------------------------------------------------------------
// dBase lexical layer, stage 24: comments, expressions, members, IF blocks,
// object paths, NEW MENU/SESSION/DATABASE, SESSION.Login und DATABASE-Lifecycle and WITH/ENDWITH.
// ---------------------------------------------------------------------------

STRING_DOUBLE
    : '"' ( '""' | '\\' . | ~["\r\n] )* '"'
    ;

STRING_SINGLE
    : '\'' ( '\'\'' | '\\' . | ~['\r\n] )* '\''
    ;

BLOCK_COMMENT
    : '/*' .*? '*/' -> channel(HIDDEN)
    ;

LINE_COMMENT_SLASH
    : '//' ~[\r\n]* -> channel(HIDDEN)
    ;

LINE_COMMENT_STAR
    : '**' ~[\r\n]* -> channel(HIDDEN)
    ;

LINE_COMMENT_AMP
    : '&&' ~[\r\n]* -> channel(HIDDEN)
    ;

PROCEDURE : [Pp][Rr][Oo][Cc][Ee][Dd][Uu][Rr][Ee];
FUNCTION  : [Ff][Uu][Nn][Cc][Tt][Ii][Oo][Nn];
RETURN    : [Rr][Ee][Tt][Uu][Rr][Nn];
IF        : [Ii][Ff];
ELSEIF    : [Ee][Ll][Ss][Ee][Ii][Ff];
ELSE      : [Ee][Ll][Ss][Ee];
ENDIF     : [Ee][Nn][Dd][Ii][Ff];
WITH      : [Ww][Ii][Tt][Hh];
ENDWITH   : [Ee][Nn][Dd][Ww][Ii][Tt][Hh];
NEW       : [Nn][Ee][Ww];
MENU      : [Mm][Ee][Nn][Uu];
SESSION   : [Ss][Ee][Ss][Ss][Ii][Oo][Nn];
DATABASE  : [Dd][Aa][Tt][Aa][Bb][Aa][Ss][Ee];
LOCAL     : [Ll][Oo][Cc][Aa][Ll];
AS        : [Aa][Ss];
PATH      : [Pp][Aa][Tt][Hh];
DATABASENAME : [Dd][Aa][Tt][Aa][Bb][Aa][Ss][Ee][Nn][Aa][Mm][Ee];
USERNAME  : [Uu][Ss][Ee][Rr][Nn][Aa][Mm][Ee];
PASSWORD  : [Pp][Aa][Ss][Ss][Ww][Oo][Rr][Dd];
ACTIVE    : [Aa][Cc][Tt][Ii][Vv][Ee];
ALIAS     : [Aa][Ll][Ii][Aa][Ss];
OPEN      : [Oo][Pp][Ee][Nn];
CLOSE     : [Cc][Ll][Oo][Ss][Ee];
COMMIT    : [Cc][Oo][Mm][Mm][Ii][Tt];
LOGIN     : [Ll][Oo][Gg][Ii][Nn];
TRUE      : [Tt][Rr][Uu][Ee];
FALSE     : [Ff][Aa][Ll][Ss][Ee];
CLASS     : [Cc][Ll][Aa][Ss][Ss];
SET         : [Ss][Ee][Tt];
CLEAR       : [Cc][Ll][Ee][Aa][Rr];
COLOR       : [Cc][Oo][Ll][Oo][Rr];
BORDERCOLOR : [Bb][Oo][Rr][Dd][Ee][Rr][Cc][Oo][Ll][Oo][Rr];
TO        : [Tt][Oo];
DEBUG     : [Dd][Ee][Bb][Uu][Gg];
FORMAT    : [Ff][Oo][Rr][Mm][Aa][Tt];
ON        : [Oo][Nn];
OFF       : [Oo][Ff][Ff];
SCREEN    : [Ss][Cc][Rr][Ee][Ee][Nn];
CONSOLE   : [Cc][Oo][Nn][Ss][Oo][Ll][Ee];

LOGIC_AND : '.' [Aa][Nn][Dd] '.';
LOGIC_OR  : '.' [Oo][Rr] '.';
LOGIC_NOT : '.' [Nn][Oo][Tt] '.';
LOGIC_XOR : '.' [Xx][Oo][Rr] '.';

QUESTION2 : '??';
QUESTION  : '?';
SCOPE     : '::';
LE        : '<=';
GE        : '>=';
EQEQ      : '==';
NEANGLE   : '<>';
NEBANG    : '!=';
BANG      : '!';
DOLLAR    : '$';
LT        : '<';
GT        : '>';
HASH      : '#';
EQUAL     : '=';
PLUS      : '+';
MINUS     : '-';
STAR      : '*';
SLASH     : '/';
DOT       : '.';
LPAREN    : '(';
RPAREN    : ')';
COMMA     : ',';
LBRACE    : '{';
RBRACE    : '}';

HEX_NUMBER
    : '0' [xX] HEX+
    | '$' HEX+
    | DIGIT HEX* [hH]
    ;

NUMBER
    : DIGIT+ ('.' DIGIT*)? EXPONENT?
    | '.' DIGIT+ EXPONENT?
    ;

IDENTIFIER
    : [A-Za-z_] [A-Za-z0-9_]*
    ;

NEWLINE
    : '\r'? '\n'
    | '\r'
    ;

WS
    : [ \t\f]+ -> channel(HIDDEN)
    ;

fragment DIGIT    : [0-9];
fragment HEX      : [0-9A-Fa-f];
fragment EXPONENT : [eE] [+-]? DIGIT+;
