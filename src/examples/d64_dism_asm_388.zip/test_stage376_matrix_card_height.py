"""Stage 376: Matrix-Rechnungskacheln und dynamischer Außenrahmen."""
import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')


class Stage376MatrixHeightTests(unittest.TestCase):
    def test_100_pixel_increase(self):
        self.assertIn('calc_h = 274.0  # Stage 386: 32 px hoeher als Stage 385', SOURCE)

    def test_parent_height_calculated_before_drawing(self):
        tree = ast.parse(SOURCE)
        method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == '_paint_matrix_type')
        names = [n.func.attr for n in ast.walk(method) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)]
        self.assertIn('addRoundedRect', names)
        code = ast.get_source_segment(SOURCE, method)
        self.assertLess(code.index('required_panel_h = '), code.index('path.addRoundedRect(rect'))
        self.assertIn('panel_h = max(340.0, available_h, required_panel_h)', code)
        self.assertIn('self.setMinimumHeight(int(rect.bottom() + 24))', code)

    def test_one_or_two_examples_stay_within_parent(self):
        panel_y, description_y, gap, padding = 22, 80, 10, 22
        matrix_y = description_y + 48 + 10
        for rows in (1, 3):
            matrix_h = max(112, 50 + 19 * rows)
            calc_start_y = matrix_y + matrix_h + 12 + 28
            for count in (1, 2):
                content_bottom = calc_start_y + count * (292 + gap)
                parent_bottom = panel_y + max(340, content_bottom - panel_y + padding)
                self.assertGreaterEqual(parent_bottom - content_bottom, padding)


if __name__ == '__main__':
    unittest.main()
