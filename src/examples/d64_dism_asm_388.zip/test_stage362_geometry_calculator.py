"""Stage 362: Rechenkern und GUI-Bedienung ohne installierte PyQt5-Bibliothek."""
import math
import re
import textwrap
import unittest
from pathlib import Path

SRC = Path(__file__).with_name('d64_dism.py').read_text(encoding='utf-8')
first = SRC.index('    _GEOMETRY_INPUTS = {')
end = SRC.index('    class GeometryErrorTitleBar(QFrame):', first)
namespace = {'math': math}
exec(compile(textwrap.dedent(SRC[first:end]), 'geometry_stage362_core.py', 'exec'), namespace)
SPECS = namespace['_GEOMETRY_INPUTS']
calc = namespace['_calculate_geometry_fact']

class Signal:
    def __init__(self): self.handlers = []
    def connect(self, callback): self.handlers.append(callback)
    def fire(self):
        for callback in self.handlers: callback()

class Widget:
    def __init__(self, parent=None):
        self._object = None
        self.style = ''
    def setObjectName(self, name): self._object = name
    def setMinimumHeight(self, height): self.min_height = height
    def setMinimumWidth(self, width): self.min_width = width
    def setToolTip(self, text): self.tooltip = text
    def setSizePolicy(self, *args): pass
    def setStyleSheet(self, s): self.style = s
    def setToolTip(self, s): self.tooltip = s
    def setAccessibleName(self, s): self.accessible_name = s
    def deleteLater(self): self.deleted = True

class LayoutItem:
    def __init__(self, obj): self.obj = obj
    def widget(self): return self.obj

class Layout:
    def __init__(self, *args): self.items = []
    def setContentsMargins(self, *args): pass
    def setSpacing(self, spacing): pass
    def setHorizontalSpacing(self, spacing): pass
    def setVerticalSpacing(self, spacing): pass
    def addLayout(self, layout): pass
    def addWidget(self, widget, *args): self.items.append(LayoutItem(widget))
    def takeAt(self, i): return self.items.pop(i)
    def count(self): return len(self.items)

class Input(Widget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._text = ''
        self.textChanged = Signal()
        self._placeholder = ''
        self._readonly = False
    def setPlaceholderText(self, s): self._placeholder = s
    def placeholderText(self): return self._placeholder
    def setReadOnly(self, v): self._readonly = v
    def isReadOnly(self): return self._readonly
    def setValidator(self, validator): self.validator = validator
    def setText(self, text): self._text = text; self.textChanged.fire()
    def text(self): return self._text
    def clear(self): self.setText('')

class Button(Widget):
    def __init__(self, title='', parent=None):
        super().__init__(parent)
        self.label=title
        self.clicked=Signal()

class Validator:
    def __init__(self, pattern, parent): self.pattern = pattern.text
class RegularExpression:
    def __init__(self, text): self.text = text

class SizePolicy:
    Expanding=1; Fixed=2; Preferred=3

class ErrorDialog:
    opens=0
    def __init__(self, dark_mode, parent): self.dark_mode=dark_mode
    def exec_(self): ErrorDialog.opens += 1

second = SRC.index('    class GeometryCalculatorPanel(QWidget):', end)
last = SRC.index('    class VolumeFactWidget(QWidget):', second)
ctx = dict(namespace)
ctx.update({'QWidget': Widget, 'QVBoxLayout': Layout, 'QHBoxLayout': Layout,
            'QLineEdit': Input, 'QPushButton': Button, 'QGridLayout': Layout, 'Qt': type('Qt', (), {'AlignLeft': 1}),
            'QRegularExpressionValidator': Validator, 'QRegularExpression': RegularExpression,
            'QSizePolicy': SizePolicy, 'GeometryDataErrorDialog': ErrorDialog, '_solve_geometry_fact': namespace['_solve_geometry_fact']})
exec(compile(textwrap.dedent(SRC[second:last]), 'geometry_stage362_panel.py', 'exec'), ctx)
Panel = ctx['GeometryCalculatorPanel']

class Stage362GeometryTests(unittest.TestCase):
    def test_all_19_supported_and_match_stage361_figures(self):
        area_start = SRC.index('    class AreaFactWidget(VolumeFactWidget):')
        dock_start = SRC.index('    class MathematicsLearningDockWidget(QWidget):')
        area_src = SRC[area_start:dock_start]
        vol_src = SRC[SRC.index('    class VolumeFactWidget(QWidget):'):area_start]
        for key in SPECS:
            self.assertIn(key, area_src if key.startswith('area_') else vol_src)
        self.assertEqual(19, len(SPECS))
        self.assertEqual(8, sum(k.startswith('area_') for k in SPECS))
        self.assertEqual(11, sum(k.startswith('volume_') for k in SPECS))
        self.assertTrue(all(4 <= len(fields) <= 9 for fields in SPECS.values()))
        self.assertTrue(all(all(label for _,label in fields) for fields in SPECS.values()))

    def test_all_19_results_against_independent_numeric_reference(self):
        pi = math.pi
        samples = {
            'area_rectangle':({'a':'6', 'b':'3.5'},21),
            'area_square':({'a':'5'},25),
            'area_triangle':({'g':'8', 'h':'4'},16),
            'area_circle':({'r':'3'},9*pi),
            'area_semicircle':({'r':'3'},4.5*pi),
            'area_ellipse':({'a':'4','b':'2'},8*pi),
            'area_rhombus':({'e':'6','f':'8'},24),
            'area_trapezoid':({'a':'5','c':'3','h':'4'},16),
            'volume_cube':({'a':'3'},27),
            'volume_rectangular':({'l':'2','b':'3','h':'4'},24),
            'volume_cylinder':({'r':'3','h':'4'},36*pi),
            'volume_sphere':({'r':'3'},36*pi),
            'volume_hemisphere':({'r':'3'},18*pi),
            'volume_ellipsoid':({'a':'2','b':'3','c':'4'},32*pi),
            'volume_cone':({'r':'3','h':'4'},12*pi),
            'volume_frustum':({'R':'4','r':'2','h':'3'},28*pi),
            'volume_square_pyramid':({'a':'3','h':'6'},18),
            'volume_rectangular_pyramid':({'l':'2','b':'3','h':'6'},12),
            'volume_triangular_prism':({'b':'3','h':'4','l':'5'},30),
        }
        self.assertEqual(set(SPECS),set(samples))
        for key,(inputs,want) in samples.items():
            with self.subTest(key=key):
                sym,result=calc(key,inputs)
                self.assertEqual(sym,'A' if key.startswith('area') else 'V')
                self.assertAlmostEqual(result,want,places=9)

    def test_invalid_numbers_for_every_figure(self):
        bad = ['', '.', '1.2.3', '1,5', 'x', '-2', '+2', '1e2', '0', '0.0', 'NaN', 'inf', '  ', '1 2']
        for key,fields in SPECS.items():
            args = {symbol:'2' for symbol,_ in fields}
            for text in bad:
                with self.subTest(key=key, invalid=text):
                    inputs = dict(args)
                    inputs[fields[0][0]]=text
                    with self.assertRaises(ValueError): calc(key, inputs)
            with self.assertRaises(ValueError): calc(key,{})

    def test_field_validation_and_unknown_keys(self):
        self.assertEqual(calc('area_circle',{'r':'.5'})[0],'A')
        self.assertAlmostEqual(calc('area_circle',{'r':'2.'})[1],4*math.pi)
        with self.assertRaises(ValueError): calc('volume_frustum',{'R':'2','r':'4','h':'1'})
        with self.assertRaises(ValueError): calc('unlisted',{})
        with self.assertRaises(ValueError): calc('volume_cube',{'a':'9'*600})

    def test_panel_has_readonly_solution_and_action(self):
        p=Panel();p.activate_fact('volume_rectangular')
        self.assertEqual('Berechnen',p.calculate_button.label)
        self.assertTrue(p.result_edit.isReadOnly())
        self.assertEqual('Lösung',p.result_edit.placeholderText())
        self.assertEqual(['l','b','h'],list(p.inputs)[:3])
        self.assertEqual(['Länge l','Breite b','Höhe h'],[f.placeholderText() for f in list(p.inputs.values())[:3]])
        for key,val in {'l':'2','b':'3','h':'4'}.items():p.inputs[key].setText(val)
        p.calculate_button.clicked.fire()
        self.assertTrue(p.result_edit.text().startswith('V = 24'), p.result_edit.text())
        p.inputs['l'].setText('5')
        self.assertEqual('',p.result_edit.text())
        p.calculate()
        self.assertTrue(p.result_edit.text().startswith('V = 60'), p.result_edit.text())

    def test_panel_switch_preserves_each_figures_inputs_but_resets_solution(self):
        p=Panel()
        p.activate_fact('area_rectangle')
        p.inputs['a'].setText('1.5')
        p.inputs['b'].setText('8')
        p.calculate()
        self.assertTrue(p.result_edit.text().startswith('A = 12'), p.result_edit.text())
        p.activate_fact('area_square')
        self.assertEqual('',p.result_edit.text())
        p.inputs['a'].setText('3')
        p.activate_fact('area_rectangle')
        self.assertEqual('1.5',p.inputs['a'].text())
        self.assertEqual('8',p.inputs['b'].text())
        self.assertEqual('',p.result_edit.text())
        p.calculate()
        self.assertTrue(p.result_edit.text().startswith('A = 12'), p.result_edit.text())

    def test_panel_invalid_runs_custom_error_not_messagebox(self):
        ErrorDialog.opens=0
        p=Panel();p.activate_fact('area_triangle')
        p.calculate()
        self.assertEqual(ErrorDialog.opens,1)
        p.inputs['g'].setText('2')
        p.inputs['h'].setText('2..2')
        p.calculate()
        self.assertEqual(ErrorDialog.opens,2)
        self.assertEqual('',p.result_edit.text())

    def test_all_editor_fields_have_strict_decimal_validator(self):
        p=Panel()
        for key in SPECS:
            p.activate_fact(key)
            for input in p.inputs.values():
                rx = re.compile('^' + input.validator.pattern + '$')
                for good in ('1','12.3','0.5','.9','1.'):
                    self.assertIsNotNone(rx.fullmatch(good))
                for bad in ('-1','1,5','3..4','2e3','a','1/2'):
                    self.assertIsNone(rx.fullmatch(bad))

    def test_dark_light_styles(self):
        p=Panel()
        p.set_dark_mode(True)
        self.assertIn('#0e2539',p.style)
        p.set_dark_mode(False)
        self.assertIn('#f6f9fd',p.style)
        dialog_src=SRC[SRC.index('    class GeometryErrorTitleBar(QFrame):'):SRC.index('    class GeometryCalculatorPanel(QWidget):')]
        self.assertIn('border: 3px solid',dialog_src)
        self.assertIn('qlineargradient(',dialog_src)
        self.assertIn('Daten Fehlen bzw. sind nicht gültig',dialog_src)
        self.assertIn("setText('✕')",dialog_src)
        self.assertIn("QPushButton('OK'",dialog_src)
        self.assertIn('close_button.clicked.connect(dialog.reject)',dialog_src)
        self.assertIn('ok_button.clicked.connect(self.accept)',dialog_src)

    def test_math_dock_wires_independent_calculators_and_scrolls(self):
        code=SRC[SRC.index('    class MathematicsLearningDockWidget(QWidget):'):]
        for element in ('area_calculator','volume_calculator'):
            self.assertIn('self.'+element+'.activate_fact(fact_key)',code)
            self.assertIn('self.'+element+'.set_dark_mode(enabled)',code)
        self.assertIn('_add_geometry_fact_page(',code)
        self.assertIn('holder.setMinimumSize(800, 760)',code)
        self.assertIn('row.addWidget(calculator, 1, Qt.AlignLeft)',code)

if __name__=='__main__':unittest.main()
