# Stage 357 – speechConvert: --lang/-l, --merge/-m und Piper-Textkonvertierung

Basis: Stage 356 (`d64_dism_asm_356.zip`). Kein Wechsel des SPC1-Dateiformats.

## SPC1-Container zusammenführen

```powershell
python speechConvert.py --merge sprache_de.spc sprache_en.spc --verify
python speechConvert.py -m sprache_de.spc sprache_en.spc -oc beide_sprachen.spc --verify
python speechConvert.py -m sprache_de.spc sprache_en.spc --on-conflict replace
python speechConvert.py -m sprache_de.spc sprache_en.spc --on-conflict error
```

- Ohne `-oc` wird **Datei 1** atomar aktualisiert; Datei 2 bleibt unverändert.
- Mit `-oc` wird in den angegebenen Zielcontainer geschrieben. Quelldateien bleiben unverändert.
- GZIP-Markierungen, Payload-Bytes, PCM-/ADPCM-/MP3-/Ogg-Codecs und CRC32 bleiben identisch.
- Namensvergleich ist wie bisher ohne Groß-/Kleinschreibung.
- Namenskonflikte: `keep` (Standard: Datei 1 behalten), `replace` (Datei 2 gewinnt), `error` (Abbruch ohne Änderung).
- Falscher oder beschädigter Quellcontainer verursacht einen Fehler; beim Schreiben bleibt das alte Ziel erhalten.
- `-gz`/`-c` gelten beim Hinzufügen neuer Samples, nicht beim verlustfreien Merge.

## Sprache für Piper auswählen

Piper besitzt für ein ONNX-Modell **keine separate Sprachauswahl**. `--lang` bestimmt, welches lokal installierte Modell `speechConvert.py` für eine neue Sprachaufnahme auswählt. Die Option beeinflusst bestehende WAV-Dateien nicht.

```powershell
# Sprachmodelle anzeigen (Beispiele; nicht notwendigerweise installiert)
python speechConvert.py --list-voices

# Deutsches Modell (Standard de_DE-thorsten-high.onnx)
python speechConvert.py --text "Guten Morgen" -l de_DE -ow morgen.wav

# Andere deutsche Sprecherin
python speechConvert.py --text "Guten Tag" -l de_DE --voice kerstin --quality low -ow guten_tag.wav

# Englisches Modell (Standard en_US-amy-medium.onnx)
python speechConvert.py --text "Hello world" -l en_US -ow hello.wav

# Piper-Ausgabe gleich als IMA-ADPCM-Sample in Container aufnehmen
python speechConvert.py --text "Hello" -l en_US -a HELLO -oc englisch.spc --gzip

# Optional:
python speechConvert.py --text "Hello" -l en_US --model-dir C:\\piper -a HELLO -oc englisch.spc
python speechConvert.py --text "Hello" -l en_US --model C:\\piper\\en_US-amy-medium.onnx --piper C:\\piper\\piper.exe -ow hello.wav
```

Standard: `de_DE` → `thorsten/high`; `en_US` → `amy/medium`. Wenn `--voice`/`--quality` gesetzt wird, sucht das Tool `LAND_SPRECHER_QUALITAET.onnx` **und** `...onnx.json` in `speech/piper`, `piper` oder `--model-dir`. Ein Modell kann über `--model` ausgewählt werden, ein Piper-Binary über `--piper`. Fehlende Dateien werden als Fehler gemeldet; das Tool lädt Stimmen nicht selbst herunter. Ohne `.onnx`-Datei kann keine neue Sprachaufnahme generiert werden.

**Achtung:** Auch das Ergebnis von `--text ... -ow ...` verwendet den allgemeinen Ausgabecodec, standardmäßig IMA-ADPCM. Wer unkomprimiertes PCM-WAV benötigt, verwendet `-c pcm`.

## Verifizierte Modelle – Dateinamensbeispiele

Die Paarung ist stets `*.onnx` + `*.onnx.json` (der Konfigurationsname hat zwei Erweiterungen).

| Sprache | Dateien (Basename) | Qualität |
|---|---|---|
| de_DE | `de_DE-thorsten-high.onnx` | high |
| de_DE | `de_DE-thorsten-medium.onnx` | medium |
| de_DE | `de_DE-kerstin-low.onnx` | low |
| de_DE | `de_DE-ramona-low.onnx` | low |
| de_DE | `de_DE-thorsten_emotional-medium.onnx` | medium (Multi-Speaker) |
| en_US | `en_US-amy-medium.onnx` | medium |
| en_US | `en_US-joe-medium.onnx` | medium |
| en_US | `en_US-lessac-medium.onnx` | medium; Modell-Lizenz vor Weitergabe prüfen |

Katalog: https://huggingface.co/rhasspy/piper-voices/tree/main
Download-Muster: `https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/thorsten/high/de_DE-thorsten-high.onnx` und derselbe Dateiname plus `.json`.

## Tests

`python -m unittest -v test_stage357_speechconvert_merge_piper.py`

Prüft unter anderem: In-place-Merge, separate Zieldatei, unveränderte gzip-Payload, Namenskonflikte, unveränderte Quelldateien bei Fehlern, deutsch/englische Modellauswahl, simulierte Piper-WAV und Wiedergabe der gemergten Daten mit dem nativen C-Decoder. Echter Windows-Piper-Laufzeittest ist noch ausstehend.
