"""Stage 358: Piper-EXE/Windows-Fail-Fast diagnostics and Python backend tests.

The fake CLI programs are POSIX scripts; they test error handling and subprocess
contract, NOT the Windows native Piper binary itself.
"""
from pathlib import Path
import contextlib
import io
import os
import tempfile
import unittest
import wave
from unittest.mock import patch
import speechConvert as sc


def fake_wav(path):
    with wave.open(str(path), 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(b'\x08\x01' * 1000)


class Process:
    def __init__(self, returncode, stderr=b'', stdout=b''):
        self.returncode=returncode
        self.stderr=stderr
        self.stdout=stdout


class TestPiperBackend(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.model=self.root/'de_DE-kerstin-low.onnx'
        self.model.write_bytes(b'fake onnx')
        Path(str(self.model)+'.json').write_text('{}', encoding='utf-8')
        self.exe=self.root/'piper.exe'
        self.exe.write_bytes(b'MZ dummy')

    def tearDown(self):
        self.temp.cleanup()

    def args(self, *other):
        return sc._arg_parser().parse_args(['--text', 'Guten Morgen',
             '--model', str(self.model), '-l', 'de_DE', '--piper', str(self.exe), *other])

    def test_native_crash_reports_windows_status_and_remedy(self):
        args=self.args('--piper-backend', 'exe')
        with patch.object(sc.subprocess, 'run', return_value=Process(-1073740791)):
            with self.assertRaises(sc.SpeechError) as raised:
                sc.synthesize_piper('Guten Morgen', args)
        detail=str(raised.exception)
        self.assertIn('0xC0000409', detail)
        self.assertIn('3221226505', detail)
        self.assertIn('python -m pip install',detail)
        self.assertIn('nicht durch',detail.lower())

    def test_auto_fallback_on_native_failfast(self):
        args=self.args('--piper-backend', 'auto', '--piper-python', 'python')
        commands=[]
        def run(command, **kw):
            commands.append(command)
            if len(commands)==1:
                return Process(3221226505)
            self.assertEqual(command[1:3],['-m','piper'])
            self.assertEqual(kw['input'], b'Guten Morgen\n')
            wav=Path(command[command.index('--output_file')+1])
            fake_wav(wav)
            return Process(0)
        with patch.object(sc.subprocess, 'run', side_effect=run):
            with contextlib.redirect_stderr(io.StringIO()):
                audio=sc.synthesize_piper('Guten Morgen',args)
        self.assertEqual(audio.frames,1000)
        self.assertEqual(len(commands),2)

    def test_python_backend_without_exe(self):
        args=self.args('--piper-backend','python')
        args.piper=None
        commands=[]
        def run(command, **kw):
            commands.append(command)
            fake_wav(Path(command[command.index('--output_file')+1]))
            return Process(0)
        with patch.object(sc.subprocess,'run', side_effect=run):
            audio=sc.synthesize_piper('Guten Morgen',args)
        self.assertEqual(audio.rate,16000)
        self.assertEqual(len(commands),1)
        self.assertIn('-m',commands[0])

    def test_regular_exe_error_does_not_switch_backend(self):
        args=self.args()
        with patch.object(sc.subprocess,'run',return_value=Process(123,b'invalid model')) as mock:
            with self.assertRaises(sc.SpeechError) as caught:
                sc.synthesize_piper('Guten Morgen',args)
        self.assertEqual(mock.call_count,1)
        self.assertIn('invalid model',str(caught.exception))

    def test_python_missing_package_has_instructions(self):
        args=self.args('--piper-backend','python')
        args.piper=None
        with patch.object(sc.subprocess,'run',return_value=Process(1,b'No module named piper')):
            with self.assertRaises(sc.SpeechError) as caught:
                sc.synthesize_piper('Guten Morgen',args)
        self.assertIn('pip install --upgrade piper-tts',str(caught.exception))

    def test_error_does_not_modify_container(self):
        args=self.args('--piper-backend','exe')
        container=self.root/'unchanged.spc'
        container.write_bytes(b'test-original')
        with patch.object(sc.subprocess,'run',return_value=Process(3221226505)):
            with self.assertRaises(sc.SpeechError):
                sc.synthesize_piper('Guten Morgen',args)
        self.assertEqual(container.read_bytes(),b'test-original')

    def test_unsigned_windows_code_rendering(self):
        self.assertEqual(sc._piper_exit_code(-1073740791),'3221226505 (0xC0000409)')


if __name__=='__main__':
    unittest.main(verbosity=2)
