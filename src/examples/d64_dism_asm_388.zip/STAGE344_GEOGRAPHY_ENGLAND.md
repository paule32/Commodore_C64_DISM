# Stage 344 – Lernen → Geographie → Deutschland / England

**Verbindliche Ausgangsbasis:** `d64_dism_asm_343.zip`.

## Hauptmenü

Alte Struktur `Lernen → Deutsch → Geographie` entfernt. Stattdessen:

```text
Lernen
└─ Geographie
   ├─ Deutschland
   └─ England
```

- `germany_geography_action` bleibt erhalten und heißt nun `Deutschland`.
- Neues `england_geography_action` startet `MainWindow.show_england_geography_dock()`.
- Die vorhandene Deutschland-Karte und ihre Bundesland-Hover-/Wappenfunktion bleiben erhalten.

## England

- Eigener `EnglandMapDock` mit `EnglandMapView`, vollständig im freien Dockbereich.
- Original-England-PNG aus der Benutzernachricht ist **unverändert** in `england.py` (Base85/lazy) eingebettet: 371×463 Pixel, SHA256 `83e78086861bada59543fc09da3b64d3b3a7050fa825c58a7138fae20fa45bd0`.
- `Ansicht → Zoom` (50–400 %) und `STRG+Mausrad` funktionieren analog zur Deutschland-Karte.
- Dark-/Light-Mode passt die freie Dockfläche an; die blaue Wasserfarbe und alle Beschriftungen der hochgeladenen Vorlage bleiben unverändert.
- Beim Schließen werden Qt-Szene, Bildobjekt und die lazy geladenen Base85-Bilddaten freigegeben.
- Im Originalbild sind traditionelle/historische Counties abgebildet. Für England wurde **keine erfundene Geometrie oder Hauptstadtdatenbank** ergänzt. County-Hover wie bei den deutschen Bundesländern ist nicht Bestandteil dieser Stage.

## Länderwechsel und Docklayout

Deutschland und England nutzen denselben Vollflächen-Workspace und dieselben bestehenden Ansicht-Zoom-Aktionen. Beim direkten Länderwechsel wird das vorige Karten-Dock mit blockierten `visibilityChanged`-Signalen versteckt. Dadurch bleibt die vor dem ersten Öffnen gespeicherte Dock- und Zentralwidget-Anordnung erhalten. Nach Schließen des zuletzt aktiven Karten-Docks werden die ursprünglichen Docks sichtbar.

Beim erstmaligen Einfügen eines der Karten-Docks werden temporäre Show/Hide-Signale ebenfalls unterdrückt, damit der Kartenwechsel nicht schon beim Erzeugen des zweiten Landes das Workspace-Layout zurücksetzt.

## Tests

- `python -m py_compile d64_dism.py england.py`
- `python -m unittest test_stage344_geography_menu.py -v` – vier Tests, darunter zwei-Wege-Dockwechsel mit echten extrahierten GUI-Methoden und simulierten Qt-Docks.
- Vorhandene fokussierte Tests aus Stages 334–338.
- ZIP-Inhalts- und Integritätskontrolle.

**Einschränkung:** In dieser Linux-Umgebung ist PyQt5 nicht installiert. Ein nativer Windows-/Qt5-GUI-Test der Karte und des Menüaufbaus muss noch durchgeführt werden.
