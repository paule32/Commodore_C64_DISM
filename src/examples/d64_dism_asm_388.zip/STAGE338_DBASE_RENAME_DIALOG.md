# Stage 338 – Umbenennen über Eingabedialog

Basis: `d64_dism_asm_337.zip`.

- `dBase-Programme → Programme → <datei.prg> → Umbenennen` öffnet statt des TreeWidget-Inline-Editors einen modalen, rahmenlosen Qt5-Eingabedialog.
- Der Dialog besitzt eine selbst gezeichnete schwarze/graue Titelleiste, 3-Pixel-Rahmen, ein vorbefülltes Dateinamenfeld sowie die Schaltflächen `Ok` und `Abbrechen`.
- `Ok` führt die vorhandene Dateiumbenennung einschließlich Projektknoten, offenem Editor und Projektspeicherung aus; `Abbrechen`/Titelleisten-X lassen alle Dateien und Einträge unverändert.
- Kollisionen benutzen weiterhin den vorhandenen Warnungsdialog und behalten den alten Namen bei.
- Die bisher fehleranfällige `editItem()`-Inline-Bearbeitung und ihr `itemChanged`-Commit sind für `.prg`-Dateien entfernt.
- Prüfungen: Python-Parser/Kompilierung; gezielte Quelltext-Regressionstests für Stages 335–338. Ein echter PyQt5-Windows-GUI-Test ist noch erforderlich.
