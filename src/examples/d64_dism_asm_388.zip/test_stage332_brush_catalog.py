"""Tests der Bibliotheksverwaltung, auch ohne Qt5 im Build-Host."""
import json
import tempfile
import types
import sys
import unittest
from pathlib import Path

from d64_brush_catalog import load_catalog, register_pattern, FORMAT


class BrushCatalogTests(unittest.TestCase):
    def setUp(self):
        self.old = sys.modules.get('d64_custom_brush')
        module = types.ModuleType('d64_custom_brush')
        def validate(data):
            w, h = int(data['width']), int(data['height'])
            assert 1 <= w <= 128 and 1 <= h <= 128
            assert len(data['palette']) == 32
            assert len(data['pixels']) == h
            assert all(len(row) == w for row in data['pixels'])
            return {k: data[k] for k in ('format', 'width', 'height', 'palette', 'pixels')}
        module.validated_pattern = validate
        sys.modules['d64_custom_brush'] = module

    def tearDown(self):
        if self.old is None:
            del sys.modules['d64_custom_brush']
        else:
            sys.modules['d64_custom_brush'] = self.old

    def test_multiple_individual_sizes_and_update(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'brush.json'
            def data(w, h):
                return {'format': 'd64-custom-brush-v1', 'width': w, 'height': h,
                        'palette': ['#000000'] * 32, 'pixels': [[2] * w for _ in range(h)]}
            first = register_pattern('Karo', data(8, 8), path=path)
            register_pattern('Streifen', data(16, 4), path=path)
            self.assertEqual([(e['width'], e['height']) for e in load_catalog(path)], [(8, 8), (16, 4)])
            register_pattern('Karo neu', data(12, 6), identifier=first['id'], path=path)
            self.assertEqual(len(load_catalog(path)), 2)
            self.assertEqual(load_catalog(path)[0]['pixels'][-1][-1], 2)
            self.assertEqual(load_catalog(path)[0]['height'], 6)
            self.assertEqual(json.loads(path.read_text('utf-8'))['format'], FORMAT)

    def test_invalid_catalog_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'brush.json'
            path.write_text('not a json', encoding='utf-8')
            with self.assertRaises(ValueError):
                load_catalog(path)
            self.assertEqual(path.read_text('utf-8'), 'not a json')

if __name__ == '__main__':
    unittest.main()
