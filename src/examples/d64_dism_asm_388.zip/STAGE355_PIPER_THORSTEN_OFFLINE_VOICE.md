# Stage 355 – Fertige deutsche Stimme mit Piper / Thorsten-Voice

## Basis
- `d64_dism_asm_354.zip` als verbindliche Baseline
- Die bestehende 81-Token-Formantsynthese, vorhandene dBase-SAY-Funktion
  und Windows-PE32-Linker bleiben erhalten.

## Motivation
Stage 354 verbessert Wortabstände und Lautübergänge, aber seine künstliche
Formantsynthese bleibt subjektiv schwer verständlich. Statt die bestehenden
Phonemschnipsel mit zusätzlichen Kurven zu kombinieren, verwendet Stage 355
eine **fertige Offline-Stimme**, die ganze Sätze erzeugt.

## Sprachpaket
- Projekt: https://github.com/rhasspy/piper (MIT im ausgewählten alten Release)
- Windows-Binary: https://github.com/rhasspy/piper/releases/tag/2023.11.14-2
- deutsche Stimme: https://huggingface.co/rhasspy/piper-voices/tree/main/de/de_DE/thorsten/high
- Satz-Sample-Rate: 22.050 Hz für `de_DE-thorsten-high` (aus dessen Model Card)
- Lizenz der zugrundeliegenden Thorsten-Daten: CC0 (Model Card)
- Binary / ONNX sind nicht im Projekt-ZIP enthalten. Es ist deshalb
  weder eine Audio-Paket-Redistribution noch ein Windows-Test behauptet.

## Realisierte Implementierung

### Native Sprach-DLL: `speech/retro_speech.c/.h`
- neuer x86-PE32-DLL-Export `SpeechSetBackend(0 | 1)`
- Backend 0: bisherige originale Formantsynthese
- Backend 1: Windows-Win32-Bridge zu `piper.exe` und einem lokalen Sprachmodell
- Übergabe des deutschen Textes als UTF-8 auf stdin; stdout/stderr abgekoppelt
- `CreateProcessW` mit `CREATE_NO_WINDOW`, ohne zusätzliche Konsole
- Ein WAV pro vollständigem Satz; kein Aneinanderstückeln von Phonemsamples
- WAV-Cache in `%LOCALAPPDATA%/d64_dism_speech_cache/` oder TEMP
- Überprüfung vorhandener WAVs auf gültigen RIFF/WAVE-Header
- Windows-Ausgabe per `PlaySoundW` (WinMM); WAV-Export per `SpeechSaveWav`
- Fehler 7 für fehlendes Paket, Fehler 8 für fehlerhaften Piper-Prozess

### dBase-Compiler: `d64dbase/compiler.py`
- `SET SPEECH MODE PIPER`
- `SET SPEECH MODE SAMPLES` als Alias für Piper
- `SET SPEECH MODE C64/HYBRID/AMIGA` setzt Backend auf Formantsynthese zurück
- Einstellung bleibt auch erhalten, wenn `SET SPEECH MODE PIPER` vor
  `SET SPEECH ON` verwendet wird
- zusätzlicher Import `SpeechSetBackend` und interne Datenvariable
  `__dbase_speech_backend`, **nur** für Sprachprogramme

### Installation / Demo
- neues `speech/install_piper_voice.py` lädt Windows-Binary und Thorsten-Modell
  (Standard High), inklusive Config und MODEL_CARD
- `speech/retro_speech_demo.c` kann `--backend piper` ansteuern
- README mit Installationspfaden und Debug-Hinweisen erweitert

## Teststatus
- Host-C99-Build und Python-Tests prüfen Backendumschaltung, Fehlercodes,
  dBase-Parsing/-Assembler-Ausgabe und Kompatibilität mit bisherigem Runtime-Code.
- Eine vollständige Live-Sprachausgabe unter Windows und der Download der
  externen großen Binärpakete sind in dieser Container-Umgebung **nicht** geprüft.

## Installationsbeispiel

```text
python speech/install_piper_voice.py --quality high
python speech/build_pe32.py      # unter MSYS2 MINGW32
```

```dbase
SET SPEECH MODE PIPER
SET SPEECH ON
SAY "Guten Morgen! Hier spricht der Computer."
SET SPEECH OFF
```
