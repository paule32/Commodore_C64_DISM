TTL 74xx SVG-Paket
===================

Inhalt:
- beschriftet/: 10 beschriftete SVG-Grafiken (74LS00, 02, 04, 08, 10, 11, 20, 21, 32, 86)
- unbeschriftet/: dieselben 10 Typen ohne Pin-Beschriftung
- uebersicht/: die erzeugte 74xx-Palettenansicht als SVG
- referenz/: die ursprünglich hochgeladene 74LS00-SVG-Referenz

Die aus den generierten PNG-Grafiken abgeleiteten SVGs sind echte Vektorpfade (kein eingebettetes Rasterbild).
Standardgröße der Einzelbausteine: 310 x 180 Pixel, viewBox 0 0 310 180.
Die Beschriftungen der beschrifteten Varianten wurden als Vektorpfade aus der erzeugten Grafik übernommen.
